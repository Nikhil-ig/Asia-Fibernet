// models/customer_details_model.dart

// Enum to potentially differentiate customer/technician details if needed in the future
enum ProfileType { customer, technician }

class CustomerDetails {
  final int? id;
  final int? accountId;
  final String? accountType;
  final String? contactName;
  final String? address;
  final String? city;
  final String? state;
  // Unified phone field example (you can keep workPhone/cellPhone separate if preferred)
  // final String? phoneNumber;
  final String? workPhone;
  final String? cellPhone;
  final String? email;
  final String? referralCode;
  final String? referredBy;
  final String? plan;
  final String? profileImageUrl; // Assuming relative path from API
  // --- Additional Fields from your API response ---
  final String? frServiceCode;
  final String? category;
  final String? exchangeCode;
  final String? ftthNo;
  final String? subServiceType;
  final String? subscriptionPlan;
  final String? planPeriod;
  final String? fmc;
  final String? bbUserId;
  final String? bbActivationDate;
  final String? assignTo;
  final String? status;

  CustomerDetails({
    this.id,
    this.accountId,
    this.accountType,
    this.contactName,
    this.address,
    this.city,
    this.state,
    // this.phoneNumber,
    this.workPhone,
    this.cellPhone,
    this.email,
    this.referralCode,
    this.referredBy,
    this.plan,
    this.profileImageUrl,
    this.frServiceCode,
    this.category,
    this.exchangeCode,
    this.ftthNo,
    this.subServiceType,
    this.subscriptionPlan,
    this.planPeriod,
    this.fmc,
    this.bbUserId,
    this.bbActivationDate,
    this.assignTo,
    this.status,
  });

  /// Factory method to create a CustomerDetails object from a JSON map.
  factory CustomerDetails.fromJson(Map<String, dynamic> json) {
    return CustomerDetails(
      id: json['ID'] as int?,
      accountId: json['AccountID'] as int?,
      accountType: json['AccountType'] as String?,
      contactName: json['ContactName'] as String?,
      address: json['Address'] as String?,
      city: json['City'] as String?,
      state: json['State'] as String?,
      // phoneNumber: _parseToString(json['Workphnumber']) ?? _parseToString(json['Cellphnumber']),
      workPhone: _parseToString(json['Workphnumber']),
      cellPhone: _parseToString(json['Cellphnumber']),
      email: json['Email'] as String?,
      referralCode: json['referral_code'] as String?,
      referredBy: json['referred_by'] as String?,
      plan:
          json['plan']
              as String?, // Make sure 'plan' exists in your API response
      profileImageUrl:
          "https://dgipe.com/af/api/${json['profile_photo']}"
              as String?, // Relative path
      frServiceCode: json['FR_Service_Code'] as String?,
      category: json['Category'] as String?,
      exchangeCode: json['Exchange_Code'] as String?,
      ftthNo: json['ftth_no'] as String?, // Check API key name
      subServiceType: json['Sub_Service_Type'] as String?,
      subscriptionPlan: json['Subscription_Plan'] as String?,
      planPeriod: json['Plan_Period'] as String?,
      fmc: json['FMC'] as String?,
      bbUserId: json['BB_USER_ID'] as String?,
      bbActivationDate: json['BB_Activation_Date'] as String?,
      assignTo: json['Assign_To'] as String?,
      status: json['Status'] as String?,
    );
  }

  /// Helper method to safely convert dynamic values (like int or String) to String.
  static String? _parseToString(dynamic value) {
    if (value == null) return null;
    return value.toString();
  }

  /// Converts the CustomerDetails object back to a JSON map.
  Map<String, dynamic> toJson() {
    return {
      'ID': id,
      'AccountID': accountId,
      'AccountType': accountType,
      'ContactName': contactName,
      'Address': address,
      'City': city,
      'State': state,
      // 'Workphnumber': phoneNumber, // Adjust based on how you store it
      'Workphnumber': workPhone,
      'Cellphnumber': cellPhone,
      'Email': email,
      'referral_code': referralCode,
      'referred_by': referredBy,
      'plan': plan,
      'profile_photo': profileImageUrl,
      'FR_Service_Code': frServiceCode,
      'Category': category,
      'Exchange_Code': exchangeCode,
      'ftth_no': ftthNo,
      'Sub_Service_Type': subServiceType,
      'Subscription_Plan': subscriptionPlan,
      'Plan_Period': planPeriod,
      'FMC': fmc,
      'BB_USER_ID': bbUserId,
      'BB_Activation_Date': bbActivationDate,
      'Assign_To': assignTo,
      'Status': status,
    };
  }

  // Optional: Get full image URL
  String? get fullProfileImageUrl {
    if (profileImageUrl == null || profileImageUrl!.isEmpty) return null;
    // Handle if API already provides full URL
    if (profileImageUrl!.startsWith('http')) {
      return profileImageUrl;
    }
    // Construct base URL - adjust based on your server structure
    // Example: If your base API URL is https://dgipe.com/af/api/
    // and images are stored relative to https://dgipe.com/af/
    return 'https://dgipe.com/af/api//techAPI/$profileImageUrl'; // Prepend base path
  }

  @override
  bool operator ==(covariant CustomerDetails other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.accountId == accountId &&
        other.accountType == accountType &&
        other.contactName == contactName &&
        other.address == address &&
        other.city == city &&
        other.state == state &&
        // other.phoneNumber == phoneNumber &&
        other.workPhone == workPhone &&
        other.cellPhone == cellPhone &&
        other.email == email &&
        other.referralCode == referralCode &&
        other.referredBy == referredBy &&
        other.plan == plan &&
        other.profileImageUrl == profileImageUrl &&
        other.frServiceCode == frServiceCode &&
        other.category == category &&
        other.exchangeCode == exchangeCode &&
        other.ftthNo == ftthNo &&
        other.subServiceType == subServiceType &&
        other.subscriptionPlan == subscriptionPlan &&
        other.planPeriod == planPeriod &&
        other.fmc == fmc &&
        other.bbUserId == bbUserId &&
        other.bbActivationDate == bbActivationDate &&
        other.assignTo == assignTo &&
        other.status == status;
  }

  @override
  String toString() {
    return 'CustomerDetails(id: $id, contactName: $contactName, email: $email, accountId: $accountId)';
  }
}
