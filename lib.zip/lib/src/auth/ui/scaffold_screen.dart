// screens/scaffold_screen.dart
import 'package:asia_fibernet/src/services/apis/base_api_service.dart';
import 'package:asia_fibernet/src/services/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import '../../customer/ui/screen/profile_screen.dart';
import '../../services/apis/api_services.dart';
import '../../services/sharedpref.dart';
import '../../theme/colors.dart';
import '../../theme/theme.dart';
import '../../customer/ui/screen/pages/complaints_page.dart';
import '../../customer/ui/screen/pages/home_page.dart';
import '../core/model/customer_details_model.dart';
import 'placeholder_screens.dart';
import '../../customer/ui/screen/bsnl_screen.dart';

// lib/src/controllers/scaffold_controller.dart

class ScaffoldController extends GetxController {
  ApiServices apiServices = Get.find<ApiServices>();
  BaseApiService baseApiService = Get.find<BaseApiService>();
  var currentIndex = 0.obs;
  final isLoading = true.obs;
  Rx<CustomerDetails?> customer = Rx<CustomerDetails?>(null);
  RxString custName = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchCustomerData();
  }

  void updateIndex(int index) {
    currentIndex.value = index;
  }

  void navigateToReferral() {
    currentIndex.value = 2;
  }

  Future<void> fetchCustomerData() async {
    isLoading.value = true;
    try {
      final userId = AppSharedPref.instance.getUserID();
      // final
      if (userId == null) {
        print("❌ No user ID found in shared prefs!");
        return;
      }

      print("🔍 Fetching customer data for user ID: $userId");

      final customerData = await apiServices.fetchCustomer();

      if (customerData == null) {
        print("❌ API returned null customer data");
        baseApiService.showSnackbar(
          'Error',
          'Failed to load profile. Please log in again.',
          isError: true,
        );
        return;
      }

      print("✅ Customer loaded: ${customerData.contactName}");

      // ✅ CORRECT: Update .value, don't reassign Rx
      custName.value = customerData.contactName ?? "User";
      customer.value = customerData;
    } catch (e, stack) {
      print("🔥 Error fetching customer: $e");
      print("Stack: $stack");
      baseApiService.showSnackbar(
        'Error',
        "Unable to load your profile. Try again later.",
        isError: true,
      );
    } finally {
      isLoading.value = false;
    }
  }
}

// screens/scaffold_screen.dart
// ... (Keep your existing ScaffoldController code as is)

class ScaffoldScreen extends StatelessWidget {
  const ScaffoldScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final scaffoldCtrl =
        Get.isRegistered<ScaffoldController>()
            ? Get.find<ScaffoldController>()
            : Get.put(ScaffoldController());

    final screens = [
      HomeScreenContent(),
      PremiumBsnlPlansScreen(),
      const AiScreen(),
      ComplaintsScreen(),
      ProfileScreen(),
    ];

    return Obx(() {
      final currentIndex = scaffoldCtrl.currentIndex.value;
      final showAppBar = currentIndex != 1 && currentIndex != 4;

      return Scaffold(
        extendBody: true,
        appBar:
            showAppBar
                ? AppBar(
                  centerTitle: false,
                  title: _AppBarGreeting(),
                  backgroundColor: Colors.white,
                  elevation: 0,
                  shadowColor: AppColors.primary.withOpacity(0.1),
                  actions: [_ProfileAvatarButton()],
                )
                : null,
        body: IndexedStack(index: currentIndex, children: screens),
        floatingActionButton: _FloatingActionCenterButton(
          currentIndex: currentIndex,
          onTap: () => scaffoldCtrl.updateIndex(2),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: _BeautifulBottomNavBar(
          currentIndex: currentIndex,
          onIndexChanged: scaffoldCtrl.updateIndex,
        ),
      );
    });
  }
}

class _BeautifulBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onIndexChanged;

  const _BeautifulBottomNavBar({
    Key? key,
    required this.currentIndex,
    required this.onIndexChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 20.r,
            spreadRadius: 0,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        child: Container(
          height: 80.h,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              top: BorderSide(color: Colors.grey.shade100, width: 1.w),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left side items
              _BottomNavItem(
                icon: Iconsax.home,
                activeIcon: Iconsax.home_15,
                label: 'Home',
                index: 0,
                currentIndex: currentIndex,
                onTap: onIndexChanged,
              ),
              _BottomNavItem(
                icon: Iconsax.document,
                activeIcon: Iconsax.document5,
                label: 'Plans',
                index: 1,
                currentIndex: currentIndex,
                onTap: onIndexChanged,
              ),

              // Spacer for FAB
              SizedBox(width: 40.w),

              // Right side items
              _BottomNavItem(
                icon: Iconsax.message,
                activeIcon: Iconsax.message5,
                label: 'Support',
                index: 3,
                currentIndex: currentIndex,
                onTap: onIndexChanged,
              ),
              _BottomNavItem(
                icon: Iconsax.profile_circle,
                activeIcon: Iconsax.profile_circle5,
                label: 'Profile',
                index: 4,
                currentIndex: currentIndex,
                onTap: onIndexChanged,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final int index;
  final int currentIndex;
  final Function(int) onTap;

  const _BottomNavItem({
    Key? key,
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.index,
    required this.currentIndex,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isActive = currentIndex == index;

    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => onTap(index),
          splashColor: AppColors.primary.withOpacity(0.1),
          highlightColor: AppColors.primary.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12.r),
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 8.h),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.fastEaseInToSlowEaseOut,
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    color:
                        isActive
                            ? AppColors.primary.withOpacity(0.1)
                            : Colors.transparent,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isActive ? activeIcon : icon,
                    size: 24.r,
                    color: isActive ? AppColors.primary : Colors.grey.shade600,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  label,
                  style: AppText.labelSmall.copyWith(
                    fontSize: 10.sp,
                    fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                    color: isActive ? AppColors.primary : Colors.grey.shade600,
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FloatingActionCenterButton extends StatelessWidget {
  final int currentIndex;
  final VoidCallback onTap;

  const _FloatingActionCenterButton({
    Key? key,
    required this.currentIndex,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isActive = currentIndex == 2;

    return FloatingActionButton(
      onPressed: onTap,
      elevation: 4,
      backgroundColor: isActive ? AppColors.primary : Colors.white,
      foregroundColor: isActive ? Colors.white : AppColors.primary,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
        side: BorderSide(color: AppColors.primary.withOpacity(0.2), width: 2.w),
      ),
      child: Container(
        width: 56.r,
        height: 56.r,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.r),
          gradient:
              isActive
                  ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppColors.primary,
                      AppColors.primary.withOpacity(0.8),
                    ],
                  )
                  : null,
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withOpacity(isActive ? 0.3 : 0.1),
              blurRadius: 12.r,
              spreadRadius: 1.r,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Icon(
          isActive ? Iconsax.magicpen5 : Iconsax.magicpen,
          size: 24.r,
          color: isActive ? Colors.white : AppColors.primary,
        ),
      ),
    );
  }
}

// ... (Keep your existing _AppBarGreeting and _ProfileAvatarButton code as is)
// Reusable Widgets

class _AppBarGreeting extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scaffoldCtrl = Get.find<ScaffoldController>();

    return Obx(() {
      if (scaffoldCtrl.isLoading.value) {
        // Skeleton loading
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(width: 120.w, height: 20.h, color: Colors.grey.shade300),
            SizedBox(height: 4.h),
            Container(width: 180.w, height: 16.h, color: Colors.grey.shade200),
          ],
        );
      }

      // ✅ Single source of truth
      final name = scaffoldCtrl.custName.value.trim();
      final displayName = name.isEmpty ? "User" : name;

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Hello, $displayName!",
            style: AppText.headingMedium.copyWith(
              color: AppColors.textColorPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            "Welcome to Asia Fibernet",
            style: AppText.bodySmall.copyWith(
              color: AppColors.textColorSecondary.withOpacity(0.8),
            ),
          ),
        ],
      );
    });
  }
}

class _ProfileAvatarButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scaffoldCtrl = Get.find<ScaffoldController>();

    return Obx(() {
      if (scaffoldCtrl.isLoading.value) {
        return Padding(
          padding: EdgeInsets.only(right: 16.w),
          child: CircleAvatar(
            radius: 20.r,
            backgroundColor: Colors.grey.shade300,
            child: Icon(Icons.person, color: Colors.grey.shade500, size: 20.r),
          ),
        );
      }

      final profileImageUrl = scaffoldCtrl.customer.value?.fullProfileImageUrl;

      return GestureDetector(
        onTap: () => Get.toNamed(AppRoutes.profile),
        child: Padding(
          padding: EdgeInsets.only(right: 16.w),
          child: CircleAvatar(
            radius: 20.r,
            backgroundColor: AppColors.primary.withOpacity(0.1),
            foregroundImage:
                profileImageUrl != null && profileImageUrl.isNotEmpty
                    ? NetworkImage(profileImageUrl)
                    : null,
            child:
                profileImageUrl == null || profileImageUrl.isEmpty
                    ? Icon(Icons.person, color: AppColors.primary, size: 20.r)
                    : null,
          ),
        ),
      );
    });
  }
}

// class _BottomNavBarItem extends StatelessWidget {
//   final IconData icon;
//   final String label;
//   final bool isSelected;
//   final VoidCallback onTap;

//   const _BottomNavBarItem({
//     Key? key,
//     required this.icon,
//     required this.label,
//     required this.isSelected,
//     required this.onTap,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Expanded(
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           onTap: onTap,
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Container(
//                 padding: EdgeInsets.all(6.r),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color:
//                       isSelected
//                           ? AppColors.primary.withOpacity(0.1)
//                           : Colors.transparent,
//                 ),
//                 child: Icon(
//                   icon,
//                   size: 24.r,
//                   color:
//                       isSelected ? AppColors.primary : AppColors.textColorHint,
//                 ),
//               ),
//               // SizedBox(height: 2.h),
//               Expanded(
//                 child: Text(
//                   label,
//                   style: AppText.labelMedium.copyWith(
//                     fontWeight:
//                         isSelected ? FontWeight.w600 : FontWeight.normal,
//                     fontSize: 12.sp,
//                     color:
//                         isSelected
//                             ? AppColors.primary
//                             : AppColors.textColorHint,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
