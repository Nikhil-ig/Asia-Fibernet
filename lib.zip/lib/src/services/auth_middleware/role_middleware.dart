import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../sharedpref.dart';
import '../routes.dart';

class RoleMiddleware extends GetMiddleware {
  @override
  int get priority => 2; // Higher priority than AuthMiddleware

  @override
  RouteSettings? redirect(String? route) {
    final isLoggedIn = AppSharedPref.instance.isUserLoggedIn();
    final userRole = AppSharedPref.instance.getRole();

    // If not logged in, let AuthMiddleware handle it
    if (!isLoggedIn) {
      return null;
    }

    // Define customer-only routes
    final customerRoutes = [
      AppRoutes.customerHome,
      AppRoutes.complaints,
      AppRoutes.referral,
      AppRoutes.profile,
      AppRoutes.kycReview,
      AppRoutes.bsnlPlans,
    ];

    // Define technician-only routes
    final technicianRoutes = [
      AppRoutes.technicianDashboard,
      AppRoutes.technicianProfile,
      AppRoutes.allTickets,
      AppRoutes.expenses,
      AppRoutes.notifications,
      AppRoutes.allCustomers,
      AppRoutes.customerDetails,
      AppRoutes.attendance,
    ];

    // Check if user is trying to access customer routes without customer role
    if (customerRoutes.contains(route) && userRole != 'customer') {
      return RouteSettings(name: AppRoutes.home);
    }

    // Check if user is trying to access technician routes without technician role
    if (technicianRoutes.contains(route) && userRole != 'technician') {
      return RouteSettings(name: AppRoutes.home);
    }

    return null;
  }
}

