// asia_fibernet_fixes/middleware/auth_middleware.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../sharedpref.dart';
import '../routes.dart'; // Import AppRoutes

class AuthMiddleware extends GetMiddleware {
  @override
  int get priority => 1;

  @override
  RouteSettings? redirect(String? route) {
    final isLoggedIn = AppSharedPref.instance.isUserLoggedIn();
    final userRole = AppSharedPref.instance.getRole();

    // Define auth routes that don't require authentication
    final isAuthRoute =
        route == AppRoutes.splash ||
        route == AppRoutes.login ||
        route == AppRoutes.otp ||
        route == AppRoutes.signup;

    // If user is logged in and trying to access auth routes, redirect to home
    if (isLoggedIn && isAuthRoute) {
      return RouteSettings(name: AppRoutes.home);
    }

    // If user is not logged in and trying to access protected routes, redirect to login
    if (!isLoggedIn && !isAuthRoute) {
      return RouteSettings(name: AppRoutes.login);
    }

    return null;
  }
}
