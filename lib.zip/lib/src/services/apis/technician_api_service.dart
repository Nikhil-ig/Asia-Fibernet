// services/apis/technician_api.dart
import 'dart:async';
import 'dart:convert';
import '../../auth/core/model/customer_details_model.dart';
import '../../technician/core/models/customer_model.dart';
import '../../technician/core/models/technician_profile_model.dart';
import '../../technician/core/models/tickets_model.dart';
import '../../technician/core/models/tech_dashboard_model.dart';
import '../../technician/ui/screens/notifications_screen.dart';
import '../utils/plugin/device_info_utils.dart';
import 'base_api_service.dart';

class TechnicianAPI extends BaseApiService {
  final BaseApiService _apiClient = BaseApiService(BaseApiService.apiTech);

  // Endpoints
  static const String _dashboard = "my_dashboard_tech.php";
  static const String _fetchAllTickets = "fetch_ticket_tech.php";
  static const String _fetchTicketByTicketNo =
      "fetch_ticket_by_ticketNo_tech.php";
  static const String _fetchAllCustomers = "fetch_all_customer_tech.php";
  static const String _fetchWireInstallationCustomers =
      "fetch_instlationCusts_tech.php";
  static const String _fetchWireInstallationCustomersDetails =
      "fetch_instlationCust_details_tech.php";

  static const String _fetchModemInstallationCustomers =
      "fetch_modem_instlationCusts_tech.php";
  static const String _fetchModemInstallationCustomersDetails =
      "fetch_instlationCust_details_tech.php";

  static const String _fetchCustomerSingle = "fetch_customer_single_tech.php";
  static const String _complaintClose = "complaint_close_by_tech.php";
  static const String _trackLocation = "track_location_tech.php";
  static const String _updateProfile = "update_my_profile_tech.php";
  static const String _getNotifications = "my_notification_tech.php";
  static const String _fetchProfile = "fetch_my_profile_tech.php";
  static const String _fetchKyc = "kyc_doc_tech.php";
  static const String _fetchCustomerByMobOrName =
      "fetch_customer_By_mobOrName_tech.php";
  static const String _createTicket = "create_tkt_for_customer.php";
  static const String _fetchOltIpList = "fetch_OLT_IP_List_tech.php";
  static const String _updateWireInstallation =
      "update_wire_installation_tech.php";

  // Expense
  static const String _addExpense = "add_expenses_tech.php";
  static const String _fetchExpenses = "fetch_expenses_tech.php";
  static const String _fetchExpenseDetails = "fetch_expenses_details.php";

  // Attendance
  static const String _punchIn = "punch_in_tech.php";
  static const String _punchOut = "punch_out_tech.php";
  static const String _fetchAttendance = "fetch_attendance_tech.php";
  static const String _fetchTodayAttendance = "fetch_today_attendance_tech.php";
  static const String _attendanceDashboard = "attandance_dashboard.php";

  // Leave
  static const String _applyLeave = "apply_leave_tech.php";
  static const String _fetchLeaves = "fetch_leaves_tech.php";
  static const String _cancelLeave = "cancel_leave_tech.php";

  // Other
  static const String _fetchMyRating = "fetch_my_rating_tech.php";
  static const String _fetchMyReferral = "fetch_my_referral_tech.php";
  static const String _fetchWorkArea = "fetch_work_area_tech.php";
  static const String _getLoginHistory = "get_login_history_tech.php";

  // ————————————————————————
  // 🔹 Dashboard & Profile
  // ————————————————————————

  Future<TechDashboardModel?> getDashboard() async {
    try {
      final res = await _apiClient.post(_dashboard);
      return _apiClient.handleResponse(
        res,
        (json) => TechDashboardModel.fromJson(json),
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) {
        _apiClient.unauthorized();
      }
      return null;
    }
  }

  Future<Map<String, dynamic>?> fetchProfile() async {
    try {
      final res = await _apiClient.post(_fetchProfile);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') {
          return json['data'];
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<TechnicianKycModel?> fetchKycDetails() async {
    try {
      final res = await _apiClient.post(_fetchKyc);
      return _apiClient.handleResponse(
        res,
        (json) => TechnicianKycModel.fromJson(json['data']),
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
      return null;
    }
  }

  Future<TechnicianProfileModel?> fetchUnifiedProfile() async {
    try {
      final profileData = await fetchProfile();
      if (profileData == null) return null;

      final baseProfile = TechnicianProfileModel.fromProfileData(profileData);
      final kycData = await fetchKycDetails();
      return kycData != null ? baseProfile.mergeWithKyc(kycData) : baseProfile;
    } catch (e, s) {
      _apiClient.logApiDebug(
        endpoint: 'fetchUnifiedProfile',
        method: 'COMBINED',
        error: e,
        stackTrace: s,
      );
      return null;
    }
  }

  Future<bool> updateProfile(Map<String, dynamic> body) async {
    try {
      final res = await _apiClient.post(_updateProfile, body: body);
      return _apiClient.handleSuccessResponse(
        res,
        "Profile updated successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) {
        _apiClient.unauthorized();
      }
      return false;
    }
  }

  // ————————————————————————
  // 🔹 Tickets
  // ————————————————————————

  Future<List<TicketModel>?> fetchAllTicketsWithFilter({
    String filter = 'all',
    String? startDate,
    String? endDate,
  }) async {
    final body = <String, dynamic>{'filter': filter, 'limit': 50};
    if (startDate != null) body['startDate'] = startDate;
    if (endDate != null) body['endDate'] = endDate;

    try {
      final res = await _apiClient.post(_fetchAllTickets, body: body);
      return _apiClient.handleListResponse(
        res,
        (item) => TicketModel.fromJson(item),
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
      return null;
    }
  }

  Future<TicketModel?> fetchTicketByTicketNo(String ticketNo) async {
    final body = {'ticket_no': ticketNo};
    try {
      final res = await _apiClient.post(_fetchTicketByTicketNo, body: body);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return TicketModel.fromJson(json['data']);
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<bool> closeComplaint({
    required String ticketNo,
    required String closedRemark,
  }) async {
    final body = {'ticket_no': ticketNo, 'closed_remark': closedRemark};
    try {
      final res = await _apiClient.post(_complaintClose, body: body);
      return _apiClient.handleSuccessResponse(
        res,
        "Ticket closed successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return false;
      return false;
    }
  }

  Future<bool> createTicket(Map<String, dynamic> ticketData) async {
    try {
      final res = await _apiClient.post(_createTicket, body: ticketData);
      return _apiClient.handleSuccessResponse(
        res,
        "Ticket created successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) {
        _apiClient.unauthorized();
      }
      return false;
    }
  }

  // ————————————————————————
  // 🔹 Customers
  // ————————————————————————

  Future<List<CustomerModel>?> fetchAllCustomers() async {
    try {
      final res = await _apiClient.get(_fetchAllCustomers);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('history')) {
          final List data = json['history'];
          return data.map((e) => CustomerModel.fromJson(e)).toList();
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return [];
  }

  Future<CustomerDetails?> fetchCustomerById(int findCustomerId) async {
    final body = {'find_customer_id': findCustomerId};
    try {
      final res = await _apiClient.post(_fetchCustomerSingle, body: body);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return CustomerDetails.fromJson(json['data']);
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<List<CustomerModel>?> searchCustomers(String query) async {
    try {
      final res = await _apiClient.post(
        _fetchCustomerByMobOrName,
        body: {"customer_mobOrName": query},
      );
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' &&
            json.containsKey('data') &&
            json['data'] is List) {
          final List data = json['data'];
          return data
              .where((item) => item is Map<String, dynamic>)
              .map((e) => CustomerModel.fromJson(e))
              .toList();
        }
        return [];
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return [];
  }

  // ————————————————————————
  // 🔹 Installation Customers
  // ————————————————————————

  Future<List<Map<String, dynamic>>?> fetchWireInstallationCustomers() async {
    try {
      final res = await _apiClient.get(_fetchWireInstallationCustomers);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;

        print("WireInstallationCustomersController result: $json");
        final List data = json['data'];
        return data.map((e) => Map<String, dynamic>.from(e)).toList();
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
    // return ;
  }

  Future<Map<String, dynamic>?> fetchWireInstallationCustomersDetails(
    int findCustomerId,
  ) async {
    final body = {'registration_id': findCustomerId};
    try {
      final res = await _apiClient.post(
        _fetchWireInstallationCustomersDetails,
        body: body,
      );
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == true) {
          return json; // Return full response: { "status": true, "customer": {...}, "wire_installation": {...} }
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<Map<String, dynamic>?> fetchOltIpList() async {
    try {
      final res = await _apiClient.get(_fetchOltIpList);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        // The API returns status:true and the lists at the top level
        if (json['status'] == true) {
          return json; // Return the full map
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<bool> updateWireInstallation(Map<String, dynamic> body) async {
    try {
      final res = await _apiClient.post(_updateWireInstallation, body: body);
      return _apiClient.handleSuccessResponse(
        res,
        "Wire installation updated successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) {
        _apiClient.unauthorized();
      }
      return false;
    }
  }

  Future<Map<String, dynamic>?> fetchModemInstallationCustomers() async {
    try {
      final res = await _apiClient.get(_fetchModemInstallationCustomers);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') {
          // final List data = json['history'];
          return json;
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<Map<String, dynamic>?> fetchModemInstallationCustomersDetails(
    int findCustomerId,
  ) async {
    final body = {'find_customer_id': findCustomerId};
    try {
      final res = await _apiClient.post(
        _fetchModemInstallationCustomersDetails,
        body: body,
      );
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') {
          // final List data = json['history'];
          return json;
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  // ————————————————————————
  // 🔹 Attendance
  // ————————————————————————

  // ————————————————————————
  // 🔹 Attendance (UPDATED)
  // ————————————————————————

  Future<bool> punchIn({
    // required String technicianId,
    // required String locationName,
    required String lat,
    required String lng,
    required String loginImageBase64, // ✅ ADD THIS
  }) async {
    // final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
    final body = {
      'in_lat': lat, 'in_long': lng,
      'login_image': loginImageBase64, // ✅ SEND IMAGE
      // ...deviceInfo,
    };
    try {
      final res = await _apiClient.post(_punchIn, body: body);
      return _apiClient.handleSuccessResponse(res, "Punched in successfully!");
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return false;
      return false;
    }
  }

  Future<bool> punchOut({
    // required String technicianId,
    // required String locationName,
    required String lat,
    required String lng,
    required String logoutImageBase64, // ✅ ADD THIS
  }) async {
    // final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
    final body = {
      'in_lat': lat, 'in_long': lng,
      'logout_image': logoutImageBase64, // ✅ SEND IMAGE
      // ...deviceInfo,
    };
    try {
      final res = await _apiClient.post(_punchOut, body: body);
      return _apiClient.handleSuccessResponse(res, "Punched out successfully!");
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return false;
      return false;
    }
  }

  Future<List<Map<String, dynamic>>?> fetchAttendance() async {
    try {
      final res = await _apiClient.post(_fetchAttendance);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return (json['data'] as List).cast<Map<String, dynamic>>();
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return [];
  }

  Future<Map<String, dynamic>?> fetchTodayAttendance() async {
    try {
      final res = await _apiClient.post(_fetchTodayAttendance);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') {
          return json['data'];
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<Map<String, dynamic>?> fetchAttendanceDashboard() async {
    try {
      final res = await _apiClient.post(_attendanceDashboard);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') {
          return json['data'];
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  // ————————————————————————
  // 🔹 Leave
  // ————————————————————————

  Future<bool> applyForLeave({
    required String startDate,
    required String endDate,
    required String leaveType,
    required String reason,
    String? attachments,
  }) async {
    final body = {
      'start_date': startDate,
      'end_date': endDate,
      'leave_type': leaveType,
      'reason': reason,
      if (attachments != null) 'attachments': attachments,
    };
    try {
      final res = await _apiClient.post(_applyLeave, body: body);
      return _apiClient.handleSuccessResponse(
        res,
        "Leave applied successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return false;
      return false;
    }
  }

  Future<List<Map<String, dynamic>>?> fetchLeaves() async {
    try {
      final res = await _apiClient.post(_fetchLeaves);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return (json['data'] as List).cast<Map<String, dynamic>>();
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return [];
  }

  Future<bool> cancelLeave(int leaveId) async {
    final body = {'leave_id': leaveId};
    try {
      final res = await _apiClient.post(_cancelLeave, body: body);
      return _apiClient.handleSuccessResponse(
        res,
        "Leave cancelled successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return false;
      return false;
    }
  }

  // ————————————————————————
  // 🔹 Expenses
  // ————————————————————————

  Future<bool> addExpense({
    required String expenseTitle,
    required double amount,
    required String expenseDate,
    required String image, // base64
    required String paymentMode,
    required String expenseCategory,
    String? description,
    String? remark,
  }) async {
    final body = {
      'expense_title': expenseTitle,
      'amount': amount,
      'expense_date': expenseDate,
      'image': image,
      'payment_mode': paymentMode,
      'status': 'Pending',
      'expense_category': expenseCategory,
      if (description != null) 'description': description,
      if (remark != null) 'remark': remark,
    };
    try {
      final res = await _apiClient.post(_addExpense, body: body);
      return _apiClient.handleSuccessResponse(
        res,
        "Expense added successfully!",
      );
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) {
        _apiClient.unauthorized();
      }
      return false;
    }
  }

  Future<List<Map<String, dynamic>>?> fetchExpenses() async {
    try {
      final res = await _apiClient.post(_fetchExpenses);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return (json['data'] as List).cast<Map<String, dynamic>>();
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return [];
  }

  Future<Map<String, dynamic>?> fetchExpenseDetails(int expenseId) async {
    final body = {'id': expenseId};
    try {
      final res = await _apiClient.post(_fetchExpenseDetails, body: body);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return json['data'];
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  // ————————————————————————
  // 🔹 Others
  // ————————————————————————

  Future<Map<String, dynamic>?> fetchMyRating() async {
    try {
      final res = await _apiClient.post(_fetchMyRating);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') return json['data'];
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<Map<String, dynamic>?> fetchMyReferral() async {
    try {
      final res = await _apiClient.post(_fetchMyReferral);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') return json['data'];
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<Map<String, dynamic>?> fetchWorkArea() async {
    try {
      final res = await _apiClient.post(_fetchWorkArea);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success') return json['data'];
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return null;
  }

  Future<List<Map<String, dynamic>>?> getLoginHistory() async {
    try {
      final res = await _apiClient.post(_getLoginHistory);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          return (json['data'] as List).cast<Map<String, dynamic>>();
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return null;
    }
    return [];
  }

  Future<List<NotificationData>?> getNotifications() async {
    try {
      final res = await _apiClient.get(_getNotifications);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['status'] == 'success' && json.containsKey('data')) {
          final List data = json['data'];
          return data
              .where((item) => item is Map<String, dynamic>)
              .map((e) => NotificationData.fromJson(e))
              .toList();
        }
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) {
        _apiClient.unauthorized();
      }
    }
    return [];
  }

  // ————————————————————————
  // 🔹 Location Tracking
  // ————————————————————————

  Future<bool> trackLocation({
    required String technicianId,
    required String date,
    required String sessionDatetime,
    required String locationName,
    required String lat,
    required String lng,
  }) async {
    final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
    final body = {
      'technician_id': technicianId,
      'date': date,
      'session_datetime': sessionDatetime,
      'location': {'location_name': locationName, 'lat': lat, 'lng': lng},
      ...deviceInfo,
    };
    try {
      final res = await _apiClient.post(_trackLocation, body: body);
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        return json['status'] == 'success';
      }
    } catch (e) {
      if (e.toString().contains('Unauthorized: No token')) return false;
    }
    return false;
  }
}
