// screens/dashboard/dashboard_screen.dart
import 'dart:math' as math;
import 'dart:ui';

import 'package:asia_fibernet/src/services/apis/api_services.dart';
import 'package:asia_fibernet/src/services/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:animate_do/animate_do.dart';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:shimmer/shimmer.dart';
import 'package:iconsax/iconsax.dart';
import '../../../services/apis/technician_api_service.dart';
import '../../../theme/colors.dart';
import '../../../theme/theme.dart';
import '../../core/models/tech_dashboard_model.dart';
import '../../attendance/attendance_screen.dart';
import 'notifications_screen.dart';
import 'technician_profile_screen.dart';

// Model for recent tickets (simplified)
class RecentTicket {
  final String ticketNo;
  final String category;
  final String status;
  final String createdAt;

  RecentTicket({
    required this.ticketNo,
    required this.category,
    required this.status,
    required this.createdAt,
  });
}

class TechnicianDashboardScreen extends StatefulWidget {
  const TechnicianDashboardScreen({super.key});

  @override
  State<TechnicianDashboardScreen> createState() =>
      _TechnicianDashboardScreenState();
}

class _TechnicianDashboardScreenState extends State<TechnicianDashboardScreen> {
  final TechnicianAPI _api = TechnicianAPI();
  AttendanceController attendanceController = AttendanceController();
  TechDashboardModel? _dashboard;
  List<RecentTicket> _recentTickets = [];
  bool _loading = true;
  int _notificationCount = 0; // Example notification count

  late TooltipBehavior _tooltipBehavior;

  @override
  void initState() {
    super.initState();
    _tooltipBehavior = TooltipBehavior(enable: true);
    _loadDashboard();
  }

  Future<void> _loadDashboard() async {
    try {
      final result = await _api.getDashboard();
      attendanceController.loadEvents();
      if (result == null) {
        Get.snackbar("Error", "Failed to load dashboard data");
      }
      setState(() {
        _dashboard = result;
        _loading = false;
      });

      if (result != null) {
        _recentTickets = [
          RecentTicket(
            ticketNo: 'TKT-001234',
            category: 'Call Drops',
            status: 'Closed',
            createdAt: '2025-08-28',
          ),
          RecentTicket(
            ticketNo: 'TKT-001235',
            category: 'No Internet',
            status: 'Open',
            createdAt: '2025-08-29',
          ),
          RecentTicket(
            ticketNo: 'TKT-001236',
            category: 'Slow Speed',
            status: 'Closed',
            createdAt: '2025-08-30',
          ),
        ];
      }
    } catch (e) {
      setState(() {
        _loading = false;
      });
      Get.snackbar("Error", "Exception: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: Stack(
        children: [
          // Decorative elements
          Positioned(
            top: -30,
            right: -20,
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 100,
            left: -40,
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
            ),
          ),

          RefreshIndicator(
            onRefresh: _loadDashboard,
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  title: FadeIn(
                    duration: const Duration(milliseconds: 600),
                    child: Text(
                      "Dashboard",
                      style: AppText.headingMedium.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(
                            blurRadius: 4.0,
                            color: Colors.black.withOpacity(0.2),
                            offset: const Offset(1.0, 1.0),
                          ),
                        ],
                      ),
                    ),
                  ),
                  centerTitle: true,
                  pinned: true,
                  foregroundColor: Colors.white,
                  iconTheme: const IconThemeData(color: Colors.white),
                  actions: [
                    FadeInRight(
                      duration: const Duration(milliseconds: 800),
                      child: Badge(
                        label: Text(
                          _notificationCount.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        alignment: Alignment.topRight.add(
                          const Alignment(-.5, .3),
                        ),
                        largeSize: 25,
                        smallSize: 25,
                        child: IconButton(
                          icon: const Icon(Iconsax.notification, size: 24),
                          onPressed: () => Get.to(() => NotificationScreen()),
                        ),
                      ),
                    ),
                  ],
                  flexibleSpace: FlexibleSpaceBar(
                    background: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppColors.primary, AppColors.primaryDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          stops: [0.1, 0.9],
                        ),
                      ),
                    ),
                  ),
                ),

                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child:
                        _loading
                            ? _buildShimmerDashboard()
                            : _dashboard == null
                            ? Center(
                              child: Text(
                                "Failed to load dashboard",
                                style: AppText.bodyMedium,
                              ),
                            )
                            : _buildDashboardContent(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(),
    );
  }

  Widget _buildDashboardContent() {
    final data = _dashboard?.data;
    _notificationCount = data?.notifications.totalNotifications ?? 0;
    if (data == null) {
      return Center(
        child: Text("No dashboard data available", style: AppText.bodyMedium),
      );
    }

    return Column(
      children: [
        // Profile Card
        FadeInUp(
          duration: const Duration(milliseconds: 600),
          child: GestureDetector(
            onTap: () => Get.to(() => TechnicianProfileScreen()),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 15,
                    spreadRadius: 2,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Stack(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  AppColors.primary,
                                  AppColors.primaryDark,
                                ],
                              ),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Iconsax.profile_2user,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              width: 18,
                              height: 18,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    const Color.fromARGB(255, 154, 249, 159),
                                    const Color.fromARGB(255, 37, 175, 44),
                                  ],
                                ),
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              data.contactName,
                              style: AppText.headingMedium.copyWith(
                                fontWeight: FontWeight.bold,
                                color: AppColors.textColorPrimary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "ID: ${data.accountId ?? 'N/A'} • ${data.city}, ${data.state}",
                              style: AppText.bodySmall.copyWith(
                                color: AppColors.textColorSecondary,
                              ),
                            ),
                            Text(
                              data.email ?? "N/A",
                              style: AppText.bodySmall.copyWith(
                                color: AppColors.textColorSecondary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              data.workphnumber ?? "N/A",
                              style: AppText.bodySmall.copyWith(
                                color: AppColors.textColorSecondary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  //   const SizedBox(height: 16),
                  //   const Divider(color: AppColors.dividerColor),
                  //   const SizedBox(height: 16),
                  //   Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceAround,
                  //     children: [
                  //       _miniStat(
                  //         Iconsax.call,
                  //         data.cellphnumber ?? 'N/A',
                  //         "Mobile",
                  //       ),
                  //       _miniStat(Iconsax.sms, "Email", "Contact"),
                  //       _miniStat(Iconsax.location, data.city, "Location"),
                  //     ],
                  //   ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        FadeInUp(
          delay: const Duration(milliseconds: 300),
          duration: const Duration(milliseconds: 800),
          child: _buildPunchCard(),
        ),
        const SizedBox(height: 20),

        // Stats Grid
        FadeInUp(
          delay: const Duration(milliseconds: 500),
          duration: const Duration(milliseconds: 1000),
          child: GridView.count(
            padding: EdgeInsets.all(0),
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 1.2,
            children: [
              _statCard(
                "Open Tickets",
                data.tickets.openTickets ?? '0',
                Iconsax.clock,
                AppColors.warning,
              ),
              _statCard(
                "Closed Tickets",
                data.tickets.closedTickets ?? '0',
                Iconsax.tick_circle,
                AppColors.success,
              ),
              _statCard(
                "Total Tickets",
                data.tickets.totalTickets.toString(),
                Iconsax.receipt,
                AppColors.info,
              ),
              _statCard(
                "Avg Rating",
                "${data.ratings.avgRating?.substring(0, math.min(3, data.ratings.avgRating?.length ?? 0)) ?? 'N/A'} ⭐",
                Iconsax.star,
                AppColors.accent1,
              ),
            ],
          ),
        ),

        // // Recent Tickets Header
        // FadeInUp(
        //   duration: const Duration(milliseconds: 1200),
        //   child: Row(
        //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //     children: [
        //       Padding(
        //         padding: const EdgeInsets.symmetric(vertical: 28.0),
        //         child: Text(
        //           "Recent Tickets",
        //           style: AppText.headingSmall.copyWith(
        //             fontWeight: FontWeight.bold,
        //             color: AppColors.textColorPrimary,
        //           ),
        //         ),
        //       ),
        //       Row(
        //         children: [
        //           IconButton(
        //             icon: const Icon(Iconsax.eye, color: AppColors.primary),
        //             onPressed: () => Get.to(() => AllTicketsScreen()),
        //             tooltip: "View All Tickets",
        //           ),
        //           IconButton(
        //             icon: const Icon(
        //               Iconsax.document_download,
        //               color: Colors.red,
        //             ),
        //             onPressed: _exportToPdf,
        //             tooltip: "Export as PDF",
        //           ),
        //         ],
        //       ),
        //     ],
        //   ),
        // ),

        // // Recent Tickets List
        // FadeInUp(
        //   duration: const Duration(milliseconds: 1400),
        //   child: ListView.separated(
        //     padding: EdgeInsets.all(0),
        //     shrinkWrap: true,
        //     physics: const NeverScrollableScrollPhysics(),
        //     itemCount: _recentTickets.length,
        //     separatorBuilder: (_, __) => const SizedBox(height: 12),
        //     itemBuilder: (context, index) {
        //       final ticket = _recentTickets[index];
        //       final statusColor = _getStatusColor(ticket.status);

        //       return Container(
        //         padding: const EdgeInsets.all(16),
        //         decoration: BoxDecoration(
        //           color: Colors.white,
        //           borderRadius: BorderRadius.circular(16),
        //           boxShadow: [
        //             BoxShadow(
        //               color: Colors.black.withOpacity(0.05),
        //               blurRadius: 10,
        //               spreadRadius: 2,
        //             ),
        //           ],
        //         ),
        //         child: Row(
        //           children: [
        //             Container(
        //               width: 40,
        //               height: 40,
        //               decoration: BoxDecoration(
        //                 color: statusColor.withOpacity(0.1),
        //                 borderRadius: BorderRadius.circular(12),
        //               ),
        //               child: Icon(
        //                 _getStatusIcon(ticket.status),
        //                 color: statusColor,
        //                 size: 20,
        //               ),
        //             ),
        //             const SizedBox(width: 16),
        //             Expanded(
        //               child: Column(
        //                 crossAxisAlignment: CrossAxisAlignment.start,
        //                 children: [
        //                   Text(
        //                     ticket.ticketNo,
        //                     style: AppText.bodyMedium.copyWith(
        //                       fontWeight: FontWeight.bold,
        //                       color: AppColors.textColorPrimary,
        //                     ),
        //                   ),
        //                   const SizedBox(height: 4),
        //                   Text(
        //                     ticket.category,
        //                     style: AppText.bodySmall.copyWith(
        //                       color: AppColors.textColorSecondary,
        //                     ),
        //                   ),
        //                   const SizedBox(height: 4),
        //                   Text(
        //                     _formatDate(ticket.createdAt),
        //                     style: AppText.bodySmall.copyWith(
        //                       color: AppColors.textColorSecondary,
        //                       fontSize: 12,
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             ),
        //             Container(
        //               padding: const EdgeInsets.symmetric(
        //                 horizontal: 12,
        //                 vertical: 6,
        //               ),
        //               decoration: BoxDecoration(
        //                 color: statusColor.withOpacity(0.1),
        //                 borderRadius: BorderRadius.circular(20),
        //                 border: Border.all(color: statusColor),
        //               ),
        //               child: Text(
        //                 ticket.status,
        //                 style: TextStyle(
        //                   color: statusColor,
        //                   fontSize: 12,
        //                   fontWeight: FontWeight.bold,
        //                 ),
        //               ),
        //             ),
        //           ],
        //         ),
        //       );
        //     },
        //   ),
        // ),
        const SizedBox(height: 40),
      ],
    );
  }

  Widget _miniStat(IconData icon, String value, String label) {
    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppColors.primary.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 18, color: AppColors.primary),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: AppText.bodyMedium.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.textColorPrimary,
          ),
        ),
        Text(
          label,
          style: AppText.bodySmall.copyWith(
            color: AppColors.textColorSecondary,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 12),
          Text(
            label,
            style: AppText.bodySmall.copyWith(
              color: AppColors.textColorSecondary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerDashboard() {
    return Column(
      children: [
        // Profile Card Shimmer
        Shimmer.fromColors(
          baseColor: Colors.grey[300]!,
          highlightColor: Colors.grey[100]!,
          child: Container(
            height: 180,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Stats Grid Shimmer
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 15,
          mainAxisSpacing: 15,
          childAspectRatio: 1.2,
          children: List.generate(
            4,
            (index) => Shimmer.fromColors(
              baseColor: Colors.grey[300]!,
              highlightColor: Colors.grey[100]!,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDrawer() {
    final data = _dashboard?.data;
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.backgroundLight,
              AppColors.backgroundLight.withOpacity(0.8),
            ],
          ),
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.primary, AppColors.primaryDark],
                ),
              ),
              child:
                  data != null
                      ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Iconsax.profile_2user,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            data.contactName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            data.workphnumber ?? 'N/A',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      )
                      : const Center(
                        child: CircularProgressIndicator(color: Colors.white),
                      ),
            ),
            _drawerItem(Iconsax.home, "Dashboard", () => Get.back()),
            _drawerItem(
              Iconsax.receipt,
              "All Tickets",
              () => Get.toNamed(AppRoutes.allTickets),
            ),
            _drawerItem(
              Iconsax.profile_add,
              "Profile",
              () => Get.toNamed(AppRoutes.technicianProfile),
            ),
            _drawerItem(
              Iconsax.activity,
              "Raise Ticket",
              () => Get.toNamed(AppRoutes.allCustomers),
            ),
            _drawerItem(
              Iconsax.calendar,
              "Attendance",
              () => Get.toNamed(AppRoutes.attendance),
            ),
            _drawerItem(
              Iconsax.strongbox,
              "Expenses",
              () => Get.toNamed(AppRoutes.expenses),
            ),
            _drawerItem(
              Iconsax.wifi_square,
              "Wire Installation",
              () => Get.toNamed(AppRoutes.wireInstallation),
            ),
            _drawerItem(
              Iconsax.box,
              "Modem Installation",
              () => Get.toNamed(AppRoutes.modemInstallation),
            ),
            _drawerItem(
              Iconsax.share,
              "Referral",
              () => Get.toNamed(AppRoutes.referral),
            ),
            const Divider(color: AppColors.dividerColor),
            _drawerItem(Iconsax.logout, "Logout", () async {
              await ApiServices().logOutDialog();
            }, color: Colors.red),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem(
    IconData icon,
    String title,
    VoidCallback onTap, {
    Color? color,
  }) {
    return ListTile(
      leading: Icon(icon, color: color ?? AppColors.primary),
      title: Text(
        title,
        style: AppText.bodyMedium.copyWith(
          color: color ?? AppColors.textColorPrimary,
        ),
      ),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 24),
    );
  }

  Color _getStatusColor(String status) {
    final s = status.toLowerCase();
    if (s.contains('open')) return AppColors.warning;
    if (s.contains('assign')) return AppColors.info;
    if (s.contains('close') || s.contains('resolve')) return AppColors.success;
    return AppColors.textColorSecondary;
  }

  IconData _getStatusIcon(String status) {
    final s = status.toLowerCase();
    if (s.contains('open')) return Iconsax.clock;
    if (s.contains('assign')) return Iconsax.user_tick;
    if (s.contains('close') || s.contains('resolve'))
      return Iconsax.tick_circle;
    return Iconsax.info_circle;
  }

  String _formatDate(String dateTimeStr) {
    try {
      final DateTime date = DateTime.parse(dateTimeStr);
      return DateFormat('MMM dd, yyyy').format(date);
    } catch (e) {
      return dateTimeStr;
    }
  }

  Future<void> _exportToPdf() async {
    final data = _dashboard?.data;
    if (data == null) {
      Get.snackbar("Error", "No data to export");
      return;
    }

    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build:
            (context) => pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  "Technician Dashboard Report",
                  style: pw.TextStyle(
                    fontSize: 20,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
                pw.SizedBox(height: 20),
                pw.Text("Technician: ${data.contactName}"),
                pw.Text("ID: ${data.accountId ?? 'N/A'}"),
                pw.Text("City: ${data.city}"),
                pw.SizedBox(height: 20),
                pw.Text(
                  "Stats",
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                ),
                pw.Text("Open Tickets: ${data.tickets.openTickets ?? '0'}"),
                pw.Text("Closed Tickets: ${data.tickets.closedTickets ?? '0'}"),
                pw.Text("Total Tickets: ${data.tickets.totalTickets}"),
                pw.Text("Average Rating: ${data.ratings.avgRating ?? 'N/A'} ⭐"),
                pw.SizedBox(height: 20),
                pw.Text(
                  "Recent Tickets",
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                ),
                ..._recentTickets.map(
                  (t) => pw.Text("${t.ticketNo} - ${t.category} (${t.status})"),
                ),
              ],
            ),
      ),
    );

    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  // Inside attendance_screen.dart

  Widget _buildPunchCard() {
    return Obx(() {
      // Find today's events using a UTC DateTime key for consistency
      final today = DateTime.now();
      // Create the key using UTC, matching how events are stored in the controller
      final todayKey = DateTime.utc(today.year, today.month, today.day);
      // Use the UTC key to look up events
      final todayEvents = attendanceController.events[todayKey] ?? [];

      // Find the first attendance event for today (if any)
      // Default to 'Not Punched' if no attendance event is found for today
      final todayAttendance = todayEvents.firstWhere(
        (e) => e.type == 'attendance',
        orElse:
            () => AttendanceEvent(
              type: 'attendance',
              status: 'Not Punched',
              // You might want to initialize other fields like punchIn/punchOut to null explicitly
              punchIn: null,
              punchOut: null,
            ),
      );

      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 15,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20.r),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(20.w),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.9),
                borderRadius: BorderRadius.circular(20.r),
                border: Border.all(
                  color: Colors.white.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Column(
                children: [
                  Text(
                    "Today's Status",
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textColorPrimary,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildPunchStatus(
                        "Punch In",
                        todayAttendance.punchIn ?? "--:--",
                        Iconsax.login_1,
                        todayAttendance.punchIn != null
                            ? Color(0xFF10B981) // Green if punched in
                            : AppColors.textColorSecondary, // Grey if not
                      ),
                      Container(
                        width: 1.w,
                        height: 40.h,
                        color: Colors.grey[200],
                      ),
                      _buildPunchStatus(
                        "Punch Out",
                        todayAttendance.punchOut ?? "--:--",
                        Iconsax.logout,
                        todayAttendance.punchOut != null &&
                                todayAttendance.punchOut != 'On Duty'
                            ? Color(0xFF10B981) // Green if punched out (normal)
                            : todayAttendance.punchOut == 'On Duty'
                            ? Color(0xFF3B82F6) // Blue if 'On Duty'
                            : Color(0xFFEF4444), // Red if not punched out
                      ),
                    ],
                  ),
                  SizedBox(height: 20.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      if (todayAttendance.punchIn == null)
                        _buildPunchButton(
                          "Punch IN",
                          Iconsax.login_1,
                          Color(0xFF10B981),
                          () => attendanceController.punchInOut(),
                          "Start your day",
                        )
                      else if (todayAttendance.punchOut == null)
                        _buildPunchButton(
                          "Punch OUT",
                          Iconsax.logout,
                          Color(0xFFEF4444),
                          () => attendanceController.punchInOut(),
                          "End your day",
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }

  Widget _buildPunchButton(
    String label,
    IconData icon,
    Color color,
    VoidCallback onPressed,
    String tooltip,
  ) {
    return Obx(
      () => Tooltip(
        message: tooltip,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.r),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: ElevatedButton.icon(
            onPressed: attendanceController.isPunching.value ? null : onPressed,
            icon: Icon(icon, size: 20.w, color: Colors.white),
            label: Text(
              label,
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: color,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              elevation: 0,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPunchStatus(
    String label,
    String time,
    IconData icon,
    Color color,
  ) {
    return Column(
      children: [
        Icon(icon, size: 24.w, color: color),
        SizedBox(height: 8.h),
        Text(
          label,
          style: TextStyle(
            fontSize: 12.sp,
            color: AppColors.textColorSecondary,
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          time,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: AppColors.textColorPrimary,
          ),
        ),
      ],
    );
  }
}

// Data for chart (optional — commented out for now)
class ChartData {
  final String week;
  final int tickets;

  ChartData(this.week, this.tickets);
}
