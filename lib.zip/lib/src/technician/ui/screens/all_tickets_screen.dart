// screens/tickets/all_tickets_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:iconsax/iconsax.dart';
import 'package:shimmer/shimmer.dart';

import '../../../services/apis/technician_api_service.dart';
import '../../../services/sharedpref.dart';
import '../../../theme/colors.dart';
import '../../../theme/theme.dart';
import '../../core/models/tickets_model.dart';
import 'customer_detail_screen.dart';

class AllTicketsController extends GetxController {
  final apiServices = TechnicianAPI();
  final tickets = <TicketModel>[].obs;
  final isLoading = true.obs;
  final filter = 'All'.obs; // Legacy — not used in filtering anymore
  final searchQuery = ''.obs;
  final TextEditingController remarkCtrl = TextEditingController();

  // Composable Filters
  final RxBool isMyTicketsActive = false.obs;
  final RxString statusFilter = 'All'.obs; // All, Open, Assigned, Closed
  final RxBool isDateFilterActive = false.obs;
  final Rx<DateTime> selectedStartDate =
      DateTime.now().subtract(const Duration(days: 7)).obs;
  final Rx<DateTime> selectedEndDate = DateTime.now().obs;

  // Keep for dialog convenience
  List<String> get filters => [
    'All',
    'My Tickets',
    'Open',
    'Assigned',
    'Closed',
    'By Date',
  ];

  @override
  void onInit() {
    super.onInit();
    fetchTickets();
  }

  // 👇 NEW: Clear ALL filters at once
  void clearAllFilters() {
    isMyTicketsActive.value = false;
    statusFilter.value = 'All';
    isDateFilterActive.value = false;
    searchQuery.value = '';
    Get.snackbar(
      "Filters Cleared",
      "All filters and search have been reset.",
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: AppColors.primary,
      colorText: Colors.white,
      icon: Icon(Iconsax.refresh, color: Colors.white),
    );
  }

  Future<void> fetchTickets() async {
    isLoading.value = true;
    try {
      // 👇 Map UI state to API filter names EXACTLY as in your PHP
      String apiFilter;
      if (isDateFilterActive.value) {
        apiFilter = 'byDate';
      } else if (isMyTicketsActive.value) {
        if (statusFilter.value == 'Open') {
          apiFilter = 'myOpenTickets';
        } else if (statusFilter.value == 'Closed') {
          apiFilter = 'myClosedTickets';
        } else {
          apiFilter = 'myTickets';
        }
      } else {
        if (statusFilter.value == 'Open') {
          apiFilter = 'openTickets';
        } else if (statusFilter.value == 'Closed') {
          apiFilter = 'closeTickets';
        } else {
          apiFilter = 'all';
        }
      }

      // 👇 Call API with mapped filter
      final result = await apiServices.fetchAllTicketsWithFilter(
        filter: apiFilter,
        startDate:
            isDateFilterActive.value
                ? DateFormat('yyyy-MM-dd').format(selectedStartDate.value)
                : null,
        endDate:
            isDateFilterActive.value
                ? DateFormat('yyyy-MM-dd').format(selectedEndDate.value)
                : null,
      );

      if (result != null) {
        tickets.assignAll(result);
      }
    } catch (e) {
      Get.snackbar("Error", "Failed to load tickets: $e");
    } finally {
      isLoading.value = false;
    }
  }

  // Replace your complex filteredTickets with:
  List<TicketModel> get filteredTickets {
    // Search is still local (PHP doesn't support it yet)
    if (searchQuery.isEmpty) return tickets;
    final query = searchQuery.value.toLowerCase();
    return tickets
        .where((t) {
          return t.ticketNo.toLowerCase().contains(query) ||
              (t.technician?.toLowerCase() ?? '').contains(query) ||
              t.createdAt.toLowerCase().contains(query);
        })
        .toList()
        .obs;
  }

  // Updated to use composable flags
  // List<TicketModel> get filteredTickets {
  //   var result = tickets;

  //   // Apply "My Tickets" filter
  //   if (isMyTicketsActive.value) {
  //     final currentUserId = AppSharedPref.instance.getUserID();
  //     result = result.where((t) => t.assignTo == currentUserId).toList().obs;
  //   }

  //   // Apply status filter
  //   if (statusFilter.value != 'All') {
  //     result =
  //         result
  //             .where((t) {
  //               final status = t.status.toLowerCase();
  //               if (statusFilter.value == 'Open') return status == 'open';
  //               if (statusFilter.value == 'Assigned')
  //                 return status == 'assigned';
  //               if (statusFilter.value == 'Closed') {
  //                 return status.contains('closed') || status == 'resolved';
  //               }
  //               return false;
  //             })
  //             .toList()
  //             .obs;
  //   }

  //   // Apply date filter
  //   if (isDateFilterActive.value) {
  //     final start = selectedStartDate.value.startOfDay;
  //     final end = selectedEndDate.value.endOfDay;
  //     result =
  //         result
  //             .where((t) {
  //               try {
  //                 final ticketDate = DateTime.parse(t.createdAt).startOfDay;
  //                 return !ticketDate.isBefore(start) &&
  //                     !ticketDate.isAfter(end);
  //               } catch (e) {
  //                 return false;
  //               }
  //             })
  //             .toList()
  //             .obs;
  //   }

  //   // Apply search
  //   if (searchQuery.isNotEmpty) {
  //     final query = searchQuery.value.toLowerCase();
  //     result =
  //         result
  //             .where(
  //               (t) =>
  //                   t.ticketNo.toLowerCase().contains(query) ||
  //                   (t.technician?.toLowerCase() ?? '').contains(query) ||
  //                   t.createdAt.toLowerCase().contains(query),
  //             )
  //             .toList()
  //             .obs;
  //   }

  //   return result;
  // }

  // Inside TechnicianAPI class

  // Helper extension for date range
  // date_extensions.dart

  Future<void> showDateFilterDialog(context) async {
    await Get.dialog(
      Obx(
        () => AlertDialog(
          title: Text("Filter by Date", style: AppText.headingMedium),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Iconsax.calendar, color: AppColors.primary),
                title: Text("Start Date"),
                subtitle: Text(
                  DateFormat('MMM dd, yyyy').format(selectedStartDate.value),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: Get.context!,
                    initialDate: selectedStartDate.value,
                    firstDate: DateTime(2000),
                    lastDate: DateTime.now(),
                  );
                  if (picked != null) {
                    selectedStartDate.value = picked;
                  }
                },
              ),
              ListTile(
                leading: Icon(Iconsax.calendar, color: AppColors.primary),
                title: Text("End Date"),
                subtitle: Text(
                  DateFormat('MMM dd, yyyy').format(selectedEndDate.value),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: Get.context!,
                    initialDate: selectedEndDate.value,
                    firstDate: selectedStartDate.value,
                    lastDate: DateTime.now(),
                  );
                  if (picked != null) {
                    selectedEndDate.value = picked;
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text(
                "Cancel",
                style: TextStyle(color: AppColors.textColorSecondary),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                isDateFilterActive.value = true;
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
              ),
              child: Text(
                "Apply Filter",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void clearDateFilter() {
    isDateFilterActive.value = false;
    selectedStartDate.value = DateTime.now().subtract(const Duration(days: 7));
    selectedEndDate.value = DateTime.now();
  }

  // Future<void> fetchTickets() async {
  //   isLoading.value = true;
  //   try {
  //     final result = await apiServices.fetchAllTickets();
  //     if (result != null) {
  //       tickets.assignAll(result);
  //     }
  //   } catch (e) {
  //     Get.snackbar(
  //       "Error",
  //       "Failed to load tickets: $e",
  //       snackPosition: SnackPosition.BOTTOM,
  //       backgroundColor: AppColors.error,
  //       colorText: Colors.white,
  //     );
  //   } finally {
  //     isLoading.value = false;
  //   }
  // }

  void showTicketDetails(context, TicketModel ticket, int customerId) async {
    print(ticket.assignTo);
    print(
      "AppSharedPref.instance.getUserID: ${AppSharedPref.instance.getUserID()}",
    );
    Get.bottomSheet(
      ignoreSafeArea: true,
      _buildTicketDetailsBottomSheet(context, null),

      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
    );

    final fullTicket = await apiServices.fetchTicketByTicketNo(ticket.ticketNo);

    if (Get.isBottomSheetOpen!) Navigator.pop(context);

    if (fullTicket != null) {
      Get.bottomSheet(
        _buildTicketDetailsBottomSheet(
          context,
          fullTicket,
          customerId,
          ticket.assignTo,
        ),
        isScrollControlled: true,
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
      );
    }
  }

  Widget _buildTicketDetailsBottomSheet(
    context,
    TicketModel? ticket, [
    int? customerId,
    int? assignTo,
  ]) {
    if (ticket == null) {
      return _buildSkeletonLoader();
    }
    // final isLoading = false.obs;
    // final remarkCtrl = TextEditingController(text: ticket.closedRemark ?? "");
    return Container(
      constraints: BoxConstraints(maxHeight: Get.size.height * .85),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(Get.context!).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Ticket Details",
                    style: AppText.headingMedium.copyWith(
                      color: AppColors.textColorPrimary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Iconsax.close_circle,
                      color: AppColors.textColorSecondary,
                    ),
                    onPressed: () => Get.back(),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: () {
                      // Assuming you have the customerId
                      print("ticket.customerId! ${ticket.customerId}");
                      int customerId =
                          ticket
                              .customerId!; // Or customer.id based on your CustomerModel
                      Get.to(
                        () => const CustomerDetailsScreen(),
                        arguments: {'customerId': customerId},
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.backgroundLight,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.dividerColor),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _detailRow(
                            Iconsax.receipt,
                            "Ticket No",
                            ticket.ticketNo,
                          ),
                          SizedBox(height: 12),
                          _detailRow(
                            Iconsax.status,
                            "Status",
                            ticket.status,
                            valueColor: _getStatusColor(ticket.status),
                          ),
                          SizedBox(height: 12),
                          _detailRow(
                            Iconsax.calendar,
                            "Created",
                            _formatDate(ticket.createdAt),
                          ),
                          if (ticket.updatedAt != null) ...[
                            SizedBox(height: 12),
                            _detailRow(
                              Iconsax.refresh,
                              "Updated",
                              _formatDate(ticket.updatedAt!),
                            ),
                          ],
                          if (ticket.customerMobileNo != null) ...[
                            SizedBox(height: 12),
                            _detailRow(
                              Iconsax.call,
                              "Customer",
                              ticket.customerMobileNo!,
                            ),
                          ],
                          if (ticket.technicianName != null) ...[
                            SizedBox(height: 12),
                            _detailRow(
                              Iconsax.user,
                              "Assigned To",
                              ticket.technicianName!,
                            ),
                          ],
                          if (ticket.closedAt != null) ...[
                            SizedBox(height: 12),
                            _detailRow(
                              Iconsax.tick_circle,
                              "Closed On",
                              _formatDate(ticket.closedAt!),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  if (ticket.description != null)
                    _section("Issue Description", ticket.description!),
                  SizedBox(height: 16),
                  if (ticket.image != null)
                    _buildImagePreview(ticket.fullImageUrl!),
                  SizedBox(height: 20),
                  if (ticket.isOpen) ...[
                    Text(
                      "Resolution Details",
                      style: AppText.bodyLarge.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.textColorPrimary,
                      ),
                    ),
                    SizedBox(height: 12),
                    TextField(
                      controller: remarkCtrl,
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: "Describe how the issue was resolved...",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: AppColors.dividerColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: AppColors.dividerColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: AppColors.primary,
                            width: 2,
                          ),
                        ),
                        filled: true,
                        fillColor: AppColors.inputBackground,
                        contentPadding: EdgeInsets.all(16),
                      ),
                    ),
                    SizedBox(height: 20),
                    if (ticket.closedAt == null)
                      if (assignTo == AppSharedPref.instance.getUserID())
                        Obx(
                          () => SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed:
                                  isLoading.value
                                      ? null
                                      : () => _sendOtpAndClose(
                                        context,
                                        ticket,
                                        remarkCtrl.text.trim(),
                                      ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.success,
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 2,
                              ),
                              child:
                                  isLoading.value
                                      ? SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2,
                                        ),
                                      )
                                      : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Iconsax.tick_circle,
                                            size: 20,
                                            color: Colors.white,
                                          ),
                                          SizedBox(width: 8),
                                          Text(
                                            "Close Ticket",
                                            style: AppText.button.copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                            ),
                          ),
                        ),
                  ] else ...[
                    if (ticket.closedRemark != null)
                      _section("Resolution Note", ticket.closedRemark!),
                  ],
                  SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, String content) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.backgroundLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.dividerColor.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: AppText.bodyMedium.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textColorPrimary,
            ),
          ),
          SizedBox(height: 8),
          Text(
            content,
            style: AppText.bodyMedium.copyWith(
              color: AppColors.textColorPrimary.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImagePreview(String imageUrl) {
    print(imageUrl);
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Attached Image",
            style: AppText.bodyLarge.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textColorPrimary,
            ),
          ),
          SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              imageUrl,
              width: double.infinity,
              height: 200,
              fit: BoxFit.cover,
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return SizedBox(
                  height: 200,
                  child: Center(child: CircularProgressIndicator()),
                );
              },
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 200,
                  color: AppColors.dividerColor,
                  child: Center(child: Text("Image not available")),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailRow(
    IconData icon,
    String label,
    String value, {
    Color? valueColor,
  }) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppColors.textColorSecondary),
        SizedBox(width: 12),
        Expanded(
          child: Text(
            label,
            style: AppText.bodyMedium.copyWith(
              color: AppColors.textColorSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Text(
          value,
          style: AppText.bodyMedium.copyWith(
            color: valueColor ?? AppColors.textColorPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    final s = status.toLowerCase();
    if (s.contains('open')) return AppColors.warning;
    if (s.contains('assign')) return AppColors.info;
    if (s.contains('close') || s.contains('resolve')) return AppColors.success;
    return AppColors.textColorSecondary;
  }

  String _formatDate(String dateTimeStr) {
    try {
      final DateTime date = DateTime.parse(dateTimeStr);
      return DateFormat('MMM dd, yyyy • hh:mm a').format(date);
    } catch (e) {
      return dateTimeStr;
    }
  }

  void selectFilterFromDialog(context, String newFilter) {
    if (newFilter == 'By Date') {
      showDateFilterDialog(context);
    } else {
      filter.value = newFilter;
      isDateFilterActive.value = false;
    }
  }

  Future<void> _sendOtpAndClose(
    context,
    TicketModel ticket,
    String remark,
  ) async {
    final String? mobile = await AppSharedPref.instance.getMobileNumber();
    if (mobile == null) {
      Get.snackbar(
        "Error",
        "Mobile number not found",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: AppColors.error,
        colorText: Colors.white,
      );
      return;
    }

    Navigator.pop(context);
    _showOtpVerificationSheet(context, ticket);
  }

  Future<TicketModel?> fetchTicketDetails(String ticketNo) async {
    try {
      final result = await apiServices.fetchTicketByTicketNo(ticketNo);
      return result;
    } catch (e) {
      Get.snackbar(
        "Error",
        "Failed to load full ticket details: $e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: AppColors.error,
        colorText: Colors.white,
      );
      return null;
    }
  }

  void _showOtpVerificationSheet(context, TicketModel ticket) {
    final otpCtrl = TextEditingController();
    final isLoading = false.obs;
    Get.bottomSheet(
      Container(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(Get.context!).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Verify Closure",
                      style: AppText.headingMedium.copyWith(
                        color: AppColors.textColorPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        Iconsax.close_circle,
                        color: AppColors.textColorSecondary,
                      ),
                      onPressed: () => Get.back(),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (ticket.requiresOtpVerification()) ...[
                      Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppColors.primary.withOpacity(0.2),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Iconsax.info_circle,
                              color: AppColors.primary,
                              size: 20,
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                "An OTP has been sent to the customer. Enter it to confirm closure.",
                                style: AppText.bodyMedium.copyWith(
                                  color: AppColors.textColorPrimary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        "Enter OTP",
                        style: AppText.bodyMedium.copyWith(
                          fontWeight: FontWeight.w500,
                          color: AppColors.textColorPrimary,
                        ),
                      ),
                      SizedBox(height: 8),

                      TextField(
                        controller: otpCtrl,
                        keyboardType: TextInputType.number,
                        maxLength: 6,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                        decoration: InputDecoration(
                          hintText: "000000",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: AppColors.dividerColor,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: AppColors.dividerColor,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: AppColors.primary,
                              width: 2,
                            ),
                          ),
                          filled: true,
                          fillColor: AppColors.inputBackground,
                          counterText: "",
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 16,
                          ),
                        ),
                      ),
                    ],
                    SizedBox(height: 24),
                    Obx(
                      () => SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed:
                              isLoading.value
                                  ? null
                                  : () async {
                                    if (ticket.requiresOtpVerification()) {
                                      final otp = otpCtrl.text;
                                      if (otp.length != 6) {
                                        Get.snackbar(
                                          "Invalid OTP",
                                          "Please enter a 6-digit OTP",
                                          snackPosition: SnackPosition.BOTTOM,
                                          backgroundColor: AppColors.warning,
                                          colorText: Colors.white,
                                        );
                                        return;
                                      }
                                    }
                                    isLoading.value = true;
                                    try {
                                      final success = await apiServices
                                          .closeComplaint(
                                            ticketNo: ticket.ticketNo,
                                            closedRemark:
                                                remarkCtrl.text.trim().isEmpty
                                                    ? "I have checked and resolved the issue"
                                                    : remarkCtrl.text.trim(),
                                          );
                                      if (success) {
                                        Get.snackbar(
                                          "Success",
                                          "Ticket closed successfully!",
                                          snackPosition: SnackPosition.BOTTOM,
                                          backgroundColor: AppColors.success,
                                          colorText: Colors.white,
                                          icon: Icon(
                                            Iconsax.tick_circle,
                                            color: Colors.white,
                                          ),
                                        );
                                        Navigator.pop(context);
                                        fetchTickets();
                                      }
                                    } catch (e) {
                                      Get.snackbar(
                                        "Error",
                                        "Failed to close ticket. Please try again.",
                                        snackPosition: SnackPosition.BOTTOM,
                                        backgroundColor: Colors.red,
                                        colorText: Colors.white,
                                      );
                                    } finally {
                                      // Navigator.pop(context);
                                      Navigator.pop(context);
                                      isLoading.value = false;
                                    }
                                  },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 2,
                          ),
                          child:
                              isLoading.value
                                  ? SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                  : Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Iconsax.shield_tick, size: 20),
                                      SizedBox(width: 8),
                                      Text(
                                        "Verify & Close",
                                        style: AppText.button.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    if (ticket.requiresOtpVerification())
                      Center(
                        child: TextButton(
                          onPressed: () {
                            Get.snackbar(
                              "OTP Sent",
                              "New OTP has been sent to customer",
                              snackPosition: SnackPosition.BOTTOM,
                              backgroundColor: AppColors.info,
                              colorText: Colors.white,
                            );
                          },
                          child: Text(
                            "Resend OTP",
                            style: AppText.bodyMedium.copyWith(
                              color: AppColors.primary,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    SizedBox(height: 8),
                    Center(
                      child: TextButton(
                        onPressed: () {
                          Get.snackbar(
                            "Send",
                            "New OTP has been sent to customer",
                            snackPosition: SnackPosition.BOTTOM,
                            backgroundColor: AppColors.info,
                            colorText: Colors.white,
                          );
                        },
                        child: Text(
                          "Send Request to Close",
                          style: AppText.bodyMedium.copyWith(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
      backgroundColor: Colors.white,
    );
  }

  Widget _buildSkeletonLoader() {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(width: 120, height: 24, color: Colors.grey[300]),
              Container(width: 24, height: 24, color: Colors.grey[300]),
            ],
          ),
          SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.backgroundLight,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.dividerColor),
            ),
            child: Column(
              children: List.generate(
                5,
                (_) => Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      Container(width: 16, height: 16, color: Colors.grey[300]),
                      SizedBox(width: 8),
                      Expanded(
                        child: Container(height: 16, color: Colors.grey[300]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Container(
            width: double.infinity,
            height: 20,
            color: Colors.grey[300],
          ),
          SizedBox(height: 8),
          Container(
            width: double.infinity,
            height: 80,
            color: Colors.grey[300],
          ),
          SizedBox(height: 20),
          Container(
            width: double.infinity,
            height: 48,
            color: Colors.grey[300],
          ),
          SizedBox(height: 20),
          Container(
            width: double.infinity,
            height: 50,
            color: Colors.grey[300],
          ),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}
// screens/tickets/all_tickets_screen.dart (Updated AllTicketsScreen)

class AllTicketsScreen extends StatelessWidget {
  const AllTicketsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(AllTicketsController());

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: Column(
        children: [
          // Modern App Bar with Subtle Gradient
          // Inside the build method of AllTicketsScreen, find the AppBar widget.

          // Replace the existing AppBar with this updated version to include the filter button.

          // App Bar
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primary, AppColors.primaryDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: AppBar(
              title: Text(
                "All Tickets",
                style: AppText.headingMedium.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
              iconTheme: IconThemeData(color: AppColors.backgroundLight),
              actions: [
                // Filter Button
                IconButton(
                  icon: Icon(Iconsax.filter, color: Colors.white),
                  onPressed:
                      () => _showFilterDialog(
                        context,
                        Get.put(AllTicketsController()),
                      ),
                  tooltip: "Filter Tickets",
                ),
                SizedBox(width: 8), // Add some spacing
                IconButton(
                  icon: Icon(Iconsax.refresh, color: Colors.white),
                  onPressed: controller.fetchTickets,
                  tooltip: "Refresh",
                ),
              ],
            ),
          ),
          // Enhanced Search Bar with Icon
          Padding(
            padding: EdgeInsets.all(16),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16), // More rounded
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: TextField(
                onChanged: (value) => controller.searchQuery.value = value,
                decoration: InputDecoration(
                  hintText: "Search by ticket no., tech name, or date...",
                  hintStyle: AppText.bodyMedium.copyWith(
                    color: AppColors.textColorSecondary.withOpacity(0.7),
                  ),
                  prefixIcon: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Icon(
                      Iconsax.search_normal,
                      color: AppColors.primary,
                      size: 20,
                    ),
                  ),
                  suffixIcon: Obx(
                    () =>
                        controller.searchQuery.isNotEmpty
                            ? IconButton(
                              icon: Icon(
                                Iconsax.close_circle,
                                color: AppColors.error,
                                size: 20,
                              ),
                              onPressed:
                                  () => controller.searchQuery.value = '',
                            )
                            : SizedBox(),
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 18,
                  ),
                ),
              ),
            ),
          ),

          // Modern Filter Tabs with Icons and Better Spacing
          // SizedBox(
          //   height: 70,
          //   child: Obx(
          //     () => ListView(
          //       scrollDirection: Axis.horizontal,
          //       padding: EdgeInsets.symmetric(horizontal: 16),
          //       children:
          //           controller.filters.map((filterName) {
          //             final isActive = controller.filter.value == filterName;
          //             IconData iconData = Iconsax.filter; // Default

          //             // Assign specific icons for better UX
          //             if (filterName == 'All')
          //               iconData = Iconsax.slider_horizontal;
          //             if (filterName == 'My Tickets') iconData = Iconsax.user;
          //             if (filterName == 'Open') iconData = Iconsax.clock;
          //             if (filterName == 'Assigned')
          //               iconData = Iconsax.user_tick;
          //             if (filterName == 'Closed')
          //               iconData = Iconsax.tick_circle;
          //             if (filterName == 'By Date') iconData = Iconsax.calendar;

          //             return Padding(
          //               padding: EdgeInsets.only(right: 12),
          //               child: GestureDetector(
          //                 onTap: () => controller.setFilter(filterName),
          //                 child: AnimatedContainer(
          //                   duration: Duration(milliseconds: 300),
          //                   padding: EdgeInsets.symmetric(
          //                     horizontal: 18,
          //                     vertical: 12,
          //                   ),
          //                   decoration: BoxDecoration(
          //                     color:
          //                         isActive ? AppColors.primary : Colors.white,
          //                     borderRadius: BorderRadius.circular(24),
          //                     boxShadow: [
          //                       BoxShadow(
          //                         color:
          //                             isActive
          //                                 ? AppColors.primary.withOpacity(0.3)
          //                                 : Colors.black.withOpacity(0.05),
          //                         blurRadius: 8,
          //                         spreadRadius: isActive ? 2 : 0,
          //                       ),
          //                     ],
          //                     border: Border.all(
          //                       color:
          //                           isActive
          //                               ? AppColors.primary
          //                               : AppColors.dividerColor,
          //                       width: 1.5,
          //                     ),
          //                   ),
          //                   child: Row(
          //                     mainAxisSize: MainAxisSize.min,
          //                     children: [
          //                       Icon(
          //                         iconData,
          //                         size: 16,
          //                         color:
          //                             isActive
          //                                 ? Colors.white
          //                                 : AppColors.primary,
          //                       ),
          //                       SizedBox(width: 8),
          //                       Text(
          //                         filterName,
          //                         style: AppText.bodyMedium.copyWith(
          //                           color:
          //                               isActive
          //                                   ? Colors.white
          //                                   : AppColors.textColorPrimary,
          //                           fontWeight:
          //                               isActive
          //                                   ? FontWeight.w600
          //                                   : FontWeight.w500,
          //                         ),
          //                       ),
          //                       // Show a badge if date filter is active
          //                       if (filterName == 'By Date' &&
          //                           controller.isDateFilterActive.value) ...[
          //                         SizedBox(width: 6),
          //                         Container(
          //                           width: 8,
          //                           height: 8,
          //                           decoration: BoxDecoration(
          //                             color: AppColors.success,
          //                             shape: BoxShape.circle,
          //                           ),
          //                         ),
          //                       ],
          //                     ],
          //                   ),
          //                 ),
          //               ),
          //             );
          //           }).toList(),
          //     ),
          //   ),
          // ),

          // ====== GENERAL FILTERS: All | My Tickets ======
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Obx(() {
              return Row(
                children: [
                  // Text(
                  //   "View:",
                  //   style: AppText.bodyMedium.copyWith(
                  //     fontWeight: FontWeight.bold,
                  //     color: AppColors.textColorPrimary,
                  //   ),
                  // ),
                  // const SizedBox(width: 12),
                  _buildFilterChip(
                    label: "All",
                    isActive:
                        !controller.isMyTicketsActive.value &&
                        controller.statusFilter.value == 'All' &&
                        !controller.isDateFilterActive.value,
                    onTap: () {
                      controller.isMyTicketsActive.value = false;
                      controller.statusFilter.value = 'All';
                      controller.isDateFilterActive.value = false;
                      controller.fetchTickets();
                    },
                  ),
                  const SizedBox(width: 8),
                  _buildFilterChip(
                    label: "My Tickets",
                    isActive: controller.isMyTicketsActive.value,
                    onTap: () {
                      controller.isMyTicketsActive.toggle();
                      controller.fetchTickets();
                    },
                  ),
                ],
              );
            }),
          ),

          // ====== STATUS & DATE FILTERS ======
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 4,
                ),
                child: Obx(() {
                  return Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildStatusFilterChip(
                        label: "Open",
                        isActive: controller.statusFilter.value == 'Open',
                        onTap: () {
                          controller.statusFilter.value = 'Open';
                          controller.fetchTickets();
                        },
                      ),
                      if (!controller.isMyTicketsActive.value)
                        _buildStatusFilterChip(
                          label: "Assigned",
                          isActive: controller.statusFilter.value == 'Assigned',
                          onTap: () {
                            controller.statusFilter.value = 'Assigned';
                            controller.fetchTickets();
                          },
                        ),
                      _buildStatusFilterChip(
                        label: "Closed",
                        isActive: controller.statusFilter.value == 'Closed',
                        onTap: () {
                          controller.statusFilter.value = 'Closed';
                          controller.fetchTickets();
                        },
                      ),
                      _buildStatusFilterChip(
                        label: "By Date",
                        isActive: controller.isDateFilterActive.value,
                        onTap: () => _showDateRangePicker(context, controller),
                      ),
                    ],
                  );
                }),
              ),
            ],
          ),

          // Enhanced Tickets Counter with Clear Option
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Obx(() {
              final count = controller.filteredTickets.length;
              final total = controller.tickets.length;
              return Row(
                children: [
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: "Showing ",
                          style: AppText.bodySmall.copyWith(
                            color: AppColors.textColorSecondary,
                          ),
                        ),
                        TextSpan(
                          text: "$count",
                          style: AppText.bodySmall.copyWith(
                            color: AppColors.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextSpan(
                          text: " of $total tickets",
                          style: AppText.bodySmall.copyWith(
                            color: AppColors.textColorSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  if (controller.searchQuery.isNotEmpty)
                    GestureDetector(
                      onTap: () => controller.searchQuery.value = '',
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.error.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.error, width: 1),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Iconsax.close_circle,
                              size: 14,
                              color: AppColors.error,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "Clear Search",
                              style: AppText.bodySmall.copyWith(
                                color: AppColors.error,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (controller.isDateFilterActive.value)
                    GestureDetector(
                      onTap: () => controller.clearDateFilter(),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        margin: EdgeInsets.only(left: 8),
                        decoration: BoxDecoration(
                          color: AppColors.warning.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: AppColors.warning,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Iconsax.calendar_remove,
                              size: 14,
                              color: AppColors.warning,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "Clear Date",
                              style: AppText.bodySmall.copyWith(
                                color: AppColors.warning,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              );
            }),
          ),

          // Beautiful Tickets List
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return _buildShimmerLoading();
              }

              final filtered = controller.filteredTickets;

              if (filtered.isEmpty) {
                return _buildEmptyState(controller);
              }

              return RefreshIndicator(
                onRefresh: controller.fetchTickets,
                backgroundColor: Colors.white,
                color: AppColors.primary,
                child: ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (context, index) => SizedBox(height: 12),
                  padding: EdgeInsets.all(16),
                  itemBuilder: (context, index) {
                    final ticket = filtered[index];
                    return _buildTicketCard(context, controller, ticket);
                  },
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  // Enhanced Shimmer Loading with more realistic shapes
  Widget _buildShimmerLoading() {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: 5,
      itemBuilder: (context, index) {
        return Shimmer.fromColors(
          baseColor: Colors.grey[300]!,
          highlightColor: Colors.grey[100]!,
          child: Container(
            height: 140,
            margin: EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Shimmer for ticket number and status badge
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 100,
                        height: 20,
                        color: Colors.grey[300],
                      ),
                      Container(width: 80, height: 24, color: Colors.grey[300]),
                    ],
                  ),
                  SizedBox(height: 16),
                  // Shimmer for date
                  Container(width: 150, height: 16, color: Colors.grey[300]),
                  SizedBox(height: 8),
                  // Shimmer for technician
                  Container(width: 120, height: 16, color: Colors.grey[300]),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // More visually appealing empty state
  Widget _buildEmptyState(AllTicketsController controller) {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 50),
            Container(
              padding: EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: AppColors.backgroundLight.withOpacity(0.8),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Iconsax.receipt_search,
                size: 80,
                color: AppColors.primary.withOpacity(0.6),
              ),
            ),
            SizedBox(height: 24),
            Text(
              "No ${controller.filter.value.toLowerCase()} tickets found",
              textAlign: TextAlign.center,
              style: AppText.headingMedium.copyWith(
                color: AppColors.textColorPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              "Try adjusting your filter or search term.",
              textAlign: TextAlign.center,
              style: AppText.bodyMedium.copyWith(
                color: AppColors.textColorSecondary,
              ),
            ),
            SizedBox(height: 32),
            if (controller.searchQuery.isNotEmpty ||
                controller.isDateFilterActive.value)
              ElevatedButton(
                onPressed: () {
                  controller.searchQuery.value = '';
                  controller.clearDateFilter();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Iconsax.refresh, size: 18),
                    SizedBox(width: 8),
                    Text(
                      "Clear All Filters",
                      style: AppText.button.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
  // Inside AllTicketsScreen class (Add this new method)

  /// Shows the filter selection dialog.
  void _showFilterDialog(context, AllTicketsController controller) {
    Get.dialog(
      Obx(
        () => AlertDialog(
          title: Text(
            "Filter Tickets",
            style: AppText.headingMedium.copyWith(fontWeight: FontWeight.bold),
          ),
          contentPadding: const EdgeInsets.all(16),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // --- Filter Options List ---
                ...(controller.filters.map((filterName) {
                  bool isActive = false;
                  IconData iconData = Iconsax.filter; // Default icon

                  // Determine if the current filter option is active based on controller state
                  if (filterName == 'My Tickets') {
                    isActive = controller.isMyTicketsActive.value;
                  } else if (filterName == 'All') {
                    // 'All' is active only if no other primary filters are active
                    isActive =
                        !controller.isMyTicketsActive.value &&
                        controller.statusFilter.value == 'All' &&
                        !controller.isDateFilterActive.value;
                  } else if (filterName == 'Open' ||
                      filterName == 'Assigned' ||
                      filterName == 'Closed') {
                    isActive = controller.statusFilter.value == filterName;
                  } else if (filterName == 'By Date') {
                    isActive = controller.isDateFilterActive.value;
                    // Optional: Add a visual indicator if date filter is active
                    // This is handled below in the list tile
                  }

                  // Assign specific icons for each filter option
                  if (filterName == 'All') iconData = Iconsax.slider_horizontal;
                  if (filterName == 'My Tickets') iconData = Iconsax.user;
                  if (filterName == 'Open') iconData = Iconsax.clock;
                  if (filterName == 'Assigned') iconData = Iconsax.user_tick;
                  if (filterName == 'Closed') iconData = Iconsax.tick_circle;
                  if (filterName == 'By Date') iconData = Iconsax.calendar;

                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color:
                            isActive
                                ? AppColors
                                    .primary // Use your AppColors
                                : Colors.transparent,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      leading: Icon(
                        iconData,
                        color:
                            isActive
                                ? AppColors
                                    .primary // Use your AppColors
                                : AppColors
                                    .textColorSecondary, // Use your AppColors
                      ),
                      title: Text(
                        filterName,
                        style: AppText.bodyMedium.copyWith(
                          // Use your AppText style
                          color:
                              AppColors.textColorPrimary, // Use your AppColors
                          fontWeight:
                              isActive ? FontWeight.w600 : FontWeight.w500,
                        ),
                      ),
                      // Show checkmark if active
                      trailing:
                          isActive
                              ? Icon(
                                Icons.check,
                                color: AppColors.success,
                              ) // Use your AppColors
                              : null,
                      // --- Handle Tap ---
                      onTap: () {
                        Navigator.pop(context); // Close the dialog first

                        if (filterName == 'My Tickets') {
                          // Toggle the "My Tickets" flag
                          controller.isMyTicketsActive.toggle();
                        } else if (filterName == 'All') {
                          // Reset all filters
                          controller.isMyTicketsActive.value = false;
                          controller.statusFilter.value = 'All';
                          controller.isDateFilterActive.value = false;
                          // Optionally reset date range to default if needed elsewhere
                          // controller.selectedStartDate.value = defaultStart;
                          // controller.selectedEndDate.value = defaultEnd;
                        } else if (filterName == 'Open' ||
                            filterName == 'Assigned' ||
                            filterName == 'Closed') {
                          // Set the status filter
                          controller.statusFilter.value = filterName;
                        } else if (filterName == 'By Date') {
                          // Trigger the date range picker
                          // This will handle setting isDateFilterActive and the dates
                          _showDateRangePicker(context, controller);
                        }
                        controller.fetchTickets();
                      },
                    ),
                  );
                }).toList()),

                // --- Show Active Date Range ---
                if (controller.isDateFilterActive.value)
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.backgroundLight, // Fallback
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: AppColors.warning, // Fallback
                          width: 1,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Active Date Filter:",
                            style: AppText.bodySmall.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "From: ${DateFormat('MMM dd, yyyy').format(controller.selectedStartDate.value)}",
                            style: AppText.bodySmall, // Use your AppText style
                          ),
                          Text(
                            "To: ${DateFormat('MMM dd, yyyy').format(controller.selectedEndDate.value)}",
                            style: AppText.bodySmall, // Use your AppText style
                          ),
                          const SizedBox(height: 8),
                          TextButton(
                            onPressed: () {
                              Navigator.pop(
                                context,
                              ); // Close dialog if opened from here
                              // Clear the date filter
                              controller.isDateFilterActive.value = false;
                              // Optionally reset dates to default range
                              // controller.selectedStartDate.value = defaultStart;
                              // controller.selectedEndDate.value = defaultEnd;
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Iconsax
                                      .calendar_remove, // Use appropriate icon
                                  size: 16,
                                  color: AppColors.warning, // Fallback
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  "Clear Date Filter",
                                  style: AppText.bodySmall.copyWith(
                                    color: AppColors.warning,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          // --- Dialog Actions ---
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text(
                "Cancel",
                style: TextStyle(
                  color: AppColors.textColorSecondary,
                ), // Fallback
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Filters are applied on selection/toggle, so just close the dialog.
                controller.fetchTickets();
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary, // Fallback
              ),
              child: Text(
                "Done",
                style: TextStyle(
                  color: Colors.white,
                ), // Adjust text color as needed
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive ? AppColors.primary : AppColors.dividerColor,
            width: 1.5,
          ),
          boxShadow:
              isActive
                  ? [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.2),
                      blurRadius: 4,
                    ),
                  ]
                  : [],
        ),
        child: Text(
          label,
          style: AppText.bodyMedium.copyWith(
            color: isActive ? Colors.white : AppColors.textColorPrimary,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildStatusFilterChip({
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color:
              isActive
                  ? AppColors.primary.withOpacity(0.1)
                  : AppColors.backgroundLight,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive ? AppColors.primary : AppColors.dividerColor,
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (label == 'By Date' && isActive) ...[
              Icon(Iconsax.calendar, size: 14, color: AppColors.primary),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: AppText.bodySmall.copyWith(
                color:
                    isActive ? AppColors.primary : AppColors.textColorSecondary,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Helper function to show the date range picker dialog.
  /// You need to implement this based on your UI preferences (e.g., using showDatePicker).
  Future<void> _showDateRangePicker(
    context,
    AllTicketsController controller,
  ) async {
    // Example using Flutter's built-in showDatePicker
    // You might want to show a custom dialog for both dates at once

    // Get the context correctly, might need to pass it or use Get.context
    final BuildContext? context = Get.context;

    if (context == null) {
      // Handle error if context is not available
      debugPrint("Context not available for date picker");
      Get.back(); // Close the filter dialog if context is missing
      return;
    }

    // --- Show Start Date Picker ---
    final DateTime? pickedStartDate = await showDatePicker(
      context: context,
      initialDate: controller.selectedStartDate.value,
      firstDate: DateTime(2000), // Adjust as needed
      lastDate: controller.selectedEndDate.value,
    );

    if (pickedStartDate != null) {
      controller.selectedStartDate.value = pickedStartDate;

      // --- Show End Date Picker (after start date is picked) ---
      final DateTime? pickedEndDate = await showDatePicker(
        context: context,
        initialDate: controller.selectedEndDate.value,
        firstDate: pickedStartDate, // End date cannot be before start date
        lastDate: DateTime.now().add(
          const Duration(days: 365),
        ), // Adjust as needed
      );

      if (pickedEndDate != null) {
        controller.selectedEndDate.value = pickedEndDate;
        // Activate the date filter once both dates are selected
        controller.isDateFilterActive.value = true;
      } else {
        // If end date is not picked, you might want to revert start date or keep previous state
        // For now, we'll just not activate the filter if end date is cancelled
        // Optionally, show a message or keep the previous end date
      }
    }
    // Close the main filter dialog if needed, or let the user tap "Done"
    // Navigator.pop(context); // Uncomment if you want to close the filter dialog immediately after date selection
  }

  // Beautiful, modern ticket card
  Widget _buildTicketCard(
    context,
    AllTicketsController controller,
    TicketModel ticket,
  ) {
    final statusColor = controller._getStatusColor(ticket.status);
    final statusIcon = _getStatusIcon(ticket.status);

    return InkWell(
      onTap:
          () =>
              controller.showTicketDetails(context, ticket, ticket.customerId!),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 15,
              spreadRadius: 1,
              offset: Offset(0, 3),
            ),
          ],
          border: Border.fromBorderSide(
            BorderSide(color: statusColor.withOpacity(0.3), width: 2),
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header row with ticket number and status
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      ticket.ticketNo,
                      style: AppText.headingSmall.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.textColorPrimary,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor, width: 1.5),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(statusIcon, size: 16, color: statusColor),
                        SizedBox(width: 8),
                        Text(
                          ticket.status,
                          style: TextStyle(
                            color: statusColor,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              // Date and technician info with icons
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Iconsax.calendar,
                      size: 16,
                      color: AppColors.primary,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _formatDate(ticket.createdAt),
                      style: AppText.bodyMedium.copyWith(
                        color: AppColors.textColorPrimary,
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              if (ticket.assignTo != null &&
                  (ticket.technician != '' && ticket.technician != null)) ...[
                SizedBox(height: 12),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.info.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Iconsax.user,
                        size: 16,
                        color: AppColors.info,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        "Technician: ${ticket.technician}",
                        style: AppText.bodyMedium.copyWith(
                          color: AppColors.textColorPrimary,
                          fontWeight: FontWeight.w500,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
              if (ticket.assignTo == AppSharedPref.instance.getUserID()) ...[
                SizedBox(height: 12),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.success.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Iconsax.user_tick,
                        size: 16,
                        color: AppColors.success,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        "Assigned to: Tech ID ${ticket.assignTo}",
                        style: AppText.bodyMedium.copyWith(
                          color: AppColors.textColorPrimary,
                          fontWeight: FontWeight.w500,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  IconData _getStatusIcon(String status) {
    final s = status.toLowerCase();
    if (s.contains('open')) return Iconsax.clock;
    if (s.contains('assign')) return Iconsax.user_tick;
    if (s.contains('close') || s.contains('resolve'))
      return Iconsax.tick_circle;
    return Iconsax.info_circle;
  }

  String _formatDate(String dateTimeStr) {
    try {
      final DateTime date = DateTime.parse(dateTimeStr);
      return DateFormat('MMM dd, yyyy • hh:mm a').format(date);
    } catch (e) {
      return dateTimeStr;
    }
  }
}

// lib/controllers/all_tickets_controller.dart

// class AllTicketsController extends GetxController {
//   final apiServices = TechnicianAPI();
//   final tickets = <TicketModel>[].obs;
//   final isLoading = true.obs;
//   final searchQuery = ''.obs;

//   // ✅ NEW: Single filter state matching API
//   final RxString activeFilter =
//       'all'
//           .obs; // Options: 'all', 'myTickets', 'myOpenTickets', 'myClosedTickets', 'openTickets', 'closeTickets', 'byDate'

//   // Date filter state
//   final Rx<DateTime> selectedStartDate =
//       DateTime.now().subtract(const Duration(days: 7)).obs;
//   final Rx<DateTime> selectedEndDate = DateTime.now().obs;

//   // Filter options for UI (human-readable labels)
//   List<Map<String, String>> get filterOptions => [
//     {'key': 'all', 'label': 'All Tickets', 'icon': '📊'},
//     {'key': 'myTickets', 'label': 'My Tickets', 'icon': '👤'},
//     {'key': 'myOpenTickets', 'label': 'My Open', 'icon': '⏳'},
//     {'key': 'myClosedTickets', 'label': 'My Closed', 'icon': '✅'},
//     {'key': 'openTickets', 'label': 'All Open', 'icon': '🕒'},
//     {'key': 'closeTickets', 'label': 'All Closed', 'icon': '🔒'},
//     {'key': 'byDate', 'label': 'By Date', 'icon': '📅'},
//   ];

//   @override
//   void onInit() {
//     super.onInit();
//     fetchTickets();
//   }

//   // 👇 Apply search only (filtering done by API)
//   List<TicketModel> get filteredTickets {
//     if (searchQuery.isEmpty) return tickets;
//     final query = searchQuery.value.toLowerCase();
//     return tickets
//         .where((t) {
//           return t.ticketNo.toLowerCase().contains(query) ||
//               (t.technician?.toLowerCase() ?? '').contains(query) ||
//               t.createdAt.toLowerCase().contains(query);
//         })
//         .toList()
//         .obs;
//   }

//   Future<void> fetchTickets() async {
//     isLoading.value = true;
//     try {
//       Map<String, dynamic> params = {'filter': activeFilter.value};
//       if (activeFilter.value == 'byDate') {
//         params['startDate'] = DateFormat(
//           'yyyy-MM-dd',
//         ).format(selectedStartDate.value);
//         params['endDate'] = DateFormat(
//           'yyyy-MM-dd',
//         ).format(selectedEndDate.value);
//       }

//       final result = await apiServices.fetchAllTicketsWithParams(params);
//       if (result != null) {
//         tickets.assignAll(result);
//       }
//     } catch (e) {
//       Get.snackbar("Error", "Failed to load tickets: $e");
//     } finally {
//       isLoading.value = false;
//     }
//   }

//   void clearAllFilters() {
//     activeFilter.value = 'all';
//     searchQuery.value = '';
//     selectedStartDate.value = DateTime.now().subtract(const Duration(days: 7));
//     selectedEndDate.value = DateTime.now();
//     fetchTickets();
//   }

//   void applyDateFilter(DateTime start, DateTime end) {
//     selectedStartDate.value = start;
//     selectedEndDate.value = end;
//     activeFilter.value = 'byDate';
//     fetchTickets();
//   }
// }

// // lib/screens/tickets/all_tickets_screen.dart
// class AllTicketsScreen extends StatelessWidget {
//   const AllTicketsScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final controller = Get.put(AllTicketsController());

//     return Scaffold(
//       backgroundColor: const Color(0xFFF5F7FA),
//       body: Column(
//         children: [
//           // App Bar
//           Container(
//             decoration: const BoxDecoration(
//               gradient: LinearGradient(
//                 colors: [Color(0xFF6366F1), Color(0xFF818CF8)],
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//               ),
//               boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 12)],
//             ),
//             child: AppBar(
//               title: const Text(
//                 "All Tickets",
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               backgroundColor: Colors.transparent,
//               elevation: 0,
//               actions: [
//                 IconButton(
//                   icon: const Icon(Icons.refresh, color: Colors.white),
//                   onPressed: controller.fetchTickets,
//                 ),
//               ],
//             ),
//           ),

//           // Search Bar
//           Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Container(
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(16),
//                 boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)],
//               ),
//               child: TextField(
//                 onChanged: (v) => controller.searchQuery.value = v,
//                 decoration: InputDecoration(
//                   hintText: "Search tickets...",
//                   prefixIcon: const Icon(
//                     Icons.search,
//                     color: Color(0xFF6366F1),
//                   ),
//                   suffixIcon: Obx(
//                     () =>
//                         controller.searchQuery.isNotEmpty
//                             ? IconButton(
//                               icon: const Icon(Icons.clear, color: Colors.red),
//                               onPressed:
//                                   () => controller.searchQuery.value = '',
//                             )
//                             : SizedBox(),
//                   ),
//                   border: InputBorder.none,
//                   contentPadding: const EdgeInsets.symmetric(
//                     horizontal: 16,
//                     vertical: 14,
//                   ),
//                 ),
//               ),
//             ),
//           ),

//           // Filter Chips
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16.0),
//             child: SizedBox(
//               height: 50,
//               child: Obx(
//                 () => ListView(
//                   scrollDirection: Axis.horizontal,
//                   children:
//                       controller.filterOptions.map((option) {
//                         final isActive =
//                             controller.activeFilter.value == option['key'];
//                         return Padding(
//                           padding: const EdgeInsets.only(right: 10),
//                           child: ChoiceChip(
//                             label: Row(
//                               mainAxisSize: MainAxisSize.min,
//                               children: [
//                                 Text(
//                                   option['icon']!,
//                                   style: const TextStyle(fontSize: 16),
//                                 ),
//                                 const SizedBox(width: 6),
//                                 Text(option['label']!),
//                               ],
//                             ),
//                             selected: isActive,
//                             selectedColor: const Color(0xFF6366F1),
//                             backgroundColor: Colors.white,
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(20),
//                               side: BorderSide(
//                                 color:
//                                     isActive
//                                         ? const Color(0xFF6366F1)
//                                         : Colors.grey.shade300,
//                                 width: 1.5,
//                               ),
//                             ),
//                             labelStyle: TextStyle(
//                               color:
//                                   isActive
//                                       ? Colors.white
//                                       : AppColors.textColorPrimary,
//                               fontWeight:
//                                   isActive
//                                       ? FontWeight.bold
//                                       : FontWeight.normal,
//                             ),
//                             onSelected: (selected) {
//                               if (option['key'] == 'byDate') {
//                                 _showDateRangePicker(context, controller);
//                               } else {
//                                 controller.activeFilter.value = option['key']!;
//                                 controller.fetchTickets();
//                               }
//                             },
//                           ),
//                         );
//                       }).toList(),
//                 ),
//               ),
//             ),
//           ),

//           // Results Counter
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
//             child: Obx(() {
//               final count = controller.filteredTickets.length;
//               return Text(
//                 "Showing $count tickets",
//                 style: const TextStyle(
//                   fontSize: 14,
//                   fontWeight: FontWeight.w600,
//                   color: Colors.grey,
//                 ),
//               );
//             }),
//           ),

//           // Tickets List
//           Expanded(
//             child: Obx(() {
//               if (controller.isLoading.value) return _buildShimmer();
//               if (controller.filteredTickets.isEmpty) return _buildEmptyState();
//               return RefreshIndicator(
//                 onRefresh: controller.fetchTickets,
//                 child: ListView.separated(
//                   padding: const EdgeInsets.all(16),
//                   itemCount: controller.filteredTickets.length,
//                   separatorBuilder: (_, __) => const SizedBox(height: 12),
//                   itemBuilder: (context, index) {
//                     final ticket = controller.filteredTickets[index];
//                     return _buildTicketCard(ticket);
//                   },
//                 ),
//               );
//             }),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildShimmer() {
//     return ListView.builder(
//       itemCount: 5,
//       itemBuilder:
//           (context, index) => Shimmer.fromColors(
//             baseColor: Colors.grey[300]!,
//             highlightColor: Colors.grey[100]!,
//             child: Container(
//               height: 120,
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(16),
//               ),
//             ),
//           ),
//     );
//   }

//   Widget _buildEmptyState() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           const Icon(Icons.receipt_long, size: 80, color: Colors.grey),
//           const SizedBox(height: 16),
//           const Text(
//             "No tickets found",
//             style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             "Try adjusting your filters",
//             style: TextStyle(color: Colors.grey),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildTicketCard(TicketModel ticket) {
//     Color statusColor;
//     IconData statusIcon;
//     if (ticket.status.toLowerCase().contains('open')) {
//       statusColor = Colors.orange;
//       statusIcon = Icons.access_time;
//     } else if (ticket.status.toLowerCase().contains('assign')) {
//       statusColor = Colors.blue;
//       statusIcon = Icons.engineering;
//     } else {
//       statusColor = Colors.green;
//       statusIcon = Icons.check_circle;
//     }

//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)],
//         border: Border(left: BorderSide(color: statusColor, width: 4)),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(
//                   ticket.ticketNo,
//                   style: const TextStyle(fontWeight: FontWeight.bold),
//                 ),
//                 Container(
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 10,
//                     vertical: 4,
//                   ),
//                   decoration: BoxDecoration(
//                     color: statusColor.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Row(
//                     children: [
//                       Icon(statusIcon, size: 14, color: statusColor),
//                       const SizedBox(width: 4),
//                       Text(
//                         ticket.status,
//                         style: TextStyle(color: statusColor, fontSize: 12),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 8),
//             Text(
//               "Created: ${_formatDate(ticket.createdAt)}",
//               style: const TextStyle(color: Colors.grey, fontSize: 12),
//             ),
//             if (ticket.technician != null) ...[
//               const SizedBox(height: 4),
//               Text(
//                 "Technician: ${ticket.technician}",
//                 style: const TextStyle(fontSize: 12),
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }

//   String _formatDate(String dateTimeStr) {
//     try {
//       final date = DateTime.parse(dateTimeStr);
//       return DateFormat('MMM dd, yyyy • hh:mm a').format(date);
//     } catch (e) {
//       return dateTimeStr;
//     }
//   }

//   Future<void> _showDateRangePicker(
//     BuildContext context,
//     AllTicketsController controller,
//   ) async {
//     final start = await showDatePicker(
//       context: context,
//       initialDate: controller.selectedStartDate.value,
//       firstDate: DateTime(2020),
//       lastDate: DateTime.now(),
//     );
//     if (start == null) return;

//     final end = await showDatePicker(
//       context: context,
//       initialDate: start.isAfter(DateTime.now()) ? DateTime.now() : start,
//       firstDate: start,
//       lastDate: DateTime.now(),
//     );
//     if (end == null) return;

//     controller.applyDateFilter(start, end);
//   }
// }
