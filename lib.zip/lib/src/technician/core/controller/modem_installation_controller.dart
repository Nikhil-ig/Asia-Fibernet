import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ModemInstallationController extends GetxController {
  // Selected files
  var signedInvoiceFile = Rx<File?>(null);
  var modemPictureFile = Rx<File?>(null);
  var ucReportFile = Rx<File?>(null);
  var upiPaymentFile = Rx<File?>(null);

  // Form fields
  var powerLevel = ''.obs;
  var latitude = ''.obs;
  var longitude = ''.obs;
  var selectedPaymentType = 'Cash'.obs;
  var otp = ''.obs;

  // State variables
  var isLoading = false.obs;
  var isGeneratingOtp = false.obs;
  var isSubmitting = false.obs;
  var error = ''.obs;
  var successMessage = ''.obs;

  final ImagePicker _imagePicker = ImagePicker();

  int? customerId;

  @override
  void onInit() {
    super.onInit();
    customerId = Get.arguments?['customerId'];
    getCurrentLocation();
  }

  Future<void> getCurrentLocation() async {
    try {
      isLoading.value = true;
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      latitude.value = position.latitude.toStringAsFixed(6);
      longitude.value = position.longitude.toStringAsFixed(6);
    } catch (e) {
      print("Location error: $e");
      latitude.value = '0.0';
      longitude.value = '0.0';
      Get.snackbar(
        'Location Error',
        'Unable to fetch current location',
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> pickImage(ImageSource source, Rx<File?> fileVariable) async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: source,
        imageQuality: 80,
        maxWidth: 1200,
      );

      if (image != null) {
        fileVariable.value = File(image.path);
        error.value = '';
      }
    } catch (e) {
      error.value = 'Failed to pick image: $e';
    }
  }

  void removeImage(Rx<File?> fileVariable) {
    fileVariable.value = null;
  }

  Future<void> generateOtp() async {
    try {
      isGeneratingOtp.value = true;
      error.value = '';

      // Simulate API call
      await Future.delayed(Duration(seconds: 2));

      // Generate random 6-digit OTP
      final randomOtp = (100000 + Random().nextInt(900000)).toString();
      otp.value = randomOtp;

      Get.snackbar(
        'OTP Generated',
        'Your OTP is: $randomOtp',
        backgroundColor: Colors.green,
        colorText: Colors.white,
        duration: Duration(seconds: 5),
      );
    } catch (e) {
      error.value = 'Failed to generate OTP: $e';
    } finally {
      isGeneratingOtp.value = false;
    }
  }

  Future<void> downloadInvoice() async {
    try {
      // Simulate download process
      Get.snackbar(
        'Download Started',
        'Invoice download in progress...',
        backgroundColor: Colors.blue,
        colorText: Colors.white,
      );

      await Future.delayed(Duration(seconds: 2));

      Get.snackbar(
        'Download Complete',
        'Invoice downloaded successfully!',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      error.value = 'Failed to download invoice: $e';
    }
  }

  Future<void> submitInstallation() async {
    try {
      // Validation
      if (signedInvoiceFile.value == null) {
        error.value = 'Please upload signed invoice';
        return;
      }

      if (modemPictureFile.value == null) {
        error.value = 'Please upload modem picture';
        return;
      }

      if (ucReportFile.value == null) {
        error.value = 'Please upload UC report picture';
        return;
      }

      if (powerLevel.value.isEmpty) {
        error.value = 'Please enter power level';
        return;
      }

      if (selectedPaymentType.value == 'UPI' && upiPaymentFile.value == null) {
        error.value = 'Please upload UPI payment screenshot';
        return;
      }

      isSubmitting.value = true;
      error.value = '';

      // Simulate API submission
      await Future.delayed(Duration(seconds: 3));

      successMessage.value = 'Modem installation submitted successfully!';
      Get.snackbar(
        'Success',
        'Modem installation completed!',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );

      // Navigate back after success
      await Future.delayed(Duration(seconds: 2));
      Get.back(result: true);
    } catch (e) {
      error.value = 'Failed to submit installation: $e';
    } finally {
      isSubmitting.value = false;
    }
  }

  void updatePowerLevel(String value) => powerLevel.value = value;
  void updatePaymentType(String value) => selectedPaymentType.value = value;
}
