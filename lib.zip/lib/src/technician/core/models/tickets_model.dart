// models/ticket_model.dart

import 'package:intl/intl.dart';

class TicketModel {
  // Fields from list API (fetch_ticket_tech.php)
  final String ticketNo;
  final String createdAt;
  final String status;
  final String? technician;
  final int? assignTo;
  final bool editable;

  // Additional fields from detailed API (get_ticket_by_ticketNo_tech.php)
  final int? customerId;
  final String? customerMobileNo;
  final String? image;
  final String? updatedAt;
  final String? description;
  final String? category;
  final String? subCategory;
  final String? closedRemark;
  final String? closedAt;
  final String? technicianName;

  TicketModel({
    // Required fields
    required this.ticketNo,
    required this.createdAt,
    required this.status,
    this.technician,
    required this.assignTo,
    required this.editable,

    // Optional detailed fields
    this.customerId,
    this.customerMobileNo,
    this.image,
    this.updatedAt,
    this.description,
    this.category,
    this.subCategory,
    this.closedRemark,
    this.closedAt,
    this.technicianName,
  });

  factory TicketModel.fromJson(Map<String, dynamic> json) {
    return TicketModel(
      customerId: json['customer_id'] as int?,
      ticketNo: json['ticket_no'] as String? ?? 'N/A',
      createdAt: json['created_at'] as String? ?? 'N/A',
      status: json['status'] as String? ?? 'Unknown',
      technician: json['technician'] as String?,
      assignTo:
          json['assign_to'] is int
              ? json['assign_to']
              : int.tryParse('${json['assign_to']}') ?? 0,
      editable:
          json['editable'] is bool
              ? json['editable']
              : (json['editable'] as String?)?.toLowerCase() == 'true' || false,

      // Optional fields from detailed response
      customerMobileNo: json['customer_mobile_no'] as String?,
      image: json['image'] as String?, // relative path
      updatedAt: json['updated_at'] as String?,
      description: json['description'] as String?,
      category: json['category'] as String?,
      subCategory: json['sub_category'] as String?,
      closedRemark: json['closed_remark'] as String?,
      closedAt: json['closed_at'] as String?,
      technicianName: json['technician_name'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
    'customer_id': customerId,
    'ticket_no': ticketNo,
    'created_at': createdAt,
    'status': status,
    'technician': technician,
    'assign_to': assignTo,
    'editable': editable,
    'customer_mobile_no': customerMobileNo,
    'image': image,
    'updated_at': updatedAt,
    'description': description,
    'category': category,
    'sub_category': subCategory,
    'closed_remark': closedRemark,
    'closed_at': closedAt,
    'technician_name': technicianName,
  };

  @override
  String toString() {
    return 'TicketModel(customerId: $customerId, ticketNo: $ticketNo, status: $status, createdAt: $createdAt, '
        'customerMobileNo: $customerMobileNo, description: $description, closedRemark: $closedRemark)';
  }

  // Helper: Full image URL
  String? get fullImageUrl {
    if (image == null) return null;
    return 'https://dgipe.com/af/api/$image';
  }

  // Helper: Is ticket closed?
  bool get isClosed =>
      status.trim().toLowerCase() == 'closed' ||
      status.trim().toLowerCase() == 'resolved';

  // Helper: Is ticket open?
  bool get isOpen => !isClosed;

  bool requiresOtpVerification({int hoursThreshold = 4}) {
    // No OTP needed for closed tickets
    if (isClosed) {
      return false;
    }

    try {
      // Parse the createdAt string. Adjust the format string if your API uses a different format.
      // The format in your _formatDate example seems to be 'MMM dd, yyyy â ¢ hh:mm a',
      // but the raw data from JSON is likely 'yyyy-MM-dd HH:mm:ss' or similar.
      // Let's assume the raw JSON date format is 'yyyy-MM-dd HH:mm:ss'.
      // You might need to adjust this format string based on your actual API response.
      // Example format for '2025-09-17 17:10:58':
      final DateTime createdAtDateTime = DateFormat(
        'yyyy-MM-dd HH:mm:ss',
      ).parse(createdAt);

      final DateTime now = DateTime.now();
      final Duration difference = now.difference(createdAtDateTime);

      // Check if the difference is greater than or equal to the threshold hours
      return difference.inHours >= hoursThreshold;
    } catch (e) {
      // If parsing fails, assume OTP is not required or handle the error as appropriate
      print("Error parsing createdAt date for ticket $ticketNo: $e");
      // Optionally, you could show a snackbar or log the error
      // Get.snackbar("Error", "Could not verify ticket age for OTP requirement.");
      return false; // Or true, depending on desired fallback behavior
    }
  }
}
