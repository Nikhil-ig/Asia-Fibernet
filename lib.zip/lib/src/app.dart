// import 'package:flutter/widgets.dart';
// import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:get/route_manager.dart';
// import 'services/routes.dart';



// /// The Widget that configures your application.
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return GetMaterialApp(
//       localizationsDelegates: const [
//         // AppLocalizations.delegate,
//         GlobalMaterialLocalizations.delegate,
//         GlobalWidgetsLocalizations.delegate,
//         GlobalCupertinoLocalizations.delegate,
//       ],
//       supportedLocales: const [
//         Locale('en', ''), // English, no country code
//       ],
//       // onGenerateTitle: (BuildContext context) =>
//       //     AppLocalizations.of(context)!.appTitle,
//       // darkTheme: ThemeData.dark(),
//       routes: AppRoutes.routes,
//       // home: const HomeScreen(),
//     );
//   }
// }
