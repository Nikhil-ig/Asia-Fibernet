// ignore_for_file: unused_import, depend_on_referenced_packages

library;

///* Google Font
import 'package:google_fonts/google_fonts.dart' as google_fonts;

//* Localizations
import 'package:flutter_localizations/flutter_localizations.dart'
    as flutter_localizations;

///* Networking
// import 'package:http/http.dart' as http;

///* Firebase
// import 'package:firebase_core/firebase_core.dart' as firebase_core;
// import 'package:cloud_firestore/cloud_firestore.dart' as cloud_firestore;

///* State Management
// import 'package:riverpod/riverpod.dart' as riverpod;
// import 'package:flutter_riverpod/flutter_riverpod.dart' as flutter_riverpod;
import 'package:get/get.dart';

///* Other Widgets
import 'package:avatar_glow/avatar_glow.dart' as avatar_glow;
