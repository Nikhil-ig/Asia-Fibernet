// // main.dart
// import 'package:asia_fibernet/src/theme/theme.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:get/get.dart';
// import 'package:timezone/data/latest_all.dart' as tz;
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:google_fonts/google_fonts.dart';

// // ✅ Fixed import paths (no spaces)
// import 'src/auth/core/controller /binding/login_binding.dart';
// import 'src/auth/core/controller /binding/scaffold_screen_binding.dart';
// import 'src/auth/ui/login_screen.dart';
// import 'src/services/apis/api_services.dart';
// import 'src/services/sharedpref.dart';
// import 'src/auth/ui/scaffold_screen.dart';
// import 'src/auth/ui/splash_screen.dart'; // ← Add this
// import 'src/theme/colors.dart';

// final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
//     FlutterLocalNotificationsPlugin();

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();

//   // Initialize timezone for notifications
//   tz.initializeTimeZones();

//   // Initialize notifications
//   const AndroidInitializationSettings androidSettings =
//       AndroidInitializationSettings('@mipmap/ic_launcher');
//   const DarwinInitializationSettings iosSettings =
//       DarwinInitializationSettings();

//   const InitializationSettings initSettings = InitializationSettings(
//     android: androidSettings,
//     iOS: iosSettings,
//   );

//   await flutterLocalNotificationsPlugin.initialize(initSettings);

//   // Initialize SharedPreferences
//   await AppSharedPref.init();

//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     // AppSharedPref.instance.clearAllUserData();
//     Get.put(ApiServices());
//     return ScreenUtilInit(
//       designSize: MediaQuery.sizeOf(
//         context,
//       ), //const Size(375, 812), // iPhone 13 mini as base
//       minTextAdapt: true,
//       splitScreenMode: true,
//       builder: (context, child) {
//         return GetMaterialApp(
//           title: 'Asia Fibernet',
//           debugShowCheckedModeBanner: false,
//           theme: ThemeData(
//             primaryColor: AppColors.primary,
//             colorScheme: ColorScheme.light(
//               primary: AppColors.primary,
//               secondary: AppColors.secondary,
//             ),
//             textTheme: GoogleFonts.poppinsTextTheme(
//               ThemeData.light().textTheme,
//             ),
//             scaffoldBackgroundColor: AppColors.backgroundLight,
//             appBarTheme: AppBarTheme(
//               backgroundColor: AppColors.cardBackground,
//               elevation: 0,
//               iconTheme: IconThemeData(color: AppColors.primary),
//               titleTextStyle: GoogleFonts.poppins(
//                 fontSize: 20.sp,
//                 fontWeight: FontWeight.bold,
//                 color: AppColors.textColorPrimary,
//               ),
//             ),
//             elevatedButtonTheme: ElevatedButtonThemeData(
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primary,
//                 foregroundColor: Colors.white,
//                 textStyle: GoogleFonts.poppins(
//                   fontSize: 16.sp,
//                   fontWeight: FontWeight.bold,
//                 ),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12.r),
//                 ),
//                 elevation: 0,
//               ),
//             ),
//             textButtonTheme: TextButtonThemeData(
//               style: TextButton.styleFrom(
//                 textStyle: GoogleFonts.poppins(
//                   fontSize: 16.sp,
//                   fontWeight: FontWeight.w500,
//                   color: AppColors.primary,
//                 ),
//               ),
//             ),
//           ),
//           initialBinding:
//               LoginBinding(), // Will be used when navigating to login
//           initialRoute: '/splash',
//           getPages: [
//             GetPage(name: '/splash', page: () => SplashScreen()),
//             GetPage(
//               name: '/login',
//               page: () => LoginScreen(),
//               binding: LoginBinding(),
//             ),
//             GetPage(
//               name: '/home',
//               page: () => ScaffoldScreen(),
//               binding: ScaffoldScreenBinding(),
//             ),
//             // Add more routes as needed
//           ],
//           // Optional: Add middleware for route protection
//           // middleware: [AuthMiddleware()],
//         );
//       },
//     );
//   }
// }

// // Model classes
// class Registration {
//   final int id;
//   final String fullName;
//   final String mobileNumber;
//   final String email;
//   final String city;
//   final String state;
//   final String connectionType;
//   final int aadharVerified;
//   final int pancardVerified;
//   final int addressVerified;

//   Registration({
//     required this.id,
//     required this.fullName,
//     required this.mobileNumber,
//     required this.email,
//     required this.city,
//     required this.state,
//     required this.connectionType,
//     required this.aadharVerified,
//     required this.pancardVerified,
//     required this.addressVerified,
//   });

//   factory Registration.fromJson(Map<String, dynamic> json) {
//     return Registration(
//       id: json['id'],
//       fullName: json['full_name'],
//       mobileNumber: json['mobile_number'],
//       email: json['email'],
//       city: json['city'] ?? '',
//       state: json['state'] ?? '',
//       connectionType: json['connection_type'] ?? '',
//       aadharVerified: json['aadhar_verified'],
//       pancardVerified: json['pancard_verified'],
//       addressVerified: json['address_verified'],
//     );
//   }
// }

// class Document {
//   final int id;
//   final String type;
//   final String verificationStatus;
//   final String documentFrontUrl;
//   final String? documentBackUrl;
//   final String profileImageUrl;
//   final String issue;

//   Document({
//     required this.id,
//     required this.type,
//     required this.verificationStatus,
//     required this.documentFrontUrl,
//     this.documentBackUrl,
//     required this.profileImageUrl,
//     required this.issue,
//   });

//   factory Document.fromJson(Map<String, dynamic> json) {
//     return Document(
//       id: json['id'],
//       type: json['type'],
//       verificationStatus: json['verification_status'],
//       documentFrontUrl: json['document_front_url'],
//       documentBackUrl: json['document_back_url'],
//       profileImageUrl: json['profile_image_url'],
//       issue: json['issue'],
//     );
//   }
// }

// class TrackingStatus {
//   final bool basicDetails;
//   final bool feasibility;
//   final bool technicianAssign;
//   final bool kycVerification;
//   final Map<String, dynamic> modemInstallation;
//   final String feedback;
//   final String issue;

//   TrackingStatus({
//     required this.basicDetails,
//     required this.feasibility,
//     required this.technicianAssign,
//     required this.kycVerification,
//     required this.modemInstallation,
//     required this.feedback,
//     required this.issue,
//   });

//   factory TrackingStatus.fromJson(Map<String, dynamic> json) {
//     return TrackingStatus(
//       basicDetails: json['basic_details'],
//       feasibility: json['feasibilty'],
//       technicianAssign: json['techinician_asgin'],
//       kycVerification: json['kyc_verification'],
//       modemInstallation: json['modem_installation'],
//       feedback: json['feedback'],
//       issue: json['issue'],
//     );
//   }
// }

// class Technician {
//   final int id;
//   final String contactName;
//   final String companyName;
//   final String address;
//   final String city;
//   final String state;
//   final int workPhoneNumber;
//   final int cellPhoneNumber;
//   final String email;

//   Technician({
//     required this.id,
//     required this.contactName,
//     required this.companyName,
//     required this.address,
//     required this.city,
//     required this.state,
//     required this.workPhoneNumber,
//     required this.cellPhoneNumber,
//     required this.email,
//   });

//   factory Technician.fromJson(Map<String, dynamic> json) {
//     return Technician(
//       id: json['ID'],
//       contactName: json['ContactName'],
//       companyName: json['CompanyName'],
//       address: json['Address'],
//       city: json['City'],
//       state: json['State'],
//       workPhoneNumber: json['Workphnumber'],
//       cellPhoneNumber: json['Cellphnumber'],
//       email: json['Email'],
//     );
//   }
// }

// // Controller
// class DashboardController extends GetxController {
//   var registration =
//       Registration(
//         id: 0,
//         fullName: '',
//         mobileNumber: '',
//         email: '',
//         city: '',
//         state: '',
//         connectionType: '',
//         aadharVerified: 0,
//         pancardVerified: 0,
//         addressVerified: 0,
//       ).obs;

//   var documents = <Document>[].obs;
//   var trackingStatus =
//       TrackingStatus(
//         basicDetails: false,
//         feasibility: false,
//         technicianAssign: false,
//         kycVerification: false,
//         modemInstallation: {},
//         feedback: '',
//         issue: '',
//       ).obs;

//   var technician =
//       Technician(
//         id: 0,
//         contactName: '',
//         companyName: '',
//         address: '',
//         city: '',
//         state: '',
//         workPhoneNumber: 0,
//         cellPhoneNumber: 0,
//         email: '',
//       ).obs;

//   var connectionStatus = 'Pending'.obs;
//   var serviceStatus = 'feasible'.obs;

//   @override
//   void onInit() {
//     super.onInit();
//     // Simulate API data loading
//     loadData();
//   }

//   void loadData() {
//     // Simulating the JSON data you provided
//     registration(
//       Registration.fromJson({
//         "id": 64,
//         "full_name": "testing2",
//         "mobile_number": "1346790134",
//         "email": "testing2@gmail.com",
//         "city": "phulera",
//         "state": "bihar",
//         "connection_type": "WiFi",
//         "aadhar_verified": 0,
//         "pancard_verified": 0,
//         "address_verified": 0,
//       }),
//     );

//     documents.add(
//       Document.fromJson({
//         "id": 141,
//         "type": "PAN",
//         "verification_status": "pending",
//         "document_front_url": "uploads/documents/pan_front_1758197497_2911.jpg",
//         "document_back_url": null,
//         "profile_image_url": "uploads/documents/profile_1758197497_1090.jpg",
//         "issue": "",
//       }),
//     );

//     trackingStatus(
//       TrackingStatus.fromJson({
//         "basic_details": true,
//         "feasibilty": true,
//         "techinician_asgin": true,
//         "kyc_verification": true,
//         "modem_installation": {
//           "status": true,
//           "modem": {
//             "modem_id": 12,
//             "modem_number": 1132,
//             "modem_features": ["features"],
//             "message": "modem is generated and your plain is this ...",
//           },
//         },
//         "feedback": "",
//         "issue": "rejected file related issue",
//       }),
//     );

//     technician(
//       Technician.fromJson({
//         "ID": 99,
//         "ContactName": "Akhil",
//         "CompanyName": "infosys",
//         "Address": "Mumbai",
//         "City": "Mumbai",
//         "State": "Maharashtra",
//         "Workphnumber": 9384756923,
//         "Cellphnumber": 9302934875,
//         "Email": "Akhil@gmail.com",
//       }),
//     );

//     connectionStatus("Pending");
//     serviceStatus("feasible");
//   }
// }

// // Main Dashboard Screen
// class CustomerDashboard extends StatelessWidget {
//   final DashboardController controller = Get.put(DashboardController());

//   CustomerDashboard({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.backgroundLight,
//       appBar: AppBar(
//         title: Text(
//           'My Dashboard',
//           style: AppText.headingMedium.copyWith(color: Colors.white),
//         ),
//         backgroundColor: AppColors.primary,
//         elevation: 0,
//         centerTitle: true,
//         iconTheme: const IconThemeData(color: Colors.white),
//       ),
//       body: SingleChildScrollView(
//         padding: EdgeInsets.all(16.w),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             _buildWelcomeCard(),
//             SizedBox(height: 20.h),
//             _buildKYCStatus(),
//             SizedBox(height: 20.h),
//             _buildConnectionProgress(),
//             SizedBox(height: 20.h),
//             _buildTechnicianInfo(),
//             SizedBox(height: 20.h),
//             _buildDocumentStatus(),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildWelcomeCard() {
//     return Obx(
//       () => Container(
//         width: double.infinity,
//         padding: EdgeInsets.all(16.w),
//         decoration: BoxDecoration(
//           gradient: const LinearGradient(
//             colors: [
//               AppColors.backgroundGradientStart,
//               AppColors.backgroundGradientEnd,
//             ],
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//           ),
//           borderRadius: BorderRadius.circular(16.r),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 10,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               'Welcome, ${controller.registration.value.fullName}!',
//               style: AppText.headingMedium.copyWith(color: Colors.white),
//             ),
//             SizedBox(height: 8.h),
//             Text(
//               'Your connection is ${controller.connectionStatus.value}',
//               style: AppText.bodyMedium.copyWith(
//                 color: Colors.white.withOpacity(0.9),
//               ),
//             ),
//             SizedBox(height: 16.h),
//             Container(
//               padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
//               decoration: BoxDecoration(
//                 color: Colors.white.withOpacity(0.2),
//                 borderRadius: BorderRadius.circular(20.r),
//               ),
//               child: Text(
//                 'Service Status: ${controller.serviceStatus.value.toUpperCase()}',
//                 style: AppText.labelMedium.copyWith(color: Colors.white),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildKYCStatus() {
//     return Obx(
//       () => Container(
//         width: double.infinity,
//         padding: EdgeInsets.all(16.w),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(16.r),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 10,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('KYC Verification Status', style: AppText.headingSmall),
//             SizedBox(height: 16.h),
//             _buildKYCStep(
//               title: 'PAN Card Verification',
//               status: controller.registration.value.pancardVerified == 1,
//               isPending:
//                   controller.documents.isNotEmpty &&
//                   controller.documents.first.type == 'PAN' &&
//                   controller.documents.first.verificationStatus == 'pending',
//             ),
//             _buildStepConnector(),
//             _buildKYCStep(
//               title: 'Aadhar Verification',
//               status: controller.registration.value.aadharVerified == 1,
//             ),
//             _buildStepConnector(),
//             _buildKYCStep(
//               title: 'Address Verification',
//               status: controller.registration.value.addressVerified == 1,
//             ),
//             SizedBox(height: 16.h),
//             if (controller.trackingStatus.value.issue.isNotEmpty)
//               Container(
//                 padding: EdgeInsets.all(12.w),
//                 decoration: BoxDecoration(
//                   color: AppColors.error.withOpacity(0.1),
//                   borderRadius: BorderRadius.circular(8.r),
//                 ),
//                 child: Row(
//                   children: [
//                     Icon(
//                       Icons.error_outline,
//                       color: AppColors.error,
//                       size: 20.w,
//                     ),
//                     SizedBox(width: 8.w),
//                     Expanded(
//                       child: Text(
//                         controller.trackingStatus.value.issue,
//                         style: AppText.bodySmall.copyWith(
//                           color: AppColors.error,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             SizedBox(height: 12.h),
//             ElevatedButton(
//               onPressed: () {
//                 // Navigate to KYC completion screen
//                 Get.snackbar(
//                   'Action Required',
//                   'Please complete your KYC documents',
//                   backgroundColor: AppColors.primaryLight,
//                   colorText: Colors.white,
//                 );
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primary,
//                 foregroundColor: Colors.white,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8.r),
//                 ),
//                 padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 24.w),
//               ),
//               child: Text('Complete KYC', style: AppText.button),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildKYCStep({
//     required String title,
//     required bool status,
//     bool isPending = false,
//   }) {
//     return Row(
//       children: [
//         Container(
//           width: 24.w,
//           height: 24.h,
//           decoration: BoxDecoration(
//             shape: BoxShape.circle,
//             color:
//                 status
//                     ? AppColors.success
//                     : isPending
//                     ? AppColors.warning
//                     : AppColors.textColorHint,
//           ),
//           child: Icon(
//             status
//                 ? Icons.check
//                 : (isPending ? Icons.access_time : Icons.pending),
//             color: Colors.white,
//             size: 16.w,
//           ),
//         ),
//         SizedBox(width: 12.w),
//         Expanded(
//           child: Text(
//             title,
//             style:
//                 status
//                     ? AppText.bodyLarge.copyWith(color: AppColors.successDark)
//                     : AppText.bodyLarge,
//           ),
//         ),
//         Text(
//           status ? 'Verified' : (isPending ? 'Pending' : 'Not Started'),
//           style:
//               status
//                   ? AppText.labelSmall.copyWith(color: AppColors.success)
//                   : AppText.labelSmall.copyWith(
//                     color:
//                         isPending
//                             ? AppColors.warning
//                             : AppColors.textColorSecondary,
//                   ),
//         ),
//       ],
//     );
//   }

//   Widget _buildStepConnector() {
//     return Container(
//       margin: EdgeInsets.only(left: 11.w, top: 4.h, bottom: 4.h),
//       width: 2.w,
//       height: 20.h,
//       color: AppColors.dividerColor,
//     );
//   }

//   Widget _buildConnectionProgress() {
//     return Obx(
//       () => Container(
//         width: double.infinity,
//         padding: EdgeInsets.all(16.w),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(16.r),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 10,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Connection Progress', style: AppText.headingSmall),
//             SizedBox(height: 16.h),
//             _buildProgressStep(
//               'Basic Details',
//               controller.trackingStatus.value.basicDetails,
//             ),
//             _buildStepConnector(),
//             _buildProgressStep(
//               'Feasibility Check',
//               controller.trackingStatus.value.feasibility,
//             ),
//             _buildStepConnector(),
//             _buildProgressStep(
//               'Technician Assigned',
//               controller.trackingStatus.value.technicianAssign,
//             ),
//             _buildStepConnector(),
//             _buildProgressStep(
//               'KYC Verification',
//               controller.trackingStatus.value.kycVerification,
//             ),
//             _buildStepConnector(),
//             _buildProgressStep(
//               'Modem Installation',
//               controller.trackingStatus.value.modemInstallation['status'] ??
//                   false,
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildProgressStep(String title, bool completed) {
//     return Row(
//       children: [
//         Container(
//           width: 24.w,
//           height: 24.h,
//           decoration: BoxDecoration(
//             shape: BoxShape.circle,
//             color: completed ? AppColors.success : AppColors.textColorHint,
//           ),
//           child: Icon(
//             completed ? Icons.check : Icons.radio_button_unchecked,
//             color: Colors.white,
//             size: 16.w,
//           ),
//         ),
//         SizedBox(width: 12.w),
//         Expanded(
//           child: Text(
//             title,
//             style:
//                 completed
//                     ? AppText.bodyLarge.copyWith(color: AppColors.successDark)
//                     : AppText.bodyLarge,
//           ),
//         ),
//       ],
//     );
//   }

//   Widget _buildTechnicianInfo() {
//     return Obx(
//       () => Container(
//         width: double.infinity,
//         padding: EdgeInsets.all(16.w),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(16.r),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 10,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Assigned Technician', style: AppText.headingSmall),
//             SizedBox(height: 16.h),
//             ListTile(
//               contentPadding: EdgeInsets.zero,
//               leading: Container(
//                 width: 50.w,
//                 height: 50.h,
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: AppColors.primaryLight,
//                 ),
//                 child: Icon(Icons.person, color: Colors.white, size: 30.w),
//               ),
//               title: Text(
//                 controller.technician.value.contactName,
//                 style: AppText.bodyLarge.copyWith(fontWeight: FontWeight.bold),
//               ),
//               subtitle: Text(
//                 controller.technician.value.companyName,
//                 style: AppText.bodyMedium,
//               ),
//               trailing: IconButton(
//                 icon: Icon(Icons.phone, color: AppColors.primary),
//                 onPressed: () {
//                   // Implement call functionality
//                   Get.snackbar(
//                     'Calling',
//                     'Calling ${controller.technician.value.contactName}',
//                     backgroundColor: AppColors.success,
//                     colorText: Colors.white,
//                   );
//                 },
//               ),
//             ),
//             SizedBox(height: 8.h),
//             Row(
//               children: [
//                 Icon(
//                   Icons.location_on,
//                   size: 16.w,
//                   color: AppColors.textColorSecondary,
//                 ),
//                 SizedBox(width: 4.w),
//                 Text(
//                   '${controller.technician.value.address}, ${controller.technician.value.city}',
//                   style: AppText.bodySmall,
//                 ),
//               ],
//             ),
//             SizedBox(height: 4.h),
//             Row(
//               children: [
//                 Icon(
//                   Icons.phone,
//                   size: 16.w,
//                   color: AppColors.textColorSecondary,
//                 ),
//                 SizedBox(width: 4.w),
//                 Text(
//                   controller.technician.value.cellPhoneNumber.toString(),
//                   style: AppText.bodySmall,
//                 ),
//               ],
//             ),
//             SizedBox(height: 4.h),
//             Row(
//               children: [
//                 Icon(
//                   Icons.email,
//                   size: 16.w,
//                   color: AppColors.textColorSecondary,
//                 ),
//                 SizedBox(width: 4.w),
//                 Text(
//                   controller.technician.value.email,
//                   style: AppText.bodySmall,
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildDocumentStatus() {
//     return Obx(
//       () => Container(
//         width: double.infinity,
//         padding: EdgeInsets.all(16.w),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(16.r),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 10,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Document Status', style: AppText.headingSmall),
//             SizedBox(height: 16.h),
//             if (controller.documents.isEmpty)
//               Text(
//                 'No documents uploaded yet',
//                 style: AppText.bodyMedium.copyWith(
//                   color: AppColors.textColorSecondary,
//                 ),
//               )
//             else
//               ...controller.documents.map(
//                 (document) => Column(
//                   children: [
//                     ListTile(
//                       contentPadding: EdgeInsets.zero,
//                       leading: Container(
//                         width: 40.w,
//                         height: 40.h,
//                         decoration: BoxDecoration(
//                           shape: BoxShape.circle,
//                           color: _getDocumentColor(document.verificationStatus),
//                         ),
//                         child: Icon(
//                           _getDocumentIcon(document.verificationStatus),
//                           color: Colors.white,
//                           size: 20.w,
//                         ),
//                       ),
//                       title: Text(document.type, style: AppText.bodyLarge),
//                       subtitle: Text(
//                         'Status: ${document.verificationStatus}',
//                         style: AppText.bodySmall.copyWith(
//                           color: _getStatusColor(document.verificationStatus),
//                         ),
//                       ),
//                       trailing: IconButton(
//                         icon: Icon(Icons.visibility, color: AppColors.primary),
//                         onPressed: () {
//                           // View document
//                           Get.snackbar(
//                             'Document View',
//                             'Viewing ${document.type} document',
//                             backgroundColor: AppColors.info,
//                             colorText: Colors.white,
//                           );
//                         },
//                       ),
//                     ),
//                     if (document.issue.isNotEmpty)
//                       Container(
//                         padding: EdgeInsets.all(8.w),
//                         margin: EdgeInsets.only(bottom: 8.h),
//                         decoration: BoxDecoration(
//                           color: AppColors.error.withOpacity(0.1),
//                           borderRadius: BorderRadius.circular(4.r),
//                         ),
//                         child: Row(
//                           children: [
//                             Icon(
//                               Icons.error_outline,
//                               size: 14.w,
//                               color: AppColors.error,
//                             ),
//                             SizedBox(width: 4.w),
//                             Expanded(
//                               child: Text(
//                                 document.issue,
//                                 style: AppText.labelSmall.copyWith(
//                                   color: AppColors.error,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                   ],
//                 ),
//               ),
//             SizedBox(height: 12.h),
//             ElevatedButton(
//               onPressed: () {
//                 // Upload documents
//                 Get.snackbar(
//                   'Upload Document',
//                   'Please select document to upload',
//                   backgroundColor: AppColors.primary,
//                   colorText: Colors.white,
//                 );
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primary,
//                 foregroundColor: Colors.white,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8.r),
//                 ),
//                 padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 24.w),
//               ),
//               child: Text('Upload Documents', style: AppText.button),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Color _getDocumentColor(String status) {
//     switch (status) {
//       case 'verified':
//         return AppColors.success;
//       case 'pending':
//         return AppColors.warning;
//       case 'rejected':
//         return AppColors.error;
//       default:
//         return AppColors.textColorHint;
//     }
//   }

//   IconData _getDocumentIcon(String status) {
//     switch (status) {
//       case 'verified':
//         return Icons.check_circle;
//       case 'pending':
//         return Icons.access_time;
//       case 'rejected':
//         return Icons.error;
//       default:
//         return Icons.description;
//     }
//   }

//   Color _getStatusColor(String status) {
//     switch (status) {
//       case 'verified':
//         return AppColors.success;
//       case 'pending':
//         return AppColors.warning;
//       case 'rejected':
//         return AppColors.error;
//       default:
//         return AppColors.textColorSecondary;
//     }
//   }
// }


// import 'package:flutter/widgets.dart';
// import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:get/route_manager.dart';
// import 'services/routes.dart';



// /// The Widget that configures your application.
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return GetMaterialApp(
//       localizationsDelegates: const [
//         // AppLocalizations.delegate,
//         GlobalMaterialLocalizations.delegate,
//         GlobalWidgetsLocalizations.delegate,
//         GlobalCupertinoLocalizations.delegate,
//       ],
//       supportedLocales: const [
//         Locale('en', ''), // English, no country code
//       ],
//       // onGenerateTitle: (BuildContext context) =>
//       //     AppLocalizations.of(context)!.appTitle,
//       // darkTheme: ThemeData.dark(),
//       routes: AppRoutes.routes,
//       // home: const HomeScreen(),
//     );
//   }
// }



// import 'package:flutter/material.dart';

// class AppColors {
//   // Primary Orange Colors (dominant color from logo)
//   static const Color primary = Color(0xFFF57C00); // Vibrant orange
//   static const Color primaryDark = Color(0xFFBB4D00); // Darker orange
//   static const Color primaryLight = Color(0xFFFFAD42); // Lighter orange

//   // Secondary Colors (complementary blues)
//   static const Color secondary = Color(0xFF1976D2); // Rich blue
//   static const Color secondaryDark = Color(0xFF004BA0);
//   static const Color secondaryLight = Color(0xFF63A4FF);

//   // Background Colors
//   static const Color backgroundLight = Color(0xFFFAFAFA); // Very light grey
//   static const Color backgroundDark = Color(0xFF121212); // For dark mode
//   static const Color backgroundGradientStart = Color(
//     0xFFF57C00,
//   ); // Primary orange
//   static const Color backgroundGradientEnd = Color(
//     0xFFEF6C00,
//   ); // Slightly darker orange

//   // Surface Colors
//   static const Color cardBackground = Colors.white;
//   static const Color cardBackgroundDark = Color(0xFF1E1E1E);

//   // Input Fields
//   static const Color inputBackground = Color(0xFFEEEEEE);
//   static const Color inputBackgroundDark = Color(0xFF2D2D2D);

//   // Text Colors
//   static const Color textColorPrimary = Color(0xFF212121); // Near black
//   static const Color textColorSecondary = Color(0xFF757575); // Medium grey
//   static const Color textColorHint = Color(0xFFBDBDBD); // Light grey
//   static const Color textColorLight = Colors.white; // For dark backgrounds

//   // Status Colors
//   static const Color success = Color(0xFF43A047); // Softer green
//   static const Color successDark = Color(0xFF2E7D32);
//   static const Color warning = Color(0xFFFFA000); // Amber warning
//   static const Color error = Color(0xFFE53935); // Red error
//   static const Color info = Color(0xFF1E88E5); // Blue info

//   // Divider
//   static const Color dividerColor = Color(0xFFE0E0E0);
//   static const Color dividerColorDark = Color(0xFF424242);

//   // Accent Colors
//   static const Color accent1 = Color(0xFFFDD835); // Yellow accent
//   static const Color accent2 = Color(0xFF5C6BC0); // Indigo accent
// }



// // theme.dart
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'colors.dart';

// class AppText {
//   // Headings
//   static TextStyle headingLarge = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 24.sp,
//     fontWeight: FontWeight.bold,
//     color: AppColors.textColorPrimary,
//   );

//   static TextStyle headingMedium = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 22.sp,
//     fontWeight: FontWeight.bold,
//     color: AppColors.textColorPrimary,
//   );

//   static TextStyle headingSmall = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 20.sp,
//     fontWeight: FontWeight.bold,
//     color: AppColors.textColorPrimary,
//   );

//   // Body Text
//   static TextStyle bodyLarge = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 16.sp,
//     fontWeight: FontWeight.normal,
//     color: AppColors.textColorPrimary,
//   );

//   static TextStyle bodyMedium = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 14.sp,
//     fontWeight: FontWeight.normal,
//     color: AppColors.textColorSecondary,
//   );

//   static TextStyle bodySmall = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 12.sp,
//     fontWeight: FontWeight.normal,
//     color: AppColors.textColorSecondary,
//   );

//   // Labels / Captions
//   static TextStyle labelLarge = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 16.sp,
//     fontWeight: FontWeight.w500,
//     color: AppColors.textColorPrimary,
//   );

//   static TextStyle labelMedium = GoogleFonts.poppins(
//     fontSize: 14.sp,
//     fontWeight: FontWeight.w500,
//     color: AppColors.textColorPrimary,
//   );

//   static TextStyle labelSmall = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 12.sp,
//     fontWeight: FontWeight.normal,
//     color: AppColors.textColorSecondary,
//   );

//   // Buttons
//   static TextStyle button = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 16.sp,
//     fontWeight: FontWeight.bold,
//     color: Colors.white,
//   );

//   // Links / Action Text
//   static TextStyle link = GoogleFonts.poppins(
//     textStyle: TextStyle(overflow: TextOverflow.ellipsis),
//     fontSize: 16.sp,
//     fontWeight: FontWeight.w500,
//     color: AppColors.primary,
//   );
// }


// /// auth

// import 'package:get/get.dart';

// import '../../../../services/apis/api_services.dart';
// import '../login_controller.dart';

// /// Binding class to manage dependencies for the LoginScreen.
// class LoginBinding implements Bindings {
//   @override
//   void dependencies() {
//     // Use Get.lazyPut for lazy initialization (controller created when first needed)
//     Get.lazyPut<LoginController>(() => LoginController());
//     Get.lazyPut<ApiServices>(() => ApiServices());
//   }
// }


// import 'package:get/get.dart';
// // Adjust the import path according to your project structure
// import '../otp_controller.dart'; // Or wherever OTPController is

// /// Binding class for OTPScreen.
// /// Responsible for creating the OTPController with the required phone number.
// class OTPBinding implements Bindings {
//   final String phoneNumber;
//   final String token;
//   final int userID;
//   bool? underReview;

//   OTPBinding({
//     required this.phoneNumber,
//     required this.token,
//     required this.userID,
//     this.underReview,
//   });

//   @override
//   void dependencies() {
//     // Register the OTPController, passing the phone number.
//     // Get.lazyPut creates it only when first accessed (e.g., when OTPScreen is built).
//     Get.lazyPut<OTPController>(
//       () => OTPController(
//         phone: phoneNumber,
//         token: token,
//         userID: userID,
//         underReview: underReview,
//       ),
//     );
//     // Or Get.put for immediate creation (less common for this case).
//     // Get.put(OTPController(phone: phoneNumber));
//   }
// }


// import 'package:get/get.dart';

// import '../../../../customer/ui/screen/pages/home_page.dart';
// import '../../../../customer/ui/screen/pages/referral_screen.dart';
// import '../customer_complaint_controller.dart';

// /// Binding class to manage dependencies for the LoginScreen.
// class ScaffoldScreenBinding implements Bindings {
//   @override
//   void dependencies() {
//     // Use Get.lazyPut for lazy initialization (controller created when first needed)
//     Get.lazyPut<HomeController>(() => HomeController());
//     Get.lazyPut<ComplaintController>(() => ComplaintController());
//     Get.lazyPut<ReferralController>(() => ReferralController());
//     // Get.lazyPut<ApiServices>(() => ApiServices());
//   }
// }


// import 'dart:async';
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'dart:developer' as developer;

// import '../../../theme/colors.dart';
// import '../../../theme/theme.dart';
// import '../../../customer/core/models/customer_view_complaint_model.dart';
// import '../../../customer/core/models/ticket_category_model.dart';
// import '../../../services/apis/api_services.dart';
// import '../../../services/sharedpref.dart';
// import '../../../services/utils/notification_helper.dart';

// class ComplaintController extends GetxController {
//   final complaints = <ComplaintViewModel>[].obs;
//   final RxString selectedFilter = 'All'.obs;

//   // With separate loading flags
//   final RxBool isComplaintsLoading = true.obs;
//   final RxBool isCategoriesLoading = true.obs;
//   final Rx<File?> uploadedImage = Rx<File?>(null);
//   final ticketCategories = <CategoryData>[].obs;

//   // Deletion state
//   final _complaintToDelete = Rx<ComplaintViewModel?>(null);
//   final RxBool isDeleting = false.obs;

//   // Categories state
//   final RxList<String> complaintCategories = <String>[].obs;

//   final ApiServices apiServices = ApiServices();
//   Timer? _pollingTimer;

//   List<String> get filterOptions => ['All', 'Open', 'Resolved'];

//   List<ComplaintViewModel> get filteredComplaints {
//     if (selectedFilter.value == 'All') return complaints;
//     return complaints.where((c) {
//       if (selectedFilter.value == 'Open') return c.isOpen;
//       if (selectedFilter.value == 'Resolved') return c.isResolved;
//       return true;
//     }).toList();
//   }

//   // 👇 NEW: Count of open complaints
//   int get openComplaintCount {
//     return complaints.where((c) => c.isOpen).length;
//   }

//   // 👇 NEW: Can user submit? Only if < 5 open complaints
//   bool get canSubmitNewComplaint {
//     return openComplaintCount < 5;
//   }

//   // 👇 Old: Just tells if ANY complaint is open (still useful for UI hints)
//   bool get hasActiveComplaint {
//     return complaints.any((c) => c.isOpen);
//   }

//   @override
//   void onInit() {
//     super.onInit();
//     fetchTicketCategories();
//     fetchComplaints();
//     _startPolling();

//     ever(_complaintToDelete, (ComplaintViewModel? complaint) {
//       if (complaint != null) {
//         _showDeleteConfirmationDialog(complaint);
//       }
//     });
//   }

//   ComplaintViewModel? get complaintToDelete => _complaintToDelete.value;

//   @override
//   void onClose() {
//     _pollingTimer?.cancel();
//     super.onClose();
//   }

//   void _startPolling() {
//     _pollingTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
//       fetchComplaints();
//     });
//   }

//   Future<void> fetchComplaints() async {
//     isComplaintsLoading.value = true;
//     try {
//       final int? customerId = AppSharedPref.instance.getUserID();
//       if (customerId == null) {
//         Get.snackbar("Error", "User not logged in");
//         Get.offAllNamed('/');
//         return;
//       }

//       final result = await apiServices.viewComplaint(customerId);
//       if (result != null) {
//         for (var newComplaint in result) {
//           final existing = complaints.firstWhereOrNull(
//             (c) => c.id == newComplaint.id,
//           );
//           if (existing != null && existing.status != newComplaint.status) {
//             _notifyStatusChange(newComplaint);
//           }
//         }
//         complaints.assignAll(result);
//       }
//     } catch (e) {
//       Get.snackbar("Error", "Failed to load complaints: $e");
//     } finally {
//       isComplaintsLoading.value = false;
//     }
//   }

//   Future<void> fetchTicketCategories() async {
//     isCategoriesLoading.value = true;
//     try {
//       final response = await apiServices.getTicketCategory();
//       if (response != null) {
//         ticketCategories.value = response.data;
//       } else {
//         Get.snackbar("Error", "Could not load categories");
//       }
//     } catch (e, stackTrace) {
//       developer.log(
//         "Failed to load ticket categories: $e",
//         error: e,
//         stackTrace: stackTrace,
//       );
//       Get.snackbar(
//         "Error",
//         "Failed to load categories. Please check your connection.",
//       );
//     } finally {
//       isCategoriesLoading.value = false;
//     }
//   }

//   Future<void> refreshComplaints() async {
//     await fetchComplaints();
//   }

//   void setSelectedFilter(String filter) {
//     selectedFilter.value = filter;
//   }

//   // 👇 UPDATED: Block submission if 5+ open complaints
//   Future<void> addComplaint({
//     required String category,
//     required String subCategory,
//     String? description,
//     File? image,
//   }) async {
//     // ✅ BLOCK if 5 or more open complaints
//     if (!canSubmitNewComplaint) {
//       Get.snackbar(
//         "Limit Reached",
//         "You can only have up to 5 open complaints at a time. Please wait until some are resolved.",
//         backgroundColor: AppColors.error.withOpacity(0.1),
//         colorText: AppColors.error,
//         icon: Icon(Icons.warning_amber_rounded, color: AppColors.error),
//         duration: Duration(seconds: 4),
//       );
//       return;
//     }

//     final String? mobile = await AppSharedPref.instance.getMobileNumber();
//     if (mobile == null) {
//       Get.snackbar("Error", "Mobile number not found");
//       return;
//     }

//     final success = await apiServices.raiseComplaint(
//       mobile: mobile,
//       title: category,
//       subCategory: subCategory,
//       description: description!,
//       image: image,
//     );

//     if (success) {
//       await fetchComplaints();
//       NotificationHelper.showNotification(
//         title: "Complaint Submitted",
//         body:
//             "Your request has been successfully submitted. We'll review it shortly.",
//       );
//       uploadedImage.value = null;
//       Get.back();
//       Get.snackbar("Success", "Your complaint has been submitted!");
//     }
//   }

//   Future<bool> closeComplaint({
//     required ComplaintViewModel complaint,
//     required String resolution,
//     required int rating,
//   }) async {
//     await Future.delayed(const Duration(seconds: 1));
//     final updated = complaint.copyWith(status: "closed");
//     complaints.remove(complaint);
//     complaints.insert(0, updated);

//     NotificationHelper.showNotification(
//       title: "Complaint Resolved",
//       body:
//           "Your complaint #${complaint.ticketNo} has been closed. Thank you for your feedback!",
//     );

//     Get.snackbar("Success", "Complaint closed and technician rated!");
//     return true;
//   }

//   void markForDeletion(ComplaintViewModel complaint) {
//     if (!complaint.isOpen) {
//       Get.snackbar(
//         "Cannot Delete",
//         "Only open complaints can be canceled.",
//         backgroundColor: AppColors.textColorHint.withOpacity(0.2),
//         colorText: AppColors.textColorHint,
//         icon: Icon(Icons.info, color: AppColors.textColorHint),
//       );
//       return;
//     }
//     _complaintToDelete.value = complaint;
//   }

//   void _showDeleteConfirmationDialog(ComplaintViewModel complaint) {
//     Get.dialog(
//       WillPopScope(
//         onWillPop: () async => !isDeleting.value,
//         child: AlertDialog(
//           title: Text("Cancel Request?", style: AppText.headingSmall),
//           content: Text("Are you sure you want to delete this complaint?"),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 if (!isDeleting.value) {
//                   _complaintToDelete.value = null;
//                 }
//                 Get.back(); // 👈 Fixed: Only call once
//               },
//               child: Text(
//                 "No",
//                 style: AppText.button.copyWith(
//                   color: AppColors.textColorSecondary,
//                 ),
//               ),
//             ),
//             Obx(
//               () => ElevatedButton(
//                 onPressed:
//                     isDeleting.value ? null : () => _confirmDelete(complaint),
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: AppColors.error,
//                 ),
//                 child:
//                     isDeleting.value
//                         ? SizedBox(
//                           height: 20,
//                           width: 20,
//                           child: CircularProgressIndicator(
//                             strokeWidth: 2,
//                             valueColor: AlwaysStoppedAnimation<Color>(
//                               Colors.white,
//                             ),
//                           ),
//                         )
//                         : Text("Yes", style: AppText.button),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Future<void> _confirmDelete(ComplaintViewModel complaint) async {
//     isDeleting.value = true;
//     try {
//       final int? customerId = await AppSharedPref.instance.getUserID();
//       final String? mobile = await AppSharedPref.instance.getMobileNumber();

//       if (customerId == null || mobile == null) {
//         Get.snackbar(
//           "Error",
//           "User information not found. Please log in again.",
//         );
//         return;
//       }

//       final isSuccess = await apiServices.closeComplaint(
//         customerId: customerId,
//         ticketNo: complaint.ticketNo,
//         closedRemark: "Complaint canceled by user.",
//         mobile: mobile,
//         rating: 0,
//       );

//       if (isSuccess) {
//         complaint.isDeleted.value = 0.0;
//         await Future.delayed(Duration(milliseconds: 300));
//         complaints.remove(complaint);
//         Get.snackbar("Deleted", "Your complaint has been canceled.");
//         if (Get.isDialogOpen == true) Get.back();
//         // ✅ Optional: Uncomment below if you want to force-sync with server
//         // await fetchComplaints();
//       } else {
//         Get.snackbar("Error", "Failed to cancel complaint. Please try again.");
//       }
//     } catch (e) {
//       Get.snackbar("Error", "An unexpected error occurred: $e");
//     } finally {
//       isDeleting.value = false;
//       _complaintToDelete.value = null;
//       // ❌ Removed redundant fetchComplaints() here — you already removed item locally
//     }
//   }

//   void _notifyStatusChange(ComplaintViewModel complaint) {
//     String? title, body;

//     if (complaint.isOpen) {
//       title = "Complaint Accepted";
//       body = "Your complaint has been accepted and assigned to a technician.";
//     } else if (complaint.isResolved) {
//       title = "Complaint Resolved";
//       body = "Great news! Your complaint has been successfully resolved.";
//     }

//     if (title != null && body != null) {
//       NotificationHelper.showNotification(title: title, body: body);
//     }
//   }

//   Widget _buildRatingDisplay(int starRating) {
//     // Even though checked before, defensive check
//     if (starRating <= 0 || starRating > 5) {
//       // print("Invalid star rating: $starRating"); // Debug log
//       return const SizedBox.shrink(); // Or handle gracefully
//     }

//     final int clampedRating = starRating.clamp(1, 5);

//     return Container(
//       width: double.infinity,
//       // Ensure padding is correct
//       padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
//       decoration: BoxDecoration(
//         color:
//             AppColors.backgroundLight ??
//             Theme.of(Get.context!).colorScheme.surfaceVariant, // Fallback color
//         borderRadius: const BorderRadius.only(
//           bottomLeft: Radius.circular(24),
//           bottomRight: Radius.circular(24),
//         ),
//         // Ensure border color is visible or remove if not needed
//         border: Border(
//           top: BorderSide(
//             color: (AppColors.dividerColor ?? Colors.grey).withOpacity(0.5),
//             width: 0.5,
//           ),
//         ),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           const Icon(
//             Icons.star,
//             // Ensure color is set and visible
//             color: AppColors.warning ?? Colors.amber, // Fallback amber
//             size: 18,
//           ),
//           const SizedBox(width: 6),
//           Text(
//             '$clampedRating/5',
//             style: AppText.bodyMedium.copyWith(
//               fontWeight: FontWeight.bold,
//               color: AppColors.textColorPrimary,
//             ),
//           ),
//           const SizedBox(width: 8),
//           Text(
//             "Rated", // Consider "Technician Rated"
//             style: AppText.bodySmall.copyWith(
//               color: AppColors.textColorSecondary,
//             ),
//           ),
//           // Optional Star Bar (uncomment if preferred)
//           // const SizedBox(width: 8),
//           // Row(
//           //   mainAxisSize: MainAxisSize.min,
//           //   children: List.generate(5, (index) {
//           //     return Icon(
//           //       index < clampedRating ? Icons.star : Icons.star_border,
//           //       color: AppColors.warning ?? Colors.amber,
//           //       size: 16,
//           //     );
//           //   }),
//           // ),
//         ],
//       ),
//     );
//   }
// }

// // --- Helper Widget for Star Rating ---
// class _StarRating extends StatelessWidget {
//   final int rating;
//   final ValueChanged<int>? onRatingUpdate; // Nullable for display-only mode
//   final double size;
//   final bool isEnabled; // New flag to enable/disable interaction

//   const _StarRating({
//     Key? key,
//     required this.rating,
//     this.onRatingUpdate,
//     this.size = 32.0,
//     this.isEnabled = true, // Default to enabled
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       mainAxisSize: MainAxisSize.min,
//       children: List.generate(5, (index) {
//         return IconButton(
//           icon: Icon(
//             index < rating ? Icons.star : Icons.star_border,
//             color: index < rating ? AppColors.warning : Colors.grey,
//             size: size,
//           ),
//           onPressed:
//               isEnabled && onRatingUpdate != null
//                   ? () => onRatingUpdate!(index + 1)
//                   : null, // Disable if not enabled or no callback
//           splashRadius: 20, // Smaller splash for better spacing
//         );
//       }),
//     );
//   }
// }

// // --- The Rating Dialog Function ---
// Future<void> showRatingDialog(ComplaintViewModel complaint) async {
//   // Ensure the complaint is closed/resolved before showing
//   if (!complaint.isResolved) {
//     Get.snackbar(
//       "Not Allowed",
//       "You can only rate closed complaints.",
//       backgroundColor: AppColors.warning,
//       colorText: Colors.white,
//     );
//     return;
//   }

//   // Controllers for rating input
//   final rating = (complaint.rating ?? 0).obs; // Initialize with existing or 0
//   final commentCtrl = TextEditingController(text: complaint.closedRemark);
//   final isSubmitting = false.obs;

//   // Function to submit the rating
//   Future<void> _submitRating() async {
//     if (rating.value <= 0) {
//       Get.snackbar(
//         "Rating Required",
//         "Please select a star rating.",
//         backgroundColor: AppColors.warning.withOpacity(0.9),
//         colorText: Colors.white,
//       );
//       return;
//     }

//     isSubmitting.value = true;
//     try {
//       final apiService =
//           Get.find<ApiServices>(); // Ensure ApiServices is registered
//       final success = await apiService.rateComplaint(
//         ticketNo: complaint.ticketNo,
//         star: rating.value,
//         // Use current time or complaint closed time if available
//         insertedOn: DateTime.now().toIso8601String(),
//         rateDescription: commentCtrl.text.trim(),
//       );

//       if (success) {
//         Get.back(); // Close the bottom sheet
//         ComplaintController().fetchComplaints();
//         Get.snackbar(
//           "Success",
//           "Thank you for your feedback!",
//           backgroundColor: AppColors.success,
//           colorText: Colors.white,
//         );
//         // Optional: Update the local complaint model or refresh list
//         // Get.find<ComplaintController>()?.fetchComplaints(); // Example
//       } else {
//         // Error message likely shown by rateComplaint itself
//       }
//     } catch (e) {
//       print("Error submitting rating: $e");
//       Get.snackbar(
//         "Error",
//         "An unexpected error occurred.",
//         backgroundColor: AppColors.error,
//         colorText: Colors.white,
//       );
//     } finally {
//       isSubmitting.value = false;
//     }
//   }

//   Get.bottomSheet(
//     Container(
//       constraints: BoxConstraints(
//         maxHeight: Get.mediaQuery.size.height * 0.9, // Prevent overflow
//       ),
//       decoration: const BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
//       ),
//       padding: EdgeInsets.only(
//         bottom:
//             MediaQuery.of(
//               Get.context!,
//             ).viewInsets.bottom, // Adjust for keyboard
//       ),
//       child: SingleChildScrollView(
//         child: Column(
//           mainAxisSize: MainAxisSize.min, // Shrink to fit content
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // --- 1. Drag Handle ---
//             Center(
//               child: Container(
//                 margin: const EdgeInsets.symmetric(vertical: 12),
//                 width: 48,
//                 height: 5,
//                 decoration: BoxDecoration(
//                   color: Colors.grey[300],
//                   borderRadius: BorderRadius.circular(3),
//                 ),
//               ),
//             ),

//             // --- 2. Header ---
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 24),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     "Rate Your Experience",
//                     style: AppText.headingSmall.copyWith(
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   IconButton(
//                     icon: const Icon(
//                       Icons.close,
//                       color: AppColors.textColorHint,
//                     ),
//                     onPressed: () => Get.back(),
//                     splashRadius: 24,
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 8),

//             // --- 3. Complaint Info Card ---
//             Container(
//               width: double.infinity,
//               margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
//               padding: const EdgeInsets.all(16),
//               decoration: BoxDecoration(
//                 color: AppColors.backgroundLight,
//                 borderRadius: BorderRadius.circular(20),
//                 border: Border.all(
//                   color: AppColors.dividerColor.withOpacity(0.5),
//                 ),
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     complaint.ticketNo,
//                     style: AppText.bodyMedium.copyWith(
//                       fontWeight: FontWeight.bold,
//                       color: AppColors.primary,
//                     ),
//                   ),
//                   const SizedBox(height: 4),
//                   Text(
//                     "${complaint.category} - ${complaint.subCategory ?? 'N/A'}",
//                     style: AppText.bodySmall,
//                   ),
//                   const SizedBox(height: 4),
//                   Text(complaint.createdAt, style: AppText.bodySmall),
//                   if (complaint.technician != null) ...[
//                     const SizedBox(height: 8),
//                     Row(
//                       children: [
//                         const Icon(
//                           Icons.engineering,
//                           size: 16,
//                           color: AppColors.secondary,
//                         ),
//                         const SizedBox(width: 6),
//                         Expanded(
//                           child: Text(
//                             "Technician: ${complaint.technician}",
//                             style: AppText.bodySmall.copyWith(
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ],
//               ),
//             ),

//             const SizedBox(height: 16),

//             // --- 4. Rating Section ---
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 24),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     "How was your service?",
//                     style: AppText.labelMedium?.copyWith(
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                   const SizedBox(height: 12),
//                   Center(
//                     child: Obx(
//                       () => _StarRating(
//                         rating: rating.value,
//                         onRatingUpdate: (newRating) => rating.value = newRating,
//                         size: 40.0, // Larger stars
//                         isEnabled:
//                             !(complaint.rating != null &&
//                                 complaint.rating! >
//                                     0), // Disable while submitting
//                       ),
//                     ),
//                   ),
//                   const SizedBox(height: 20),

//                   // --- 5. Comment Box ---
//                   Text(
//                     "Comments (Optional)",
//                     style: AppText.labelMedium.copyWith(
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                   const SizedBox(height: 8),
//                   TextField(
//                     controller: commentCtrl,
//                     maxLines: 3,
//                     enabled: !isSubmitting.value, // Disable while submitting
//                     decoration: InputDecoration(
//                       hintText: "Share details of your experience...",
//                       hintStyle: TextStyle(color: AppColors.textColorHint),
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(16),
//                         borderSide: BorderSide(color: AppColors.dividerColor),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(16),
//                         borderSide: BorderSide(
//                           color: AppColors.primary,
//                           width: 2,
//                         ),
//                       ),
//                       filled: true,
//                       fillColor: AppColors.inputBackground,
//                       contentPadding: const EdgeInsets.symmetric(
//                         horizontal: 16,
//                         vertical: 16,
//                       ),
//                     ),
//                     style: AppText.bodyMedium?.copyWith(
//                       color: AppColors.textColorPrimary,
//                     ),
//                   ),
//                 ],
//               ),
//             ),

//             const SizedBox(height: 24),

//             // --- 6. Submit Button ---
//             if (!(complaint.rating != null && complaint.rating! > 0))
//               Padding(
//                 padding: const EdgeInsets.symmetric(
//                   horizontal: 24,
//                   vertical: 12,
//                 ),
//                 child: Obx(
//                   () => SizedBox(
//                     width: double.infinity,
//                     height: 52, // Consistent button height
//                     child: ElevatedButton(
//                       onPressed: isSubmitting.value ? null : _submitRating,
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: AppColors.primary,
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(16),
//                         ),
//                         elevation: 2,
//                       ),
//                       child:
//                           isSubmitting.value
//                               ? const CircularProgressIndicator(
//                                 color: Colors.white,
//                               )
//                               : Text(
//                                 complaint.rating != null &&
//                                         complaint.rating! > 0
//                                     ? "Update Rating"
//                                     : "Submit Rating",
//                                 style: AppText.button.copyWith(
//                                   color: Colors.white,
//                                 ),
//                               ),
//                     ),
//                   ),
//                 ),
//               ),
//             const SizedBox(height: 12), // Bottom spacing
//           ],
//         ),
//       ),
//     ),
//     isScrollControlled: true, // Important for keyboard handling
//     backgroundColor: Colors.transparent, // Make background transparent
//   );
// }

// // --- How to Use ---
// // In your _buildComplaintCard or onTap handler:
// /*
// InkWell(
//   onTap: () {
//     if (complaint.isResolved) {
//       showRatingDialog(complaint); // Show this dialog
//     } else {
//       _showComplaintDetails(complaint); // Show details for open ones
//     }
//   },
//   // ... rest of your card
// )
// */


// // ignore_for_file: avoid_print

// import 'package:asia_fibernet/src/services/sharedpref.dart';

// import '../../../technician/ui/screens/tech_dashboard_screen.dart';
// import 'package:get/get.dart';
// import 'package:flutter/material.dart';
// // Import your ApiServices
// import '../model/verify_mobile_model.dart';
// import '../../../services/apis/api_services.dart';
// // Import OTP Screen
// import '../../ui/otp_screen.dart';
// import 'binding/otp_binding.dart';

// class LoginController extends GetxController
//     with GetSingleTickerProviderStateMixin {
//   // Needed for AnimationController

//   // --- Create an instance of ApiServices ---
//   // ✅ It's better practice to get the singleton instance registered with GetX
//   // Make sure you register ApiServices as a GetX service (e.g., Get.put(ApiServices()) or Get.lazyPut(() => ApiServices()) in main.dart or an initializer)
//   // final ApiServices _apiService = ApiServices(); // Old way - creates new instance
//   final ApiServices _apiService =
//       Get.find<ApiServices>(); // ✅ Get the registered instance

//   final phoneController = TextEditingController(text: "5523235656");
//   late AnimationController _animationController;
//   late Animation<double> logoAnimation;
//   late Animation<double> textAnimation;
//   late Animation<double> cardAnimation;

//   // ✅ Add a loading state observable
//   final RxBool isLoading = false.obs;

//   @override
//   void onInit() {
//     super.onInit();
//     _animationController = AnimationController(
//       duration: Duration(milliseconds: 1000),
//       vsync: this, // Requires GetSingleTickerProviderStateMixin
//     );
//     // Define curves for different timings if needed
//     logoAnimation = CurvedAnimation(
//       parent: _animationController,
//       curve: Curves.easeOut,
//     );
//     textAnimation = CurvedAnimation(
//       parent: _animationController,
//       curve: Curves.easeInOut,
//     );
//     cardAnimation = CurvedAnimation(
//       parent: _animationController,
//       curve: Curves.easeInOut,
//     );
//     // Start the animation
//     _animationController.forward();
//   }

//   // Inside LoginController class

//   void login() async {
//     if (isLoading.value) {
//       print("Login already in progress...");
//       return;
//     }

//     String phoneNumber = phoneController.text.trim();

//     if (phoneNumber.isEmpty) {
//       Get.snackbar("Error", "Please enter a mobile number.");
//       return;
//     }

//     isLoading.value = true;

//     try {
//       print("Attempting to verify mobile: $phoneNumber");

//       final verifyResponse = await _apiService.mobileVerification(phoneNumber);

//       if (verifyResponse == null) {
//         Get.snackbar(
//           "Network Error",
//           "Could not connect. Please check your internet connection.",
//           backgroundColor: Colors.red.shade100,
//           colorText: Colors.red,
//         );
//         return;
//       }

//       if (verifyResponse.status == "success") {
//         final role = verifyResponse.data?.userRole ?? UserRole.unknown;
//         final userId = verifyResponse.data?.id ?? -1;
//         final token = verifyResponse.token ?? '';

//         print("✅ Verification successful");
//         print("User Role: $role");
//         print("User ID: $userId");
//         print(
//           "Token: '$token'",
//         ); // Print with quotes to see empty string clearly

//         // --- Key Change: Check for Guest/Unregistered ---
//         // Define conditions for being a "Guest" or unregistered user.
//         // This might be an empty token, a specific role, or a specific message.
//         // Adjust these conditions based on your API's actual response for new users.
//         bool isGuest =
//             token.isEmpty ||
//             token == '' ||
//             role == UserRole.unknown; // Example conditions

//         if (isGuest) {
//           print(
//             "📱 User identified as Guest/Unregistered. Navigating to UnregisteredUserScreen.",
//           );
//           // Save necessary info for the unregistered user
//           // Even if token is empty, saving phoneNumber and a placeholder might be useful
//           // You might get a temporary ID or session token from the API for guests, use that if available.
//           AppSharedPref.instance.setUserID(
//             userId,
//           ); // Save the ID if provided, even for guests
//           AppSharedPref.instance.setMobileNumber(phoneNumber);
//           AppSharedPref.instance.setToken(
//             "Guest",
//           ); // Save the (possibly empty) token
//           AppSharedPref.instance.setRole("Guest"); // Set role explicitly
//           AppSharedPref.instance.setVerificationStatus(
//             false,
//           ); // Indicate not fully verified
//           Get.to(
//             () => OTPScreen(),
//             binding: OTPBinding(
//               phoneNumber: phoneNumber,
//               token: token,
//               userID: userId,
//               underReview: verifyResponse.serviceStatus == "under_review",
//             ),
//           );
//           // Navigate directly to UnregisteredUserScreen for guests
//           // Get.offAll(
//           //   () => UnregisteredUserScreen(),
//           //   // binding: ScaffoldScreenBinding(),
//           // ); // Assuming binding is correct
//           // Show a welcome message or instructions specific to new users if desired
//           Get.snackbar(
//             "Welcome!",
//             "Please complete your registration.",
//             snackPosition: SnackPosition.BOTTOM,
//           );
//           return; // Stop further processing
//         }

//         // --- End Key Change ---

//         // If not a guest, proceed with standard role-based navigation
//         switch (role) {
//           case UserRole.customer:
//             // Standard customer flow - go to OTP
//             AppSharedPref.instance.setVerificationStatus(
//               true,
//             ); // Or keep false if OTP confirms verification
//             // Consider if OTP is always needed for existing customers or just guests
//             // For now, keeping original flow for existing customers
//             Get.to(
//               () => OTPScreen(),
//               binding: OTPBinding(
//                 phoneNumber: phoneNumber,
//                 token: token,
//                 userID: userId,
//               ),
//             );
//             break;

//           case UserRole.technician:
//             AppSharedPref.instance.setToken(token);
//             AppSharedPref.instance.setUserID(userId);
//             AppSharedPref.instance.setMobileNumber(phoneNumber);
//             AppSharedPref.instance.setRole("technician");
//             Get.to(() => TechnicianDashboardScreen());
//             break;

//           case UserRole.admin:
//             Get.snackbar(
//               "Admin Access",
//               "Redirecting to admin panel...",
//               snackPosition: SnackPosition.BOTTOM,
//             );
//             // Get.to(() => AdminDashboardScreen());
//             break;

//           case UserRole.unknown:
//           // This case is now handled by the 'isGuest' check above.
//           // If you reach here, it means token wasn't empty but role was unknown.
//           // You might want to handle this differently, maybe as an error.
//           default:
//             // Handle any other unexpected roles if necessary
//             Get.snackbar(
//               "Access Denied",
//               "Your account type is not recognized. Please contact support.",
//               backgroundColor: Colors.orange.shade100,
//               colorText: Colors.orange,
//             );
//             break;
//         }
//       } else {
//         // API returned status != "success"
//         Get.snackbar(
//           "Login Failed",
//           verifyResponse.message,
//           backgroundColor: Colors.red.shade100,
//           colorText: Colors.red,
//         );
//       }
//     } catch (e) {
//       print("Exception during login: $e");
//       Get.snackbar(
//         "Error",
//         "An unexpected error occurred. Please try again.",
//         backgroundColor: Colors.red.shade100,
//         colorText: Colors.red,
//       );
//     } finally {
//       isLoading.value = false;
//     }
//   }

//   @override
//   void onClose() {
//     _animationController.dispose();
//     phoneController.dispose();
//     super.onClose();
//   }
// }


// // Example OTPController structure (based on your snippet)
// import 'dart:async';

// import 'package:asia_fibernet/src/auth/core/model/verify_mobile_model.dart';
// import 'package:asia_fibernet/src/customer/unregistered_user/unregistered_kyc_status_screen.dart';

// import '../../../customer/ui/screen/unregistered_user_screen.dart';
// import '../../../services/sharedpref.dart';
// import '../../ui/scaffold_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';

// import 'binding/scaffold_screen_binding.dart';

// // Adjust import for HomeScreen

// class OTPController extends GetxController {
//   // Receive phone number via constructor
//   final String phone;
//   final String token;
//   final int userID;
//   bool? underReview;
//   OTPController({
//     required this.phone,
//     required this.token,
//     required this.userID,
//     this.underReview,
//   });

//   // Rx variables
//   final List<TextEditingController> otpControllers = List.generate(
//     6,
//     (index) => TextEditingController(),
//   );
//   final List<FocusNode> focusNodes = List.generate(6, (index) => FocusNode());
//   RxInt currentIndex = 0.obs;
//   RxInt secondsRemaining = 60.obs;
//   RxBool resendEnabled = false.obs;
//   late Timer timer;

//   @override
//   void onInit() {
//     super.onInit();
//     startTimer();
//   }

//   void startTimer() {
//     secondsRemaining.value = 60;
//     resendEnabled.value = false;
//     timer = Timer.periodic(Duration(seconds: 1), (timer) {
//       secondsRemaining.value--;
//       if (secondsRemaining.value <= 0) {
//         resendEnabled.value = true;
//         timer.cancel();
//       }
//     });
//   }

//   void onOtpChanged(String value, int index) {
//     // Logic for focus and checking completion
//     // ... your existing logic ...
//     if (value.length == 1 && index < 5) {
//       focusNodes[index].unfocus();
//       // Using Get.context - generally okay, but context from widget is preferred if available
//       FocusScope.of(Get.context!).requestFocus(focusNodes[index + 1]);
//       currentIndex.value = index + 1;
//     } else if (value.isEmpty && index > 0) {
//       focusNodes[index].unfocus();
//       FocusScope.of(Get.context!).requestFocus(focusNodes[index - 1]);
//       currentIndex.value = index - 1;
//     }

//     bool allFilled = true;
//     for (int i = 0; i < 6; i++) {
//       if (otpControllers[i].text.isEmpty) {
//         allFilled = false;
//         break;
//       }
//     }
//     if (allFilled) {
//       Future.delayed(Duration(milliseconds: 300), () {
//         verifyAndLogin(); // Call internal method
//       });
//     }
//   }

//   void resendOTP() {
//     if (resendEnabled.value) {
//       secondsRemaining.value = 60;
//       resendEnabled.value = false;
//       startTimer();
//       // Add API call to resend OTP if needed
//       Get.snackbar("OTP", "OTP resent to $phone"); // Example feedback
//     }
//   }
//   // Inside OTPController class

//   void verifyAndLogin() async {
//     String enteredOTP = otpControllers.map((c) => c.text).join();

//     // Dummy verification - Replace with real API call to verify OTP
//     bool isOtpValid = (enteredOTP == "123456"); // Example dummy check

//     if (isOtpValid) {
//       // Replace with your actual OTP verification logic
//       print("✅ OTP verified successfully for user ID: $userID");

//       // --- Key Change: Determine final destination based on token ---
//       // After OTP, check the token status again.
//       // The token might have been updated by the OTP verification API call (if applicable).
//       // For this example, we'll assume the token from the constructor determines the path,
//       // but you might fetch an updated token here.

//       // Define what constitutes a "Guest" token after OTP.
//       // This should match the logic in LoginController or be based on the OTP verification result.
//       bool isGuestAfterOtp =
//           token.isEmpty || token == "Guest"; // Example condition

//       if (isGuestAfterOtp) {
//         print(
//           "📱 OTP verified for Guest user. Navigating to UnregisteredUserScreen.",
//         );
//         // Save user data for Guest (might already be done in LoginController, but ensure consistency)
//         AppSharedPref.instance.setUserID(userID);
//         AppSharedPref.instance.setMobileNumber(phone);
//         AppSharedPref.instance.setToken(
//           "Guest",
//         ); // Save the (possibly still empty) token
//         AppSharedPref.instance.setRole("Guest");
//         AppSharedPref.instance.setVerificationStatus(
//           false,
//         ); // Still not fully verified post-KYC

//         // Navigate to UnregisteredUserScreen for guests who just entered OTP
//         Get.offAll(
//           () =>
//               underReview ?? false
//                   ? KycStatusScreen()
//                   : UnregisteredUserScreen(),
//           binding: ScaffoldScreenBinding(),
//         );
//         Get.snackbar("Success", "OTP Verified! Please complete your profile.");
//         return; // Stop further processing
//       }

//       // --- End Key Change ---

//       // If not a guest after OTP verification, proceed to the main app
//       print("📱 OTP verified for registered user. Navigating to main app.");
//       AppSharedPref.instance.setToken(token); // Save the verified token
//       AppSharedPref.instance.setUserID(userID);
//       AppSharedPref.instance.setMobileNumber(phone);
//       // Set role based on context - if it was 'customer' before OTP, it remains so.
//       // AppSharedPref.instance.setRole("customer"); // Or fetch from API if needed
//       AppSharedPref.instance.setVerificationStatus(true); // Now fully verified

//       Get.offAll(() => ScaffoldScreen(), binding: ScaffoldScreenBinding());
//       Get.snackbar("Success", "Login Successful!");
//     } else {
//       Get.snackbar(
//         "Error",
//         "Invalid OTP",
//         backgroundColor: Colors.red.shade100,
//       );
//       // Clear fields
//       for (var c in otpControllers) {
//         c.clear();
//       }
//       if (focusNodes.isNotEmpty) {
//         FocusScope.of(Get.context!).requestFocus(focusNodes[0]);
//       }
//     }
//   }

//   @override
//   void onClose() {
//     timer.cancel();
//     for (var c in otpControllers) {
//       c.dispose();
//     }
//     for (var n in focusNodes) {
//       n.dispose();
//     }
//     super.onClose();
//   }
// }



// import 'package:asia_fibernet/src/auth/core/controller%20/binding/otp_binding.dart';
// import 'package:asia_fibernet/src/auth/ui/otp_screen.dart';
// import 'package:asia_fibernet/src/services/sharedpref.dart';
// import 'package:get/get.dart';
// import 'package:flutter/material.dart';

// import '../../../customer/ui/screen/unregistered_user_screen.dart';
// import '../../../services/apis/api_services.dart';
// import '../../../services/utils/plugin/device_info_utils.dart'; // For AnimationController

// // Import your ApiServices
// class SignUpController extends GetxController
//     with GetSingleTickerProviderStateMixin {
//   // --- Dependencies ---
//   final ApiServices _apiService =
//       Get.find<ApiServices>(); // Get the ApiServices instance

//   // --- Text Editing Controllers ---
//   final fullNameController = TextEditingController();
//   final mobileNumberController = TextEditingController();
//   final emailController = TextEditingController();
//   final addressController = TextEditingController();
//   final cityController = TextEditingController();
//   final stateController = TextEditingController();
//   final pincodeController = TextEditingController();
//   // Add controller for Referral Code if you have a field for it
//   final referralCodeController = TextEditingController();

//   // --- Animation Controllers (from your existing code) ---
//   late AnimationController animationController;
//   late Animation<double> textAnimation;
//   late Animation<double> cardAnimation;

//   // --- Observable for Selected Plan ---
//   final selectedPlan = ''.obs; // Or RxString? selectedPlan = RxString('');

//   // --- Loading State for Registration ---
//   final RxBool isRegistering = false.obs;

//   @override
//   void onInit() {
//     super.onInit();
//     // Initialize animations (from your existing code)
//     animationController = AnimationController(
//       duration: const Duration(milliseconds: 600),
//       vsync: this,
//     );
//     textAnimation = Tween<double>(begin: 0, end: 1).animate(
//       CurvedAnimation(parent: animationController, curve: Curves.easeOut),
//     );
//     cardAnimation = Tween<double>(begin: 0.8, end: 1).animate(
//       CurvedAnimation(parent: animationController, curve: Curves.easeOut),
//     );
//     animationController.forward();
//   }

//   // --- Method to Handle Registration ---
//   Future<void> registerCustomer() async {
//     // Basic validation can also be done here or rely on Form validation
//     // For now, let's assume form validation happened before calling this.

//     // Set loading state
//     isRegistering(true);

//     try {
//       // --- Gather Data from Controllers ---
//       // You'll likely get Wi-Fi and GPS info dynamically.
//       // For now, using placeholders or defaults.
//       // In a real scenario, you'd use DeviceInfoUtils.getAllDeviceInfo() or similar.
//       // Example:
//       final Map<String, dynamic> deviceInfo =
//           await DeviceInfoUtils.getAllDeviceInfo();
//       final String wifiName = deviceInfo['wifi_name'] ?? 'Unknown';
//       final String wifiBssid = deviceInfo['wifi_bssid'] ?? '00:00:00:00:00:00';
//       final String wifiGateway = deviceInfo['wifi_gateway'] ?? '0.0.0.0';
//       final String gpsLatitude = deviceInfo['latitude']?.toString() ?? '0.0';
//       final String gpsLongitude = deviceInfo['longitude']?.toString() ?? '0.0';

//       // --- Prepare API Call Parameters ---
//       // IMPORTANT: Replace placeholder values with dynamic data where possible.
//       // Connection type could come from selectedPlan or be fixed for signup.
//       final String connectionType = "WiFi"; // Or derive from selectedPlan
//       // --- Call the API Service ---
//       final bool isSuccess = await _apiService.registerCustomer(
//         fullName: fullNameController.text.trim(),
//         mobileNumber: mobileNumberController.text.trim(),
//         connectionType: connectionType,
//         email: emailController.text.trim(),
//         city: cityController.text.trim(),
//         state: stateController.text.trim(),
//         // Pincode might be part of address or separate, adjust as needed.
//         // If needed in API, you'd add it to registerCustomer method and pass it here.
//         referralCode: referralCodeController.text.trim(), // Pass referral code
//         wifiName: wifiName,
//         wifiBssid: wifiBssid,
//         wifiGateway: wifiGateway,
//         gpsLatitude: gpsLatitude,
//         gpsLongitude: gpsLongitude,
//       );

//       // --- Handle API Response ---
//       if (isSuccess) {
//         // Registration successful
//         // AppSharedPref.instance.setToken("Guest");
//         // AppSharedPref.instance.setUserID(-1);
//         // AppSharedPref.instance.setMobileNumber(
//         //   mobileNumberController.text.trim(),
//         // );

//         Get.snackbar(
//           "Success",
//           "Your application has been submitted successfully!",
//           backgroundColor: Colors.green.withOpacity(0.9),
//           colorText: Colors.white,
//         );
//         // Optionally, clear the form or navigate to a confirmation screen
//         clearForm();
//         Get.offAll(
//           () => OTPScreen(),
//           binding: BindingsBuilder(
//             () => OTPBinding(
//               phoneNumber: mobileNumberController.text.trim(),
//               token: "Guest",
//               userID: -1,
//             ),
//           ),
//         ); // Example navigation
//         Get.offAll(
//           () => UnregisteredUserScreen(),
//           // binding: BindingsBuilder(
//           //   () => Get.lazyPut<HomeController>(() => HomeController()),
//           // ),
//           // binding: ScaffoldScreenBinding(),
//         );
//       } else {
//         // Registration failed (API returned error or network issue handled in ApiServices)
//         // The ApiServices should show a snackbar with the specific error.
//         // You could add additional logic here if needed.
//       }
//     } catch (e) {
//       // Handle unexpected errors in the controller logic (less likely if ApiServices handles well)
//       Get.snackbar(
//         "Error",
//         "An unexpected error occurred during registration: $e",
//         backgroundColor: Colors.red.withOpacity(0.9),
//         colorText: Colors.white,
//       );
//     } finally {
//       // Reset loading state
//       isRegistering(false);
//     }
//   }

//   // --- Optional: Method to Clear Form ---
//   void clearForm() {
//     fullNameController.clear();
//     mobileNumberController.clear();
//     emailController.clear();
//     addressController.clear();
//     cityController.clear();
//     stateController.clear();
//     pincodeController.clear();
//     referralCodeController.clear();
//     selectedPlan.value = ''; // Or RxString? selectedPlan.value = null;
//   }

//   @override
//   void onClose() {
//     // Dispose controllers
//     fullNameController.dispose();
//     mobileNumberController.dispose();
//     emailController.dispose();
//     addressController.dispose();
//     cityController.dispose();
//     stateController.dispose();
//     pincodeController.dispose();
//     referralCodeController.dispose();
//     animationController.dispose();
//     super.onClose();
//   }
// }


// import 'package:asia_fibernet/src/auth/core/controller%20/binding/otp_binding.dart';
// import 'package:asia_fibernet/src/auth/ui/otp_screen.dart';
// import 'package:asia_fibernet/src/services/sharedpref.dart';
// import 'package:get/get.dart';
// import 'package:flutter/material.dart';

// import '../../../customer/ui/screen/unregistered_user_screen.dart';
// import '../../../services/apis/api_services.dart';
// import '../../../services/utils/plugin/device_info_utils.dart'; // For AnimationController

// // Import your ApiServices
// class SignUpController extends GetxController
//     with GetSingleTickerProviderStateMixin {
//   // --- Dependencies ---
//   final ApiServices _apiService =
//       Get.find<ApiServices>(); // Get the ApiServices instance

//   // --- Text Editing Controllers ---
//   final fullNameController = TextEditingController();
//   final mobileNumberController = TextEditingController();
//   final emailController = TextEditingController();
//   final addressController = TextEditingController();
//   final cityController = TextEditingController();
//   final stateController = TextEditingController();
//   final pincodeController = TextEditingController();
//   // Add controller for Referral Code if you have a field for it
//   final referralCodeController = TextEditingController();

//   // --- Animation Controllers (from your existing code) ---
//   late AnimationController animationController;
//   late Animation<double> textAnimation;
//   late Animation<double> cardAnimation;

//   // --- Observable for Selected Plan ---
//   final selectedPlan = ''.obs; // Or RxString? selectedPlan = RxString('');

//   // --- Loading State for Registration ---
//   final RxBool isRegistering = false.obs;

//   @override
//   void onInit() {
//     super.onInit();
//     // Initialize animations (from your existing code)
//     animationController = AnimationController(
//       duration: const Duration(milliseconds: 600),
//       vsync: this,
//     );
//     textAnimation = Tween<double>(begin: 0, end: 1).animate(
//       CurvedAnimation(parent: animationController, curve: Curves.easeOut),
//     );
//     cardAnimation = Tween<double>(begin: 0.8, end: 1).animate(
//       CurvedAnimation(parent: animationController, curve: Curves.easeOut),
//     );
//     animationController.forward();
//   }

//   // --- Method to Handle Registration ---
//   Future<void> registerCustomer() async {
//     // Basic validation can also be done here or rely on Form validation
//     // For now, let's assume form validation happened before calling this.

//     // Set loading state
//     isRegistering(true);

//     try {
//       // --- Gather Data from Controllers ---
//       // You'll likely get Wi-Fi and GPS info dynamically.
//       // For now, using placeholders or defaults.
//       // In a real scenario, you'd use DeviceInfoUtils.getAllDeviceInfo() or similar.
//       // Example:
//       final Map<String, dynamic> deviceInfo =
//           await DeviceInfoUtils.getAllDeviceInfo();
//       final String wifiName = deviceInfo['wifi_name'] ?? 'Unknown';
//       final String wifiBssid = deviceInfo['wifi_bssid'] ?? '00:00:00:00:00:00';
//       final String wifiGateway = deviceInfo['wifi_gateway'] ?? '0.0.0.0';
//       final String gpsLatitude = deviceInfo['latitude']?.toString() ?? '0.0';
//       final String gpsLongitude = deviceInfo['longitude']?.toString() ?? '0.0';

//       // --- Prepare API Call Parameters ---
//       // IMPORTANT: Replace placeholder values with dynamic data where possible.
//       // Connection type could come from selectedPlan or be fixed for signup.
//       final String connectionType = "WiFi"; // Or derive from selectedPlan
//       // --- Call the API Service ---
//       final bool isSuccess = await _apiService.registerCustomer(
//         fullName: fullNameController.text.trim(),
//         mobileNumber: mobileNumberController.text.trim(),
//         connectionType: connectionType,
//         email: emailController.text.trim(),
//         city: cityController.text.trim(),
//         state: stateController.text.trim(),
//         // Pincode might be part of address or separate, adjust as needed.
//         // If needed in API, you'd add it to registerCustomer method and pass it here.
//         referralCode: referralCodeController.text.trim(), // Pass referral code
//         wifiName: wifiName,
//         wifiBssid: wifiBssid,
//         wifiGateway: wifiGateway,
//         gpsLatitude: gpsLatitude,
//         gpsLongitude: gpsLongitude,
//       );

//       // --- Handle API Response ---
//       if (isSuccess) {
//         // Registration successful
//         // AppSharedPref.instance.setToken("Guest");
//         // AppSharedPref.instance.setUserID(-1);
//         // AppSharedPref.instance.setMobileNumber(
//         //   mobileNumberController.text.trim(),
//         // );

//         Get.snackbar(
//           "Success",
//           "Your application has been submitted successfully!",
//           backgroundColor: Colors.green.withOpacity(0.9),
//           colorText: Colors.white,
//         );
//         // Optionally, clear the form or navigate to a confirmation screen
//         clearForm();
//         Get.offAll(
//           () => OTPScreen(),
//           binding: BindingsBuilder(
//             () => OTPBinding(
//               phoneNumber: mobileNumberController.text.trim(),
//               token: "Guest",
//               userID: -1,
//             ),
//           ),
//         ); // Example navigation
//         Get.offAll(
//           () => UnregisteredUserScreen(),
//           // binding: BindingsBuilder(
//           //   () => Get.lazyPut<HomeController>(() => HomeController()),
//           // ),
//           // binding: ScaffoldScreenBinding(),
//         );
//       } else {
//         // Registration failed (API returned error or network issue handled in ApiServices)
//         // The ApiServices should show a snackbar with the specific error.
//         // You could add additional logic here if needed.
//       }
//     } catch (e) {
//       // Handle unexpected errors in the controller logic (less likely if ApiServices handles well)
//       Get.snackbar(
//         "Error",
//         "An unexpected error occurred during registration: $e",
//         backgroundColor: Colors.red.withOpacity(0.9),
//         colorText: Colors.white,
//       );
//     } finally {
//       // Reset loading state
//       isRegistering(false);
//     }
//   }

//   // --- Optional: Method to Clear Form ---
//   void clearForm() {
//     fullNameController.clear();
//     mobileNumberController.clear();
//     emailController.clear();
//     addressController.clear();
//     cityController.clear();
//     stateController.clear();
//     pincodeController.clear();
//     referralCodeController.clear();
//     selectedPlan.value = ''; // Or RxString? selectedPlan.value = null;
//   }

//   @override
//   void onClose() {
//     // Dispose controllers
//     fullNameController.dispose();
//     mobileNumberController.dispose();
//     emailController.dispose();
//     addressController.dispose();
//     cityController.dispose();
//     stateController.dispose();
//     pincodeController.dispose();
//     referralCodeController.dispose();
//     animationController.dispose();
//     super.onClose();
//   }
// }


// enum UserRole {
//   customer,
//   technician,
//   admin,
//   unknown;

//   // Helper to convert string to enum safely
//   static UserRole fromString(String? role) {
//     if (role == null) return unknown;
//     return switch (role.toLowerCase()) {
//       'customer' => customer,
//       'technician' => technician,
//       'admin' => admin,
//       _ => unknown,
//     };
//   }
// }

// class VerifyMobileResponse {
//   final String status; // Can be "success" or "error"
//   final String message;
//   final String token; // Now always String (even if empty)
//   final Data? data; // Optional: null if data is {} or absent
//   final String? action; // Present in some cases
//   final String? serviceStatus; // NEW: optional service_status field

//   VerifyMobileResponse({
//     required this.status,
//     required this.message,
//     required this.token, // No longer optional — empty string if not present
//     this.data,
//     this.action,
//     this.serviceStatus,
//   });

//   factory VerifyMobileResponse.fromJson(Map<String, dynamic> json) {
//     final rawData = json['data'];
//     Data? parsedData;

//     // Only parse data if it's a non-empty map with expected keys
//     if (rawData is Map<String, dynamic> && rawData.isNotEmpty) {
//       parsedData = Data.fromJson(rawData);
//     }
//     // else leave as null — indicates no meaningful data

//     return VerifyMobileResponse(
//       status: json['status'] as String? ?? 'unknown',
//       message: json['message'] as String? ?? '',
//       token: json['token'] as String? ?? '',
//       action: json['action'] as String?,
//       serviceStatus: json['service_status'] as String?,
//       data: parsedData,
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'status': status,
//       'message': message,
//       'token': token,
//       'action': action,
//       'service_status': serviceStatus,
//       'data': data?.toJson() ?? {}, // Serialize as {} if null
//     };
//   }

//   @override
//   String toString() {
//     return 'VerifyMobileResponse(status: $status, message: $message, token: $token, data: $data, action: $action, serviceStatus: $serviceStatus)';
//   }
// }

// class Data {
//   final int id;
//   final UserRole userRole;

//   Data({required this.id, required this.userRole});

//   factory Data.fromJson(Map<String, dynamic> json) {
//     // If keys are missing, use fallbacks
//     final id = json['id'] as int? ?? -1;
//     final roleStr = json['role'] as String?;
//     final userRole = UserRole.fromString(roleStr);

//     return Data(id: id, userRole: userRole);
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'id': id,
//       'role': userRole.name, // Dart 3+ `.name` gives string value
//     };
//   }

//   @override
//   String toString() => 'Data(id: $id, userRole: $userRole)';
// }


// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../core/controller /login_controller.dart';
// import '../core/controller /signup_controller.dart';
// import '../../theme/colors.dart';
// import '../../theme/theme.dart';
// import '../../customer/ui/widgets/custom_text_field.dart';
// import 'signup_screen.dart';

// class LoginScreen extends GetView<LoginController> {
//   final _formKey = GlobalKey<FormState>();
//   final double _currentSliderValue = 20;

//   LoginScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final screenHeight = MediaQuery.of(context).size.height;
//     final screenWidth = MediaQuery.of(context).size.width;

//     return Scaffold(
//       body: Container(
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//             colors: [
//               AppColors.backgroundLight,
//               AppColors.backgroundGradientEnd.withOpacity(0.9),
//             ],
//             stops: const [0.1, 0.9],
//           ),
//         ),
//         child: SafeArea(
//           child: SingleChildScrollView(
//             padding: EdgeInsets.symmetric(
//               horizontal: screenWidth > 600 ? screenWidth * 0.15 : 24.0,
//               vertical: 16.0,
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 // Animated Logo Section
//                 ScaleTransition(
//                   scale: controller.logoAnimation,
//                   child: Container(
//                     margin: const EdgeInsets.only(top: 20),
//                     child: Stack(
//                       alignment: Alignment.center,
//                       children: [
//                         // Background glow effect
//                         Container(
//                           height: 140,
//                           width: 140,
//                           decoration: BoxDecoration(
//                             shape: BoxShape.circle,
//                             boxShadow: [
//                               BoxShadow(
//                                 color: AppColors.primary.withOpacity(0.3),
//                                 blurRadius: 25,
//                                 spreadRadius: 5,
//                               ),
//                             ],
//                           ),
//                         ),
//                         // Logo container
//                         Container(
//                           height: 120,
//                           width: 120,
//                           decoration: BoxDecoration(
//                             color: Colors.white,
//                             shape: BoxShape.circle,
//                             boxShadow: [
//                               BoxShadow(
//                                 color: AppColors.primary.withOpacity(0.2),
//                                 blurRadius: 15,
//                                 spreadRadius: 2,
//                               ),
//                             ],
//                           ),
//                           child: CircleAvatar(
//                             radius: 80,
//                             backgroundColor: Colors.white,
//                             backgroundImage: const AssetImage(
//                               "assets/asia-logo.jpg",
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 SizedBox(height: screenHeight * 0.02),

//                 // Welcome Text
//                 FadeTransition(
//                   opacity: controller.textAnimation,
//                   child: Column(
//                     children: [
//                       Text(
//                         "Welcome to Asia Fibernet",
//                         style: AppText.headingLarge.copyWith(
//                           fontSize: screenWidth > 600 ? 32 : 28,
//                           fontWeight: FontWeight.w700,
//                           color: AppColors.textColorPrimary,
//                         ),
//                         textAlign: TextAlign.center,
//                       ),
//                       SizedBox(height: screenHeight * 0.01),
//                       Padding(
//                         padding: EdgeInsets.symmetric(
//                           horizontal: screenWidth > 600 ? 60 : 0,
//                         ),
//                         child: Text(
//                           "Ultra-fast internet solutions for your home and business",
//                           textAlign: TextAlign.center,
//                           style: AppText.bodyMedium.copyWith(
//                             color: AppColors.textColorSecondary,
//                             fontSize: screenWidth > 600 ? 18 : 16,
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 SizedBox(height: screenHeight * 0.04),

//                 // Login Card
//                 ScaleTransition(
//                   scale: controller.cardAnimation,
//                   child: Card(
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(20),
//                     ),
//                     elevation: 8,
//                     shadowColor: AppColors.primary.withOpacity(0.2),
//                     color: AppColors.cardBackground,
//                     child: Padding(
//                       padding: const EdgeInsets.all(24.0),
//                       child: Form(
//                         key: _formKey,
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Text(
//                               "Customer Login",
//                               style: AppText.headingSmall.copyWith(
//                                 fontSize: 22,
//                                 fontWeight: FontWeight.w600,
//                               ),
//                             ),
//                             SizedBox(height: screenHeight * 0.008),
//                             Text(
//                               "Login with your mobile number",
//                               style: AppText.bodySmall.copyWith(
//                                 color: AppColors.textColorSecondary,
//                               ),
//                             ),
//                             SizedBox(height: screenHeight * 0.03),

//                             // Mobile Number Input
//                             Text(
//                               "Mobile Number",
//                               style: AppText.labelMedium.copyWith(
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                             SizedBox(height: screenHeight * 0.01),
//                             Container(
//                               decoration: BoxDecoration(
//                                 color: AppColors.inputBackground,
//                                 borderRadius: BorderRadius.circular(12),
//                                 border: Border.all(
//                                   color: AppColors.dividerColor.withOpacity(
//                                     0.2,
//                                   ),
//                                   width: 1,
//                                 ),
//                               ),
//                               child: Row(
//                                 children: [
//                                   Padding(
//                                     padding: const EdgeInsets.symmetric(
//                                       horizontal: 16.0,
//                                     ),
//                                     child: Text(
//                                       "+91",
//                                       style: AppText.labelLarge.copyWith(
//                                         fontWeight: FontWeight.w600,
//                                       ),
//                                     ),
//                                   ),
//                                   Container(
//                                     height: 30,
//                                     width: 1,
//                                     color: AppColors.dividerColor.withOpacity(
//                                       0.3,
//                                     ),
//                                   ),
//                                   Expanded(
//                                     child: CustomTextField(
//                                       controller: controller.phoneController,
//                                       keyboardType: TextInputType.phone,
//                                       hintText: "Enter your 10-digit number",
//                                       prefixIcon: null,
//                                       validator: (value) {
//                                         if (value == null || value.isEmpty) {
//                                           return 'Please enter your number';
//                                         }
//                                         if (value.length != 10) {
//                                           return 'Enter valid 10-digit number';
//                                         }
//                                         return null;
//                                       },
//                                       labelText: '',
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                             SizedBox(height: screenHeight * 0.03),

//                             // Send OTP Button
//                             Obx(
//                               () => SizedBox(
//                                 width: double.infinity,
//                                 height: 56,
//                                 child: ElevatedButton(
//                                   onPressed:
//                                       controller.isLoading.value
//                                           ? null
//                                           : () {
//                                             if (_formKey.currentState!
//                                                 .validate()) {
//                                               controller.login();
//                                             }
//                                           },
//                                   style: ElevatedButton.styleFrom(
//                                     backgroundColor: AppColors.primary,
//                                     foregroundColor: Colors.white,
//                                     shape: RoundedRectangleBorder(
//                                       borderRadius: BorderRadius.circular(12),
//                                     ),
//                                     elevation: 2,
//                                     shadowColor: AppColors.primary.withOpacity(
//                                       0.4,
//                                     ),
//                                     disabledBackgroundColor: AppColors.primary
//                                         .withOpacity(0.5),
//                                   ),
//                                   child:
//                                       controller.isLoading.value
//                                           ? SizedBox(
//                                             height: 20,
//                                             width: 20,
//                                             child: CircularProgressIndicator(
//                                               strokeWidth: 2,
//                                               valueColor:
//                                                   const AlwaysStoppedAnimation<
//                                                     Color
//                                                   >(Colors.white),
//                                             ),
//                                           )
//                                           : Text(
//                                             "SEND OTP",
//                                             style: AppText.button.copyWith(
//                                               fontSize: 16,
//                                               fontWeight: FontWeight.w600,
//                                             ),
//                                           ),
//                                 ),
//                               ),
//                             ),
//                             SizedBox(height: screenHeight * 0.025),

//                             // Forgot Password
//                             Center(
//                               child: TextButton(
//                                 onPressed: () {
//                                   // Handle Forgot Password
//                                 },
//                                 child: Text(
//                                   "Forgot Password?",
//                                   style: AppText.link.copyWith(
//                                     color: AppColors.primary,
//                                     fontWeight: FontWeight.w600,
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 SizedBox(height: screenHeight * 0.04),

//                 // Sign Up Link
//                 FadeTransition(
//                   opacity: controller.textAnimation,
//                   child: Column(
//                     children: [
//                       SizedBox(height: screenHeight * 0.02),
//                       SizedBox(
//                         width: double.infinity,
//                         child: OutlinedButton(
//                           onPressed: () {
//                             Get.to(
//                               () => SignUpScreen(),
//                               binding: BindingsBuilder(() {
//                                 Get.lazyPut<SignUpController>(
//                                   () => SignUpController(),
//                                 );
//                               }),
//                             );
//                           },
//                           style: OutlinedButton.styleFrom(
//                             foregroundColor: AppColors.primary,
//                             side: BorderSide(
//                               color: AppColors.primary,
//                               width: 1.5,
//                             ),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             padding: const EdgeInsets.symmetric(vertical: 16),
//                           ),
//                           child: Text(
//                             "APPLY FOR NEW CONNECTION",
//                             style: AppText.button.copyWith(
//                               color: AppColors.backgroundLight,
//                               fontWeight: FontWeight.w600,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 SizedBox(height: screenHeight * 0.03),

//                 // Footer text
//                 Text(
//                   "© 2023 Asia Fibernet. All rights reserved",
//                   style: AppText.bodySmall.copyWith(
//                     color: AppColors.textColorHint,
//                     fontSize: 12,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// // Adjust imports according to your project structure
// import '../core/controller /otp_controller.dart'; // Ensure this path is correct
// import '../../theme/colors.dart'; // Ensure path is correct
// import '../../theme/theme.dart'; // Ensure AppText is defined here

// class OTPScreen extends GetView<OTPController> {
//   // Correctly uses GetView
//   // --- FIX: Remove the phone parameter from the widget constructor ---
//   // final String phone; // <-- Remove this line
//   // OTPScreen({required this.phone}); // <-- Remove this line

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//             colors: [
//               AppColors.backgroundLight,
//               AppColors.backgroundGradientEnd,
//             ],
//           ),
//         ),
//         child: SafeArea(
//           child: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 24.0),
//             child: Column(
//               children: [
//                 SizedBox(height: 40),
//                 Icon(Icons.verified_user, size: 80, color: AppColors.primary),
//                 SizedBox(height: 24),
//                 Text("Verify Your Number", style: AppText.headingMedium),
//                 SizedBox(height: 16),
//                 // --- FIX: Access phone number from controller ---
//                 RichText(
//                   text: TextSpan(
//                     text: "Enter the OTP sent to ",
//                     style: AppText.bodyMedium.copyWith(
//                       color: AppColors.textColorSecondary,
//                     ),
//                     children: [
//                       TextSpan(
//                         // --- Use controller.phone ---
//                         text: "+91 ${controller.phone}", // <-- Changed here
//                         style: AppText.bodyMedium.copyWith(
//                           fontWeight: FontWeight.bold,
//                           color: AppColors.textColorPrimary,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 SizedBox(height: 40),
//                 // OTP Input Fields
//                 // --- FIX: Consider if Obx is needed here. The fields themselves update.
//                 // The Obx might be okay if otpControllers itself could change (it doesn't here).
//                 // Alternatively, just build the list directly.
//                 // Let's keep Obx for now as it's watching the controller.
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: List.generate(6, (index) {
//                     return SizedBox(
//                       width: 50,
//                       height: 60,
//                       child: TextField(
//                         controller: controller.otpControllers[index],
//                         focusNode: controller.focusNodes[index],
//                         keyboardType: TextInputType.number,
//                         textAlign: TextAlign.center,
//                         style: AppText.headingSmall.copyWith(
//                           color: AppColors.textColorPrimary,
//                           fontSize: 24,
//                         ),
//                         decoration: InputDecoration(
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(12),
//                             borderSide: BorderSide.none,
//                           ),
//                           filled: true,
//                           fillColor: AppColors.cardBackground,
//                           counterText: '',
//                           contentPadding: EdgeInsets.zero,
//                         ),
//                         maxLength: 1,
//                         onChanged:
//                             (value) => controller.onOtpChanged(value, index),
//                       ),
//                     );
//                   }),
//                 ),

//                 SizedBox(height: 24),
//                 // Resend OTP - This Obx is correct
//                 Obx(
//                   () => Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Text(
//                         "Didn't receive OTP? ",
//                         style: AppText.bodyMedium.copyWith(
//                           color: AppColors.textColorSecondary,
//                         ),
//                       ),
//                       TextButton(
//                         onPressed:
//                             controller.resendEnabled.value
//                                 ? () {
//                                   controller.resendOTP();
//                                 }
//                                 : null,
//                         child: Text(
//                           controller.resendEnabled.value
//                               ? "Resend OTP"
//                               : "Resend in ${controller.secondsRemaining.value} s",
//                           style: TextStyle(
//                             color:
//                                 controller.resendEnabled.value
//                                     ? AppColors.primary
//                                     : Colors.grey,
//                             fontWeight: FontWeight.bold,
//                             // fontSize: 16, // Consider using AppText.labelMedium or similar
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Spacer(),
//                 Padding(
//                   padding: const EdgeInsets.only(bottom: 40.0),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       controller.verifyAndLogin();
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: AppColors.primary,
//                       foregroundColor:
//                           Colors.white, // Add foreground color for text
//                       minimumSize: Size(double.infinity, 56),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       elevation: 0,
//                     ),
//                     child: Text("VERIFY & LOGIN", style: AppText.button),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


// // screens/scaffold_screen.dart
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../core/controller /customer_complaint_controller.dart';
// import '../../theme/colors.dart';
// import '../../theme/theme.dart';
// import '../../customer/ui/screen/pages/complaints_page.dart';
// import '../../customer/ui/screen/pages/home_page.dart';
// import '../../customer/ui/screen/pages/referral_screen.dart';
// import '../../customer/ui/screen/profile_screen.dart';

// // screens/scaffold_screen.dart
// class ScaffoldScreen extends StatefulWidget {
//   const ScaffoldScreen({super.key});

//   @override
//   _ScaffoldScreenState createState() => _ScaffoldScreenState();
// }

// class _ScaffoldScreenState extends State<ScaffoldScreen> {
//   int _currentIndex = 0;
//   final List<Widget> _screens = [
//     HomeScreenContent(),
//     ComplaintsScreen(),
//     ReferralScreen(),
//   ]; // Added ReferralScreen

//   void _onItemTapped(int index) {
//     setState(() {
//       Get.lazyPut<HomeController>(() => HomeController());
//       Get.lazyPut<ComplaintController>(() => ComplaintController());
//       Get.lazyPut<ReferralController>(() => ReferralController());
//       _currentIndex = index;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       extendBody: true, // Important for FAB positioning
//       appBar: AppBar(
//         centerTitle: false,
//         title: Obx(() {
//           // Listen to the HomeController's customer observable
//           final controller = Get.find<HomeController>();
//           // Safely get customer details
//           final customerData = controller.customer.value;
//           final name = customerData?.contactName ?? "User";

//           // Display greeting text
//           return Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 "Hello, $name!",
//                 style: AppText.headingSmall.copyWith(
//                   color: AppColors.textColorPrimary,
//                   fontWeight: FontWeight.w600,
//                 ),
//               ),
//               Text(
//                 "Welcome to Asia Fibernet",
//                 style: AppText.bodySmall.copyWith(
//                   color: AppColors.textColorSecondary.withOpacity(0.8),
//                 ),
//               ),
//             ],
//           );
//         }),
//         backgroundColor: Colors.white,
//         elevation: 0,
//         shadowColor: AppColors.primary.withOpacity(0.1),
//         actions: [
//           // ... potentially other actions like notifications ...
//           // Profile Avatar Action Button
//           Obx(() {
//             // Listen to the HomeController's customer observable for the avatar
//             final controller = Get.find<HomeController>();
//             final customerData = controller.customer.value;
//             final profileImageUrl =
//                 customerData?.fullProfileImageUrl; // Use the helper getter

//             // Show a default icon if no image URL is available or customer is null
//             if (profileImageUrl == null) {
//               return Padding(
//                 padding: const EdgeInsets.only(right: 16.0),
//                 child: CircleAvatar(
//                   backgroundColor: AppColors.primary.withOpacity(0.1),
//                   child: Icon(
//                     Icons.person, // Default icon
//                     color: AppColors.primary,
//                   ),
//                 ),
//               );
//             }

//             // Show the profile image from the network
//             return GestureDetector(
//               onTap: () {
//                 Get.to(() => ProfileScreen()); // Navigate to Profile
//               },
//               child: Padding(
//                 padding: const EdgeInsets.only(right: 16.0),
//                 child: CircleAvatar(
//                   backgroundColor: AppColors.primary.withOpacity(
//                     0.1,
//                   ), // Background if image fails
//                   foregroundImage: NetworkImage(
//                     "https://dgipe.com/af/api/${controller.customer.value!.profileImageUrl}",
//                   ), // Load image
//                   // Optional: Add a placeholder/error widget
//                   child:
//                       profileImageUrl.isEmpty
//                           ? Icon(Icons.person, color: AppColors.primary)
//                           : null, // Let foregroundImage handle it, or show placeholder/error icon
//                 ),
//               ),
//             );
//           }),
//         ],
//       ),
//       body: AnimatedSwitcher(
//         duration: Duration(milliseconds: 300),
//         child: _screens[_currentIndex],
//         transitionBuilder: (child, animation) {
//           return FadeTransition(opacity: animation, child: child);
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           setState(() {
//             _currentIndex = 2; // Switch to ReferralScreen
//           });
//         },
//         backgroundColor: AppColors.primary,
//         elevation: 5,
//         shape: CircleBorder(),
//         child: Icon(Icons.people_alt, color: Colors.white),
//       ),
//       floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
//       bottomNavigationBar: Container(
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 10,
//               spreadRadius: 2,
//             ),
//           ],
//         ),
//         child: ClipRRect(
//           borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//           child: BottomAppBar(
//             shape: CircularNotchedRectangle(), // This creates the notch for FAB
//             notchMargin: 8.0,
//             color: Colors.white,
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 // Home Button
//                 _buildNavBarItem(
//                   icon:
//                       _currentIndex == 0
//                           ? Icons.home_filled
//                           : Icons.home_outlined,
//                   label: 'Home',
//                   isSelected: _currentIndex == 0,
//                   onTap: () => _onItemTapped(0),
//                 ),

//                 // Support Button
//                 _buildNavBarItem(
//                   icon:
//                       _currentIndex == 1
//                           ? Icons.support_agent
//                           : Icons.support_agent_outlined,
//                   label: 'Support',
//                   isSelected: _currentIndex == 1,
//                   onTap: () => _onItemTapped(1),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildNavBarItem({
//     required IconData icon,
//     required String label,
//     required bool isSelected,
//     required VoidCallback onTap,
//   }) {
//     return Expanded(
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           onTap: onTap,
//           child: Padding(
//             padding: EdgeInsets.symmetric(vertical: 0),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Container(
//                   padding: EdgeInsets.all(6),
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     color:
//                         isSelected
//                             ? AppColors.primary.withOpacity(0.1)
//                             : Colors.transparent,
//                   ),
//                   child: Icon(
//                     icon,
//                     size: 24,
//                     color:
//                         isSelected
//                             ? AppColors.primary
//                             : AppColors.textColorHint,
//                   ),
//                 ),
//                 // SizedBox(height: 4),
//                 Text(
//                   label,
//                   style: AppText.labelMedium.copyWith(
//                     fontWeight:
//                         isSelected ? FontWeight.w600 : FontWeight.normal,
//                     fontSize: 12,
//                     color:
//                         isSelected
//                             ? AppColors.primary
//                             : AppColors.textColorHint,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


// // lib/src/ui/screen/signup_screen.dart
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import '../core/controller /signup_controller.dart';
// import '../../theme/colors.dart';
// import '../../theme/theme.dart';
// import '../../customer/ui/widgets/custom_text_field.dart';

// class SignUpScreen extends GetView<SignUpController> {
//   final _formKey = GlobalKey<FormState>();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.backgroundLight,
//       appBar: AppBar(
//         title: Text(
//           "New Connection",
//           style: AppText.headingSmall.copyWith(color: AppColors.textColorLight),
//         ),
//         centerTitle: true,
//         backgroundColor: AppColors.primary,
//         elevation: 0,
//         iconTheme: IconThemeData(color: AppColors.textColorLight),
//         systemOverlayStyle: SystemUiOverlayStyle.light.copyWith(
//           statusBarColor: AppColors.primary,
//         ),
//       ),
//       body: Obx(() {
//         return Stack(
//           children: [
//             // Background decoration
//             Positioned(
//               top: -50,
//               right: -50,
//               child: Container(
//                 width: 200,
//                 height: 200,
//                 decoration: BoxDecoration(
//                   color: AppColors.primary.withOpacity(0.1),
//                   shape: BoxShape.circle,
//                 ),
//               ),
//             ),

//             SingleChildScrollView(
//               padding: const EdgeInsets.all(24),
//               child: Form(
//                 key: _formKey,
//                 child: Column(
//                   children: [
//                     // Animated header
//                     ScaleTransition(
//                       scale: controller.cardAnimation,
//                       child: Container(
//                         width: 120,
//                         height: 120,
//                         decoration: BoxDecoration(
//                           gradient: LinearGradient(
//                             colors: [AppColors.primary, AppColors.primaryDark],
//                             begin: Alignment.topLeft,
//                             end: Alignment.bottomRight,
//                           ),
//                           shape: BoxShape.circle,
//                           boxShadow: [
//                             BoxShadow(
//                               color: AppColors.primary.withOpacity(0.3),
//                               blurRadius: 15,
//                               spreadRadius: 5,
//                             ),
//                           ],
//                         ),
//                         child: Center(
//                           child: Icon(
//                             Icons.connected_tv,
//                             size: 50,
//                             color: AppColors.textColorLight,
//                           ),
//                         ),
//                       ),
//                     ),

//                     SizedBox(height: 24),

//                     FadeTransition(
//                       opacity: controller.textAnimation,
//                       child: Center(
//                         child: Text(
//                           "Ultra-Fast Fiber Connection",
//                           style: AppText.headingMedium.copyWith(
//                             color: AppColors.primaryDark,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                       ),
//                     ),

//                     SizedBox(height: 8),

//                     FadeTransition(
//                       opacity: controller.textAnimation,
//                       child: Center(
//                         child: Text(
//                           "Get connected within 48 hours",
//                           style: AppText.bodyMedium.copyWith(
//                             color: AppColors.textColorSecondary,
//                           ),
//                         ),
//                       ),
//                     ),

//                     SizedBox(height: 40),

//                     // Form container with subtle shadow
//                     Container(
//                       padding: EdgeInsets.all(20),
//                       decoration: BoxDecoration(
//                         color: AppColors.cardBackground,
//                         borderRadius: BorderRadius.circular(16),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.black.withOpacity(0.05),
//                             blurRadius: 20,
//                             spreadRadius: 5,
//                           ),
//                         ],
//                       ),
//                       child: Column(
//                         children: [
//                           // Personal Details Section
//                           _buildSectionHeader("Personal Details"),

//                           CustomTextField(
//                             controller: controller.fullNameController,
//                             labelText: "Full Name",
//                             prefixIcon: Icon(
//                               Icons.person_outline,
//                               color: AppColors.primary,
//                             ),
//                             keyboardType: TextInputType.name,
//                             validator:
//                                 (value) =>
//                                     value?.isEmpty ?? true
//                                         ? 'Please enter your full name'
//                                         : null,
//                             hintText: '',
//                           ),

//                           SizedBox(height: 16),

//                           Row(
//                             children: [
//                               Expanded(
//                                 flex: 3,
//                                 child: CustomTextField(
//                                   controller: controller.mobileNumberController,
//                                   labelText: "Mobile Number",
//                                   prefixIcon: Icon(
//                                     Icons.phone_android_outlined,
//                                     color: AppColors.primary,
//                                   ),
//                                   keyboardType: TextInputType.phone,
//                                   validator: (value) {
//                                     if (value?.isEmpty ?? true)
//                                       return 'Please enter mobile number';
//                                     if (value!.length != 10 ||
//                                         !RegExp(r'^[0-9]+$').hasMatch(value)) {
//                                       return 'Invalid mobile number';
//                                     }
//                                     return null;
//                                   },
//                                   hintText: '',
//                                 ),
//                               ),
//                               SizedBox(width: 16),
//                               Expanded(
//                                 flex: 4,
//                                 child: CustomTextField(
//                                   controller: controller.emailController,
//                                   labelText: "Email Address",
//                                   prefixIcon: Icon(
//                                     Icons.email_outlined,
//                                     color: AppColors.primary,
//                                   ),
//                                   keyboardType: TextInputType.emailAddress,
//                                   validator: (value) {
//                                     if (value?.isEmpty ?? true)
//                                       return 'Please enter email';
//                                     if (!GetUtils.isEmail(value!))
//                                       return 'Invalid email address';
//                                     return null;
//                                   },
//                                   hintText: '',
//                                 ),
//                               ),
//                             ],
//                           ),

//                           SizedBox(height: 24),
//                           _buildSectionHeader("Installation Address"),

//                           CustomTextField(
//                             controller: controller.addressController,
//                             labelText: "Full Address",
//                             prefixIcon: Icon(
//                               Icons.home_outlined,
//                               color: AppColors.primary,
//                             ),
//                             validator:
//                                 (value) =>
//                                     value?.isEmpty ?? true
//                                         ? 'Please enter address'
//                                         : null,
//                             hintText: '',
//                             keyboardType: TextInputType.multiline,
//                           ),

//                           SizedBox(height: 16),

//                           Row(
//                             children: [
//                               Expanded(
//                                 child: CustomTextField(
//                                   controller: controller.cityController,
//                                   labelText: "City",
//                                   prefixIcon: Icon(
//                                     Icons.location_city_outlined,
//                                     color: AppColors.primary,
//                                   ),
//                                   keyboardType: TextInputType.text,
//                                   validator:
//                                       (value) =>
//                                           value?.isEmpty ?? true
//                                               ? 'Please enter city'
//                                               : null,
//                                   hintText: '',
//                                 ),
//                               ),
//                               SizedBox(width: 16),
//                               Expanded(
//                                 child: CustomTextField(
//                                   keyboardType: TextInputType.text,
//                                   controller: controller.stateController,
//                                   labelText: "State",
//                                   prefixIcon: Icon(
//                                     Icons.map_outlined,
//                                     color: AppColors.primary,
//                                   ),
//                                   validator:
//                                       (value) =>
//                                           value?.isEmpty ?? true
//                                               ? 'Please enter state'
//                                               : null,
//                                   hintText: '',
//                                 ),
//                               ),
//                             ],
//                           ),

//                           SizedBox(height: 16),

//                           CustomTextField(
//                             controller: controller.pincodeController,
//                             labelText: "Pincode",
//                             prefixIcon: Icon(
//                               Icons.pin_outlined,
//                               color: AppColors.primary,
//                             ),
//                             keyboardType: TextInputType.number,
//                             hintText: '',
//                           ),

//                           SizedBox(height: 24),

//                           // _buildSectionHeader("Connection Details"),

//                           // Text(
//                           //   "Select Plan",
//                           //   style: AppText.labelMedium.copyWith(
//                           //     color: AppColors.primaryDark,
//                           //     fontWeight: FontWeight.w600,
//                           //   ),
//                           // ),

//                           // SizedBox(height: 8),

//                           // Container(
//                           //   decoration: BoxDecoration(
//                           //     color: AppColors.inputBackground,
//                           //     borderRadius: BorderRadius.circular(12),
//                           //     border: Border.all(
//                           //       color: AppColors.primary.withOpacity(0.3),
//                           //       width: 1,
//                           //     ),
//                           //   ),
//                           //   child: Padding(
//                           //     padding: const EdgeInsets.symmetric(
//                           //       horizontal: 16.0,
//                           //     ),
//                           //     child: DropdownButtonFormField<String>(
//                           //       value:
//                           //           controller.selectedPlan.value.isEmpty
//                           //               ? null
//                           //               : controller.selectedPlan.value,
//                           //       items: [
//                           //         _buildPlanItem(
//                           //           "Basic Fiber",
//                           //           "₹799/month",
//                           //           "100 Mbps Unlimited",
//                           //         ),
//                           //         _buildPlanItem(
//                           //           "Premium Fiber",
//                           //           "₹1299/month",
//                           //           "300 Mbps Unlimited + OTT",
//                           //         ),
//                           //         _buildPlanItem(
//                           //           "Ultra Fiber",
//                           //           "₹1999/month",
//                           //           "1 Gbps Unlimited + OTT Premium",
//                           //         ),
//                           //       ],
//                           //       onChanged:
//                           //           (value) =>
//                           //               controller.selectedPlan.value =
//                           //                   value ?? '',
//                           //       validator:
//                           //           (value) =>
//                           //               value?.isEmpty ?? true
//                           //                   ? 'Please select a plan'
//                           //                   : null,
//                           //       decoration: InputDecoration(
//                           //         border: InputBorder.none,
//                           //       ),
//                           //       dropdownColor: AppColors.cardBackground,
//                           //       style: AppText.bodyMedium.copyWith(
//                           //         color: AppColors.textColorPrimary,
//                           //       ),
//                           //       hint: Text(
//                           //         "Choose your broadband plan",
//                           //         style: AppText.bodyMedium.copyWith(
//                           //           color: AppColors.textColorHint,
//                           //         ),
//                           //       ),
//                           //     ),
//                           //   ),
//                           // ),

//                           // SizedBox(height: 16),
//                           CustomTextField(
//                             keyboardType: TextInputType.text,
//                             controller: controller.referralCodeController,
//                             labelText: "Referral Code (Optional)",
//                             prefixIcon: Icon(
//                               Icons.card_giftcard_outlined,
//                               color: AppColors.primary,
//                             ),
//                             hintText: '',
//                           ),

//                           SizedBox(height: 32),

//                           // Submit Button with gradient
//                           Container(
//                             width: double.infinity,
//                             height: 50,
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(12),
//                               gradient: LinearGradient(
//                                 colors: [
//                                   AppColors.primary,
//                                   AppColors.primaryDark,
//                                 ],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               boxShadow: [
//                                 BoxShadow(
//                                   color: AppColors.primary.withOpacity(0.3),
//                                   blurRadius: 10,
//                                   spreadRadius: 1,
//                                   offset: Offset(0, 3),
//                                 ),
//                               ],
//                             ),
//                             child: ElevatedButton(
//                               onPressed:
//                                   controller.isRegistering.value
//                                       ? null
//                                       : () {
//                                         if (_formKey.currentState!.validate()) {
//                                           controller.registerCustomer();
//                                         }
//                                       },
//                               style: ElevatedButton.styleFrom(
//                                 backgroundColor: Colors.transparent,
//                                 shadowColor: Colors.transparent,
//                                 shape: RoundedRectangleBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                 ),
//                                 padding: EdgeInsets.zero,
//                               ),
//                               child:
//                                   controller.isRegistering.value
//                                       ? SizedBox(
//                                         height: 20,
//                                         width: 20,
//                                         child: CircularProgressIndicator(
//                                           strokeWidth: 2,
//                                           valueColor:
//                                               AlwaysStoppedAnimation<Color>(
//                                                 AppColors.textColorLight,
//                                               ),
//                                         ),
//                                       )
//                                       : Text(
//                                         "SUBMIT APPLICATION",
//                                         style: AppText.button.copyWith(
//                                           color: AppColors.textColorLight,
//                                           fontWeight: FontWeight.bold,
//                                           letterSpacing: 1,
//                                         ),
//                                       ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),

//                     SizedBox(height: 24),

//                     // Footer text
//                     Text(
//                       "Our representative will contact you within 2 hours to confirm your application",
//                       textAlign: TextAlign.center,
//                       style: AppText.bodySmall.copyWith(
//                         color: AppColors.textColorSecondary,
//                         fontStyle: FontStyle.italic,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         );
//       }),
//     );
//   }

//   Widget _buildSectionHeader(String title) {
//     return Padding(
//       padding: const EdgeInsets.only(bottom: 16.0),
//       child: Row(
//         children: [
//           Container(
//             height: 24,
//             width: 4,
//             decoration: BoxDecoration(
//               color: AppColors.primary,
//               borderRadius: BorderRadius.circular(2),
//             ),
//           ),
//           SizedBox(width: 8),
//           Text(
//             title,
//             style: AppText.labelLarge.copyWith(
//               color: AppColors.primaryDark,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }


// // asia_fibernet_fixes/splash_screen.dart
// import 'package:asia_fibernet/src/technician/ui/screens/tech_dashboard_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../../services/sharedpref.dart';
// import '../../customer/ui/screen/unregistered_user_screen.dart'; // Import UnregisteredUserScreen
// import '../../customer/ui/screen/pages/home_page.dart'; // Import HomeController if needed

// class SplashScreen extends StatefulWidget {
//   @override
//   _SplashScreenState createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen>
//     with TickerProviderStateMixin {
//   late AnimationController _animController;
//   late Animation<double> _scaleAnim;

//   @override
//   void initState() {
//     super.initState();
//     _animController = AnimationController(
//       duration: Duration(seconds: 2),
//       vsync: this,
//     )..forward();

//     _scaleAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
//       CurvedAnimation(parent: _animController, curve: Curves.easeOutBack),
//     );

//     _checkLoginState();
//   }

//   void _checkLoginState() async {
//     await Future.delayed(Duration(seconds: 2));

//     // Check if the user is logged in (has a token)
//     final token = await AppSharedPref.instance.getToken();
//     final isLoggedIn = token != null && token.isNotEmpty;
//     final phoneNo = await AppSharedPref.instance.getMobileNumber();
//     print(phoneNo);

//     if (isLoggedIn) {
//       // If logged in, check the role
//       final role = AppSharedPref.instance.getRole();
//       if (role == "customer") {
//         // For customers, check verification status or token validity if needed
//         // For now, assuming a valid token means access to home
//         // Ensure HomeController is available if needed by HomeScreen
//         // Get.put(HomeController()); // Uncomment if HomeScreen needs it and it's not in a binding
//         Get.offAllNamed('/home');
//       } else if (role == "technician") {
//         Get.offAll(() => TechnicianDashboardScreen());
//       } else {
//         // Unknown role, redirect to login
//         Get.offAllNamed('/login');
//       }
//     } else {
//       // If not logged in, check if they are a guest/unregistered user
//       // This check depends on how you store guest status.
//       // Common ways: specific role, empty token, or verification status.
//       // Example: Check for a "Guest" role or specific condition indicating unregistered status.
//       final role = AppSharedPref.instance.getRole();
//       final isVerified = await AppSharedPref.instance.getVerificationStatus();

//       // Define your condition for an unregistered/guest user
//       // This is an example - adjust based on your logic in LoginController/OTPController
//       bool isUnregisteredUser =
//           (role == "Guest" ||
//               (token == '') &&
//               (phoneNo != '') &&
//               phoneNo != null);

//       if (isUnregisteredUser) {
//         // Navigate to the UnregisteredUserScreen
//         Get.offAll(() => UnregisteredUserScreen());
//       } else {
//         // No token and not identified as a guest, go to login
//         Get.offAllNamed('/login');
//       }
//     }
//   }

//   @override
//   void dispose() {
//     _animController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Color(0xFF1976D2),
//       body: Center(
//         child: ScaleTransition(
//           scale: _scaleAnim,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Icon(Icons.wifi, size: 100, color: Colors.white),
//               SizedBox(height: 16),
//               Text(
//                 "Asia Fibernet",
//                 style: TextStyle(
//                   fontSize: 32,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.white,
//                 ),
//               ),
//               SizedBox(height: 8),
//               Text(
//                 "High-Speed Internet",
//                 style: TextStyle(fontSize: 16, color: Colors.white70),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }



// /// APIs

// // services/api_services.dart
// import 'dart:convert';
// import 'dart:developer' as developer;
// import 'dart:io';
// import 'package:http/http.dart' as http;
// // Models
// import '../../auth/core/model/customer_details_model.dart';
// import '../../auth/core/model/verify_mobile_model.dart';
// import '../../customer/core/models/bsnl_plan_model.dart';
// import '../../customer/core/models/customer_view_complaint_model.dart';
// import '../../customer/core/models/login_history_model.dart';
// import '../../customer/core/models/plan_request_status_model.dart';
// import '../../customer/core/models/referral_data_model.dart';
// import '../../customer/core/models/technician_model.dart';
// import '../../customer/core/models/ticket_category_model.dart';
// import '../../customer/unregistered_user/unregistered_kyc_status_model.dart';
// import '../../technician/ui/screens/notifications_screen.dart';
// import '../sharedpref.dart';
// import 'base_api_service.dart'; // Import the new base service

// /// A centralized API service for all network operations.
// class ApiServices {
//   static const String _baseURL = "http://dgipe.com/af/api/";
//   final BaseApiService _apiClient = BaseApiService(
//     _baseURL,
//   ); // Instance for customer API

//   // Customer Endpoints
//   static const String _verifyMobile = "verify_mobile.php";
//   static const String _registerCustomer = "register_customer.php";
//   static const String _getCustomerDetails = "get_customer_details.php";
//   static const String _viewComplaint = "view_complaint.php";
//   static const String _raiseComplaint = "raise_complaint.php";
//   static const String _closeComplaint = "close_complaint.php";
//   static const String _fetchBsnlPlan = "fetch_bsnl_plan.php";
//   static const String _generateReferralCode = "generate_referral_code.php";
//   static const String _getReferralData = "get_referral_data.php";
//   static const String _editCustomerDetails = "edit_customer_details.php";
//   static const String _rateComplaint = "rate_complaint.php";
//   static const String _updatePlanRequest = "update_plan_request.php";
//   static const String _getTicketCategory = "get_ticket_categroy.php";
//   static const String _uploadProfilePhoto = "upload_profile_photo.php";
//   static const String _getLoginHistory = "get_login_history.php";
//   static const String _fetchTechnicianDetails = "fetch_technician_details.php";
//   static const String _getPlanRequestStatus =
//       "customer_plan_request_status.php";
//   static const String _getReferralMessage = "get_referral_message.php";
//   static const String _kycVerifyStatusCheck = "kyc_verify_status_check.php";
//   static const String _uploadNewCustomerDoc = "upload_new_customer_doc.php";
//   static const String _getNotifications = "my_notification_tech.php";

//   // ————————————————————————
//   // 🔹 Customer APIs
//   // ————————————————————————

//   Future<VerifyMobileResponse?> mobileVerification(String phoneNumber) async {
//     final body = {'mobile': phoneNumber};
//     try {
//       // This endpoint does NOT require a token, so we bypass _apiClient.post
//       // and use http.post directly to avoid unauthorized errors.
//       final url = _apiClient.buildUrl(_verifyMobile);
//       final res = await http.post(
//         url,
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode(body),
//       );
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _verifyMobile,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleResponse(
//         res,
//         (json) => VerifyMobileResponse.fromJson(json),
//       );
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _verifyMobile,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: s,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Network error. Please try again.");
//       return null;
//     }
//   }

//   Future<bool> registerCustomer({
//     required String fullName,
//     required String mobileNumber,
//     required String connectionType,
//     required String email,
//     required String city,
//     required String state,
//     required String referralCode,
//     required String wifiName,
//     required String wifiBssid,
//     required String wifiGateway,
//     required String gpsLatitude,
//     required String gpsLongitude,
//   }) async {
//     final body = {
//       'full_name': fullName,
//       'mobile_number': mobileNumber,
//       'connection_type': connectionType,
//       'email': email,
//       'city': city,
//       'state': state,
//       'referral_code': referralCode,
//       'wifi_name': wifiName,
//       'wifi_bssid': wifiBssid,
//       'wifi_gateway': wifiGateway,
//       'gps_latitude': gpsLatitude,
//       'gps_longitude': gpsLongitude,
//     };
//     try {
//       // This endpoint does NOT require a token, so we bypass _apiClient.post
//       final url = _apiClient.buildUrl(_registerCustomer);
//       final res = await http.post(
//         url,
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode(body),
//       );
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _registerCustomer,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleSuccessResponse(res, "Customer registered successfully!");
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _registerCustomer,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: s,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar(
//         "Error",
//         "Registration failed. Check your connection.",
//       );
//       return false;
//     }
//   }

//   Future<CustomerDetails?> fetchCustomerById(int id) async {
//     try {
//       final res = await _apiClient.post(_getCustomerDetails);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getCustomerDetails,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       final result = _handleResponse(
//         res,
//         (json) => CustomerDetails.fromJson(json['data']),
//       );
//       if (result != null) {
//         AppSharedPref.instance.setMobileNumber(result.cellPhone!);
//       }
//       return result;
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getCustomerDetails,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to load customer data.");
//       return null;
//     }
//   }

//   Future<List<ComplaintViewModel>?> viewComplaint(int customerId) async {
//     final body = {'id': customerId};
//     try {
//       final res = await _apiClient.post(_viewComplaint, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _viewComplaint,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleListResponse(
//         res,
//         (item) => ComplaintViewModel.fromJson(item),
//       );
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _viewComplaint,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to load complaints.");
//       return null;
//     }
//   }

//   Future<TechnicianModel?> fetchTechnicianById(int techId) async {
//     print("Called fetchTechnicianById...");
//     final requestBody = {'tech_id': techId};
//     try {
//       final response = await _apiClient.post(
//         _fetchTechnicianDetails,
//         body: requestBody,
//       );
//       developer.log('Fetching technician with ID: $techId');
//       if (response.statusCode == 200) {
//         developer.log('Technician API Response: ${response.body}');
//         final json = jsonDecode(response.body);
//         if (json['status'] == 'success') {
//           return TechnicianModel.fromJson(json['data']);
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.logApiDebug(
//           endpoint: _fetchTechnicianDetails,
//           method: 'POST',
//           statusCode: response.statusCode,
//           requestBody: jsonEncode(requestBody),
//           responseBody: response.body,
//         );
//         _apiClient.handleHttpError(response.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchTechnicianDetails,
//         method: 'POST',
//         requestBody: jsonEncode(requestBody),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Error fetching technician: $e');
//       _apiClient.showSnackbar("Error", "Failed to load technician details.");
//     }
//     return null;
//   }

//   Future<bool> raiseComplaint({
//     required String mobile,
//     required String title,
//     required String subCategory,
//     String? description,
//     File? image,
//     int assignBy = 1,
//     int? assignTo,
//     String status = "Open",
//   }) async {
//     final customerId = await AppSharedPref.instance.getUserID();
//     if (customerId == null) {
//       _apiClient.unauthorized();
//       return false;
//     }
//     String? imageBase64;
//     if (image != null) {
//       try {
//         final bytes = await image.readAsBytes();
//         imageBase64 = base64Encode(bytes);
//       } catch (e) {
//         developer.log("Image read error: $e");
//       }
//     }
//     final now = DateTime.now();
//     final ticketNo =
//         'TKT-${_formatDateTime(now)}-${(now.millisecondsSinceEpoch % 1000).toString().padLeft(3, '0')}';
//     final body = {
//       'id': customerId,
//       'registered_mobile': mobile,
//       'ticket_no': ticketNo,
//       'category': title,
//       'sub_category': subCategory,
//       'description': description ?? "N/A",
//       'image_base64': imageBase64 ?? "",
//       'status': status,
//       'customer_id': customerId,
//       'technician': 'Rahul Patil (Dummy)',
//     };
//     try {
//       final res = await _apiClient.post(_raiseComplaint, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _raiseComplaint,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleSuccessResponse(
//         res,
//         "Complaint $ticketNo raised successfully!",
//       );
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _raiseComplaint,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to submit complaint.");
//       return false;
//     }
//   }

//   Future<TicketCategoryResponse?> getTicketCategory() async {
//     try {
//       // Note: This is a GET request
//       final res = await _apiClient.get(_getTicketCategory);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getTicketCategory,
//           method: 'GET',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       return _handleResponse(
//         res,
//         (json) => TicketCategoryResponse.fromJson(json),
//       );
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getTicketCategory,
//         method: 'GET',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to fetch categories.");
//       return null;
//     }
//   }

//   Future<bool> closeComplaint({
//     required int customerId,
//     required String ticketNo,
//     required String closedRemark,
//     required String mobile,
//     required int rating,
//   }) async {
//     final body = {
//       'customer_id': customerId,
//       'ticket_no': ticketNo,
//       'closed_remark': closedRemark,
//       'status': 'closed',
//       'registered_mobile': mobile,
//       'rating': rating,
//     };
//     try {
//       final res = await _apiClient.post(_closeComplaint, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _closeComplaint,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleSuccessResponse(res, "Complaint closed successfully!");
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _closeComplaint,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to close complaint.");
//       return false;
//     }
//   }

//   Future<bool> rateComplaint({
//     required String ticketNo,
//     required int star,
//     required String insertedOn,
//     String? rateDescription,
//   }) async {
//     final body = {
//       'ticket_no': ticketNo,
//       'star': star,
//       'inserted_on': insertedOn,
//       'rate_description': rateDescription,
//     };
//     try {
//       final res = await _apiClient.post(_rateComplaint, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _rateComplaint,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleSuccessResponse(res, "Thank you for your feedback!");
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _rateComplaint,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to submit rating.");
//       return false;
//     }
//   }

//   Future<List<BsnlPlan>?> fetchBsnlPlan() async {
//     try {
//       // This endpoint does NOT require a token, so we bypass _apiClient.post
//       final url = _apiClient.buildUrl(_fetchBsnlPlan);
//       final res = await http.post(
//         url,
//         headers: {'Content-Type': 'application/json'},
//       );
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchBsnlPlan,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       return _handleListResponse(res, (item) => BsnlPlan.fromJson(item));
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _fetchBsnlPlan,
//         method: 'POST',
//         error: e,
//         stackTrace: s,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to fetch plans.");
//       return null;
//     }
//   }

//   Future<bool> updatePlanRequest({
//     required int id,
//     required int requestPlanId,
//     required int customerId,
//     required int registerMobileNo,
//   }) async {
//     final body = {
//       'id': id,
//       'request_plan_id': requestPlanId,
//       'customer_id': customerId,
//       'register_mobile_no': registerMobileNo,
//     };
//     try {
//       final res = await _apiClient.post(_updatePlanRequest, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _updatePlanRequest,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleSuccessResponse(res, "Plan update requested!");
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _updatePlanRequest,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to request plan update.");
//       return false;
//     }
//   }

//   Future<Map<String, dynamic>?> generateReferralCode() async {
//     try {
//       final res = await _apiClient.post(_generateReferralCode);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _generateReferralCode,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       return _handleResponse(res, (json) => json);
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _generateReferralCode,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to generate referral code.");
//       return null;
//     }
//   }

//   Future<List<ReferralDataModel>?> getReferralData(int customerId) async {
//     final body = {'id': customerId};
//     try {
//       final res = await _apiClient.post(_getReferralData, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getReferralData,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       final json = jsonDecode(res.body);
//       if (res.statusCode == 200 &&
//           json['status'] == 'success' &&
//           json.containsKey('referrals')) {
//         final data = json['referrals'] as List;
//         return data.map((e) => ReferralDataModel.fromJson(e)).toList();
//       } else {
//         _apiClient.showSnackbar(
//           "Error",
//           json['message'] ?? "Failed to load referrals.",
//         );
//         return null;
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getReferralData,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Network error.");
//       return null;
//     }
//   }

//   Future<bool> editCustomerDetails({
//     required int id,
//     required int customerId,
//     required String accountID,
//     required String accountType,
//     required String contactName,
//     required String address,
//     required String cellphnumber,
//     required String email,
//   }) async {
//     final body = {
//       'id': id,
//       'customer_id': customerId,
//       'AccountID': accountID,
//       'AccountType': accountType,
//       'ContactName': contactName,
//       'Address': address,
//       'Cellphnumber': cellphnumber,
//       'Email': email,
//     };
//     try {
//       final res = await _apiClient.post(_editCustomerDetails, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _editCustomerDetails,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleSuccessResponse(res, "Profile updated successfully!");
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _editCustomerDetails,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Update failed.");
//       return false;
//     }
//   }

//   Future<bool> uploadProfilePhoto(File imageFile) async {
//     String? base64Image;
//     try {
//       final bytes = await imageFile.readAsBytes();
//       base64Image = base64Encode(bytes);
//     } catch (e) {
//       developer.log("Image conversion failed: $e");
//       _apiClient.showSnackbar("Error", "Could not process image.");
//       return false;
//     }
//     final body = {'profile_photo': base64Image};
//     try {
//       final res = await _apiClient.post(_uploadProfilePhoto, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _uploadProfilePhoto,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       print("body $body");
//       print("resp ${res.body}");
//       return _handleSuccessResponse(res, "Photo uploaded successfully!");
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _uploadProfilePhoto,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Upload failed.");
//       return false;
//     }
//   }

//   Future<List<LoginHistoryModel>?> getLoginHistory(int customerId) async {
//     final body = {'customer_id': customerId};
//     try {
//       final res = await _apiClient.post(_getLoginHistory, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getLoginHistory,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       return _handleListResponse(
//         res,
//         (item) => LoginHistoryModel.fromJson(item),
//       );
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getLoginHistory,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to load login history.");
//       return null;
//     }
//   }

//   // ✅ NEW METHOD: Get customer plan request status
//   Future<PlanRequestStatusModel?> getPlanRequestStatus(int customerId) async {
//     final body = {'customer_id': customerId};
//     try {
//       final res = await _apiClient.post(_getPlanRequestStatus, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getPlanRequestStatus,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           return PlanRequestStatusModel.fromJson(json['data']);
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Failed to load plan request status.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getPlanRequestStatus,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to load plan request status.");
//     }
//     return null;
//   }

//   Future<ReferralMessageResponse?> getReferralMessage() async {
//     try {
//       final res = await _apiClient.get(_getReferralMessage);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getReferralMessage,
//           method: 'GET',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return ReferralMessageResponse.fromJson(json);
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Failed to load referral info.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getReferralMessage,
//         method: 'GET',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to load referral steps.");
//     }
//     return null;
//   }

//   // ————————————————————————
//   // 🔹 Private Helpers
//   // ————————————————————————
//   // These helpers are kept because they are specific to the logic of ApiServices
//   // and are not generic HTTP handling.

//   String _formatDateTime(DateTime dt) {
//     return "${dt.year % 100}${dt.month.toString().padLeft(2, '0')}${dt.day.toString().padLeft(2, '0')}-${dt.hour.toString().padLeft(2, '0')}${dt.minute.toString().padLeft(2, '0')}${dt.second.toString().padLeft(2, '0')}";
//   }

//   T? _handleResponse<T>(
//     http.Response res,
//     T Function(Map<String, dynamic>) fromJson,
//   ) {
//     if (res.statusCode == 200) {
//       final json = jsonDecode(res.body) as Map<String, dynamic>;
//       if (json['status'] == 'success' || json['status'] == 'exists') {
//         return fromJson(json);
//       } else {
//         _apiClient.showSnackbar("Error", json['message']);
//       }
//     } else {
//       _apiClient.handleHttpError(res.statusCode);
//     }
//     return null;
//   }

//   List<T>? _handleListResponse<T>(
//     http.Response res,
//     T Function(Map<String, dynamic>) fromJson,
//   ) {
//     if (res.statusCode == 200) {
//       final json = jsonDecode(res.body) as Map<String, dynamic>;
//       if (json['status'] == 'success' && json.containsKey('data')) {
//         final data = json['data'] as List;
//         return data.map((e) => fromJson(e as Map<String, dynamic>)).toList();
//       } else {
//         _apiClient.showSnackbar("Error", json['message'] ?? "No data found.");
//       }
//     } else {
//       _apiClient.handleHttpError(res.statusCode);
//     }
//     return null;
//   }

//   bool _handleSuccessResponse(http.Response res, String successMsg) {
//     if (res.statusCode == 200) {
//       final json = jsonDecode(res.body);
//       if (json['status'] == 'success') {
//         _apiClient.showSnackbar("Success", successMsg, isError: false);
//         return true;
//       } else {
//         _apiClient.showSnackbar("Error", json['message']);
//       }
//     } else {
//       _apiClient.handleHttpError(res.statusCode);
//     }
//     return false;
//   }

//   // ✅ Add the NEW uploadNewCustomerDocuments method here
//   /// Uploads customer details and documents for a new user registration.
//   ///
//   /// [mobileNo] The customer's mobile number.
//   /// [fullName] The customer's full name.
//   /// [idNo] The ID number (e.g., Aadhaar).
//   /// [address] The customer's full address.
//   /// [profileImage] The customer's profile photo File.
//   /// [idFrontImage] The front side of the ID proof File.
//   /// [idBackImage] The back side of the ID proof File (can be null if not required).
//   /// [addressProofImage] The address proof File (can be null if not required or same as ID).
//   /// [desiredPlan] The name of the plan the customer wants.
//   /// [idType] The type of ID (e.g., 'Aadhar', 'PAN Card'). Used for API document_type.
//   ///
//   /// Returns the registration ID (int) on success, or null on failure.
//   Future<int?> uploadNewCustomerDocuments({
//     required String mobileNo,
//     required String fullName,
//     required String idNo,
//     required String address,
//     required File profileImage,
//     required File idFrontImage,
//     File? idBackImage, // Optional, e.g., for PAN Card
//     File? addressProofImage, // Optional, might be the same as ID or separate
//     required String desiredPlan,
//     required String idType, // e.g., 'Aadhar', 'PAN Card'
//   }) async {
//     String? profileBase64, idFrontBase64, idBackBase64, addressProofBase64;

//     try {
//       // Convert images to Base64
//       profileBase64 = base64Encode(await profileImage.readAsBytes());
//       idFrontBase64 = base64Encode(await idFrontImage.readAsBytes());
//       if (idBackImage != null) {
//         idBackBase64 = base64Encode(await idBackImage.readAsBytes());
//       }
//       if (addressProofImage != null) {
//         addressProofBase64 = base64Encode(
//           await addressProofImage.readAsBytes(),
//         );
//       }
//     } catch (e) {
//       developer.log("Image conversion failed for new customer doc: $e");
//       _apiClient.showSnackbar("Error", "Could not process one or more images.");
//       return null;
//     }

//     // Build the request body according to the API specification
//     final body = {
//       'customer': {
//         'mobile_no': mobileNo,
//         'full_name': fullName,
//         'id_no': idNo,
//         'address': address,
//         'profile_image': profileBase64 ?? '',
//       },
//       'documents': [
//         {
//           'document_type': idType, // e.g., 'Aadhar'
//           'proof_front': idFrontBase64 ?? '',
//           'proof_back':
//               idBackBase64 ?? '', // Can be empty string if not applicable
//           'address_proof_img': '', // Not used for ID doc in this structure
//         },
//         if (addressProofImage != null &&
//             addressProofBase64 != null) // Only add if provided
//           {
//             'document_type': 'Address Proof', // Fixed type for address proof
//             'proof_front': '', // Not used for address proof in this structure
//             'proof_back': '', // Not used for address proof in this structure
//             'address_proof_img': addressProofBase64,
//           },
//       ],
//       'plan': {'desired_plan': desiredPlan},
//     };

//     try {
//       final res = await _apiClient.post(_uploadNewCustomerDoc, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _uploadNewCustomerDoc,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body), // Be cautious logging large base64
//           responseBody: res.body,
//         );
//       }

//       // print("Upload New Customer Doc Request Body: ${jsonEncode(body).length} chars"); // Optional debug
//       // print("Upload New Customer Doc Response: ${res.body}"); // Optional debug

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Customer and documents saved successfully!",
//             isError: false,
//           );
//           // Extract and return the registration ID
//           var registrationId = json['registration_id'];
//           if (registrationId is int) {
//             return registrationId;
//           } else if (registrationId is String) {
//             return int.tryParse(registrationId);
//           }
//           return null; // Or throw an exception if registration_id is critical
//         } else {
//           String message = json['message'] ?? "Failed to save customer data.";
//           _apiClient.showSnackbar("Error", message);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         // Depending on your API, this might not require a token for unregistered users
//         // Handle accordingly or let the generic error handler deal with it
//       }
//       _apiClient.logApiDebug(
//         endpoint: _uploadNewCustomerDoc,
//         method: 'POST',
//         // Avoid logging large base64 strings in error
//         requestBody: jsonEncode({
//           'customer': {
//             'mobile_no': mobileNo,
//             'full_name': fullName /* ... other non-base64 fields */,
//           },
//           'documents': [
//             {'document_type': idType /* ... */},
//             if (addressProofImage != null)
//               {'document_type': 'Address Proof' /* ... */},
//           ],
//           'plan': {'desired_plan': desiredPlan},
//         }),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in uploadNewCustomerDocuments: $e');
//       _apiClient.showSnackbar("Error", "Registration submission failed.");
//     }
//     return null;
//   }

//   // In your ApiServices class

//   Future<KycStatusResponse?> checkKycStatus(String mobile) async {
//     final body = {'mobile': mobile};
//     try {
//       // ✅ Use the endpoint constant, let _apiClient build the full URL
//       final res = await _apiClient.post(_kycVerifyStatusCheck, body: body);

//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _kycVerifyStatusCheck, // ✅ Correct endpoint name
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }

//       // Assuming _handleResponse is your existing helper method
//       return _handleResponse(res, (json) => KycStatusResponse.fromJson(json));
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _kycVerifyStatusCheck, // ✅ Correct endpoint name
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in checkKycStatus: $e');
//       _apiClient.showSnackbar("Error", "Failed to check KYC status.");
//       return null;
//     }
//   }

//   // Add this constant with the other endpoint constants

//   // Add this method with the other API methods
//   Future<List<NotificationData>?> getNotifications() async {
//     try {
//       final res = await _apiClient.get(_getNotifications);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getNotifications,
//           method: 'GET',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       return _handleListResponse(
//         res,
//         (item) => NotificationData.fromJson(item),
//       );
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getNotifications,
//         method: 'GET',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception: $e');
//       _apiClient.showSnackbar("Error", "Failed to load notifications.");
//       return null;
//     }
//   }
// }

// extension on int {
//   String padLeft(int totalWidth, [String fillChar = '0']) =>
//       toString().padLeft(totalWidth, fillChar);
// }


// // services/apis/attendance_leave_api.dart

// import 'dart:convert';

// import '../../technician/core/models/attendance_and_leave_model.dart';
// import 'base_api_service.dart';

// class AttendanceLeaveAPI {
//   static const String _baseURL = "https://dgipe.com/af/api/techAPI/";
//   final BaseApiService _apiClient = BaseApiService(
//     _baseURL,
//   ); // Instance for tech API
//   // Endpoints
//   static const String _punchIn = "punch_in_tech.php";
//   static const String _punchOut = "punch_out_tech.php";
//   static const String _fetchAttendance = "fetch_attendance_tech.php";
//   static const String _fetchLeaves = "fetch_leaves_tech.php";
//   static const String _cancelLeave = "cancel_leave_tech.php";
//   static const String _fetchTodayAttendance = "fetch_today_attendance_tech.php";
//   static const String _applyLeave = "apply_leave_tech.php";
//   static const String _fetchHolidays = "holiday_calendar_tech.php";

//   /// Punch In with location
//   Future<AttendanceModel?> punchIn({
//     required String inLat,
//     required String inLong,
//   }) async {
//     try {
//       final body = {'in_lat': inLat, 'in_long': inLong};

//       final res = await _apiClient.post(_punchIn, body: body);

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Punched in successfully!",
//             isError: false,
//           );
//           return AttendanceModel.fromJson(json['data']);
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Punch-in failed.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _punchIn,
//         method: 'POST',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to punch in.");
//     }
//     return null;
//   }

//   /// Punch Out with location
//   Future<bool> punchOut({required String inLat, required String inLong}) async {
//     try {
//       final body = {'in_lat': inLat, 'in_long': inLong};

//       final res = await _apiClient.post(_punchOut, body: body);

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Punched out successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Punch-out failed.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _punchOut,
//         method: 'POST',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to punch out.");
//     }
//     return false;
//   }

//   /// Fetch attendance for a specific month (YYYY-MM)
//   Future<List<AttendanceModel>?> fetchAttendanceByMonth(String month) async {
//     try {
//       final res = await _apiClient.get(
//         _fetchAttendance,
//         queryParameters: {'month': month},
//       );

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List<dynamic> data = json['data'];
//           return data
//               .map((e) => AttendanceModel.fromJson(e as Map<String, dynamic>))
//               .toList();
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "No attendance data found.",
//           );
//           return [];
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _fetchAttendance,
//         method: 'GET',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to load attendance.");
//     }
//     return null;
//   }

//   /// Fetch today’s attendance record
//   Future<AttendanceModel?> fetchTodayAttendance() async {
//     try {
//       final res = await _apiClient.get(_fetchTodayAttendance);

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           return AttendanceModel.fromJson(json['data'] as Map<String, dynamic>);
//         } else {
//           _apiClient.showSnackbar(
//             "Info",
//             json['message'] ?? "No attendance for today.",
//           );
//           return null;
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _fetchTodayAttendance,
//         method: 'GET',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to load today's attendance.");
//     }
//     return null;
//   }

//   /// Apply for a new leave
//   Future<bool> applyLeave({
//     required String leaveType,
//     required String startDate,
//     required String endDate,
//     required String reason,
//   }) async {
//     try {
//       final body = {
//         'leave_type': leaveType,
//         'start_date': startDate,
//         'end_date': endDate,
//         'reason': reason,
//       };

//       final res = await _apiClient.post(_applyLeave, body: body);

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Leave applied successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Failed to apply leave.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _applyLeave,
//         method: 'POST',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to submit leave request.");
//     }
//     return false;
//   }

//   /// Fetch leaves for a specific month (YYYY-MM)
//   Future<List<LeaveModel>?> fetchLeavesByMonth(String month) async {
//     try {
//       final res = await _apiClient.get(
//         _fetchLeaves,
//         queryParameters: {'month': month},
//       );

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List<dynamic> data = json['data'];
//           return data
//               .map((e) => LeaveModel.fromJson(e as Map<String, dynamic>))
//               .toList();
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "No leave data found.",
//           );
//           return [];
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _fetchLeaves,
//         method: 'GET',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to load leaves.");
//     }
//     return null;
//   }

//   /// Cancel a leave request by ID
//   Future<bool> cancelLeave(int leaveId) async {
//     try {
//       final body = {'leave_id': leaveId};

//       final res = await _apiClient.put(_cancelLeave, body: body);

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Leave cancelled successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Failed to cancel leave.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: _cancelLeave,
//         method: 'PUT',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to cancel leave.");
//     }
//     return false;
//   }

//   /// Fetch holidays for a specific month (YYYY-MM)
//   Future<List<HolidayModel>?> fetchHolidaysByMonth(String month) async {
//     try {
//       // Assuming the endpoint expects a 'month' query parameter like the others
//       final res = await _apiClient.post(
//         _fetchHolidays,
//         // body: {'month': month}, // Pass month parameter
//       );

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List<dynamic> data = json['data'];
//           // Map the JSON list to HolidayModel objects
//           return data
//               .map((e) => HolidayModel.fromJson(e as Map<String, dynamic>))
//               .toList();
//         } else {
//           // Handle API response indicating no data or an error message
//           _apiClient.showSnackbar(
//             "Info", // Use Info level if it's just no holidays
//             json['message'] ?? "No holidays found for this month.",
//           );
//           return []; // Return empty list if no holidays, not null
//         }
//       } else {
//         // Handle HTTP errors (e.g., 404, 500)
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e, s) {
//       // Log the error and show a user-friendly message
//       _apiClient.logApiDebug(
//         endpoint: _fetchHolidays,
//         method: 'POST',
//         error: e,
//         stackTrace: s,
//       );
//       _apiClient.showSnackbar("Error", "Failed to load holidays.");
//     }
//     // Return null if the request failed unexpectedly
//     return null;
//   }
// }


// // services/base_api_service.dart
// import 'dart:convert';
// import 'dart:developer' as developer;
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:http/http.dart' as http;
// import '../sharedpref.dart';

// class BaseApiService {
//   final String _baseUrl;

//   BaseApiService(this._baseUrl);

//   Uri buildUrl(String endpoint, {Map<String, String>? queryParameters}) {
//     final uri = Uri.parse("$_baseUrl$endpoint");
//     if (queryParameters != null && queryParameters.isNotEmpty) {
//       return uri.replace(queryParameters: queryParameters);
//     }
//     return uri;
//   }

//   /// Unified Snackbar for consistent UX
//   void showSnackbar(String title, String message, {bool isError = true}) {
//     Get.snackbar(
//       title,
//       message,
//       snackPosition: Get.isDarkMode ? SnackPosition.BOTTOM : SnackPosition.TOP,
//       backgroundColor: isError ? Colors.red : Colors.green,
//       colorText: Colors.white,
//       duration: const Duration(seconds: 3),
//     );
//   }

//   /// Handles HTTP errors and shows user-friendly messages
//   void handleHttpError(int statusCode) {
//     String msg = "Request failed.";
//     if (statusCode == 401) {
//       msg = "Session expired. Please log in again.";
//       unauthorized();
//     } else if (statusCode == 400) {
//       msg = "Invalid data sent.";
//     } else if (statusCode == 404) {
//       msg = "Resource not found.";
//     } else if (statusCode == 500) {
//       msg = "Server error.";
//     }
//     showSnackbar("Error", msg);
//   }

//   /// Handles unauthorized access
//   void unauthorized() {
//     showSnackbar("Unauthorized", "Please log in again.");
//     AppSharedPref.instance.clearAllUserData();
//     Get.offAllNamed('/login'); // Adjust route as needed
//   }

//   /// Logs detailed API information to the console for debugging.
//   void logApiDebug({
//     required String endpoint,
//     required String method,
//     int? statusCode,
//     String? requestBody,
//     String? responseBody,
//     Object? error,
//     StackTrace? stackTrace,
//   }) {
//     final buffer = StringBuffer();
//     buffer.writeln('=== API DEBUG START ===');
//     buffer.writeln('Endpoint: $endpoint');
//     buffer.writeln('Method: $method');
//     buffer.writeln('Timestamp: ${DateTime.now().toIso8601String()}');
//     if (requestBody != null) {
//       buffer.writeln('--- Request Body ---');
//       buffer.writeln(requestBody);
//     }
//     if (statusCode != null) {
//       buffer.writeln('Status Code: $statusCode');
//     }
//     if (responseBody != null) {
//       buffer.writeln('--- Response Body ---');
//       buffer.writeln(responseBody);
//     }
//     if (error != null) {
//       buffer.writeln('--- ERROR ---');
//       buffer.writeln('Error: $error');
//       if (stackTrace != null) {
//         buffer.writeln('Stack Trace: $stackTrace');
//       }
//     }
//     buffer.writeln('=== API DEBUG END ===');
//     developer.log(buffer.toString(), name: 'API_DEBUG');
//   }

//   /// Executes a POST request and returns http.Response
//   /// Automatically adds Authorization header
//   Future<http.Response> post(
//     String endpoint, {
//     Map<String, String>? headers,
//     dynamic body,
//   }) async {
//     final token = await AppSharedPref.instance.getToken();
//     if (token == null) {
//       unauthorized();
//       throw Exception('Unauthorized: No token');
//     }
//     final finalHeaders = {
//       'Authorization': 'Bearer $token',
//       'Content-Type': 'application/json',
//       ...?headers,
//     };
//     final url = buildUrl(endpoint);
//     final encodedBody = body is String ? body : jsonEncode(body);
//     return await http.post(url, headers: finalHeaders, body: encodedBody);
//   }

//   /// Executes a GET request and returns http.Response
//   Future<http.Response> get(
//     String endpoint, {
//     Map<String, String>? headers,
//     Map<String, String>? queryParameters,
//   }) async {
//     final token = await AppSharedPref.instance.getToken();
//     final isGuest = AppSharedPref.instance.getRole() == "Guest";
//     if (!isGuest) {
//       if (token == null) {
//         unauthorized();
//         throw Exception('Unauthorized: No token');
//       }
//     }
//     final finalHeaders = {'Authorization': 'Bearer $token', ...?headers};
//     final url = buildUrl(endpoint, queryParameters: queryParameters);
//     return await http.get(url, headers: finalHeaders);
//   }

//   /// Executes a PUT request and returns http.Response
//   Future<http.Response> put(
//     String endpoint, {
//     Map<String, String>? headers,
//     dynamic body,
//   }) async {
//     final token = await AppSharedPref.instance.getToken();
//     if (token == null) {
//       unauthorized();
//       throw Exception('Unauthorized: No token');
//     }
//     final finalHeaders = {
//       'Authorization': 'Bearer $token',
//       'Content-Type': 'application/json',
//       ...?headers,
//     };
//     final url = buildUrl(endpoint);
//     final encodedBody = body is String ? body : jsonEncode(body);
//     return await http.put(url, headers: finalHeaders, body: encodedBody);
//   }
// }


// // // services/apis/technician_api.dart
// // import 'dart:async';
// // import 'dart:convert';
// // import 'dart:developer' as developer;
// // import '../../auth/core/model/customer_details_model.dart';
// // import '../../technician/core/models/customer_model.dart';
// // import '../../technician/core/models/technician_profile_model.dart';
// // import '../../technician/core/models/tickets_model.dart';
// // import '../../technician/core/models/tech_dashboard_model.dart';
// // import '../utils/plugin/device_info_utils.dart';
// // import 'base_api_service.dart'; // Import the new base service

// // /// API Service for Technician-specific operations
// // class TechnicianAPI {
// //   static const String _baseURL = "https://dgipe.com/af/api/techAPI/";
// //   final BaseApiService _apiClient = BaseApiService(
// //     _baseURL,
// //   ); // Instance for tech API

// //   // Endpoints
// //   static const String _dashboard = "my_dashboard_tech.php";
// //   static const String _fetchAllTickets = "fetch_ticket_tech.php";
// //   static const String _fetchTicketByTicketNo =
// //       "fetch_ticket_by_ticketNo_tech.php";
// //   static const String _fetchAllCustomers = "fetch_all_customer_tech.php";
// //   static const String _fetchCustomerSingle = "fetch_customer_single_tech.php";
// //   static const String _complaintClose = "complaint_close_by_tech.php";
// //   static const String _trackLocation = "track_location_tech.php";
// //   static const String _updateProfile = "update_my_profile_tech.php";
// //   static const String _notifications = "my_notification_tech.php";
// //   static const String _fetchProfile = "fetch_my_profile_tech.php";
// //   static const String _fetchKyc = "kyc_doc_tech.php";
// //   static const String _fetchCustomerByMobOrName =
// //       "fetch_customer_By_mobOrName_tech.php";
// //   static const String _updateMyProfile =
// //       "update_my_profile_tech.php";

// //   // ————————————————————————
// //   // 🔹 Technician APIs
// //   // ————————————————————————

// //   /// Fetches the technician's dashboard data
// //   Future<TechDashboardModel?> getDashboard() async {
// //     try {
// //       final res = await _apiClient.post(_dashboard);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _dashboard,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success') {
// //           return TechDashboardModel.fromJson(json);
// //         } else {
// //           _apiClient.showSnackbar("Error", json['message']);
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         _apiClient.unauthorized();
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _dashboard,
// //         method: 'POST',
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in getDashboard: $e');
// //       // _apiClient.showSnackbar("Error", "Failed to load dashboard.");
// //     }
// //     _apiClient.unauthorized();
// //     return null;
// //   }

// //   /// Fetches all tickets assigned to the technician
// //   Future<List<TicketModel>?> fetchAllTickets() async {
// //     try {
// //       final res = await _apiClient.post(_fetchAllTickets);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchAllTickets,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success' && json.containsKey('data')) {
// //           final List data = json['data'];
// //           return data.map((e) => TicketModel.fromJson(e)).toList();
// //         } else {
// //           _apiClient.showSnackbar(
// //             "Error",
// //             json['message'] ?? "No tickets found.",
// //           );
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchAllTickets,
// //         method: 'POST',
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in fetchAllTickets: $e');
// //       _apiClient.showSnackbar("Error", "Failed to load tickets.");
// //     }
// //     return null;
// //   }

// //   /// Fetches a single ticket by ticket number
// //   Future<TicketModel?> fetchTicketByTicketNo(String ticketNo) async {
// //     final body = {'ticket_no': ticketNo};
// //     try {
// //       final res = await _apiClient.post(_fetchTicketByTicketNo, body: body);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchTicketByTicketNo,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           requestBody: jsonEncode(body),
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success' && json.containsKey('data')) {
// //           return TicketModel.fromJson(json['data']);
// //         } else {
// //           _apiClient.showSnackbar(
// //             "Error",
// //             json['message'] ?? "Ticket not found.",
// //           );
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchTicketByTicketNo,
// //         method: 'POST',
// //         requestBody: jsonEncode(body),
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in fetchTicketByTicketNo: $e');
// //       _apiClient.showSnackbar("Error", "Failed to load ticket.");
// //     }
// //     return null;
// //   }

// //   /// Fetches all customers assigned to the technician
// //   Future<List<CustomerModel>?> fetchAllCustomers() async {
// //     try {
// //       final res = await _apiClient.get(_fetchAllCustomers);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchAllCustomers,
// //           method: 'GET',
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success' && json.containsKey('history')) {
// //           final List data = json['history'];
// //           return data.map((e) => CustomerModel.fromJson(e)).toList();
// //         } else {
// //           return [];
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchAllCustomers,
// //         method: 'GET',
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in fetchAllCustomers: $e');
// //     }
// //     return null;
// //   }

// //   /// Fetches a single customer by ID
// //   Future<CustomerDetails?> fetchCustomerById(int findCustomerId) async {
// //     final body = {'find_customer_id': findCustomerId};
// //     try {
// //       final res = await _apiClient.post(_fetchCustomerSingle, body: body);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchCustomerSingle,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           requestBody: jsonEncode(body),
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success' && json.containsKey('data')) {
// //           return CustomerDetails.fromJson(json['data']);
// //         } else {
// //           _apiClient.showSnackbar(
// //             "Error",
// //             json['message'] ?? "Customer not found.",
// //           );
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchCustomerSingle,
// //         method: 'POST',
// //         requestBody: jsonEncode(body),
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in fetchCustomerById: $e');
// //       _apiClient.showSnackbar("Error", "Failed to load customer.");
// //     }
// //     return null;
// //   }

// //   /// Closes a complaint/ticket by technician
// //   Future<bool> closeComplaint({
// //     required String ticketNo,
// //     required String closedRemark,
// //   }) async {
// //     final body = {'ticket_no': ticketNo, 'closed_remark': closedRemark};
// //     try {
// //       final res = await _apiClient.post(_complaintClose, body: body);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _complaintClose,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           requestBody: jsonEncode(body),
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body);
// //         if (json['status'] == 'success') {
// //           _apiClient.showSnackbar(
// //             "Success",
// //             "Ticket closed successfully!",
// //             isError: false,
// //           );
// //           return true;
// //         } else {
// //           _apiClient.showSnackbar("Error", json['message']);
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return false;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _complaintClose,
// //         method: 'POST',
// //         requestBody: jsonEncode(body),
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in closeComplaint: $e');
// //       _apiClient.showSnackbar("Error", "Failed to close ticket.");
// //     }
// //     return false;
// //   }

// //   /// Uploads technician's profile photo (base64)
// //   Future<bool> uploadProfilePhoto(String base64Image) async {
// //     final body = {'profile_photo': base64Image};
// //     try {
// //       final res = await _apiClient.post(_updateProfile, body: body);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _updateProfile,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           requestBody: jsonEncode(body),
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body);
// //         if (json['status'] == 'success') {
// //           _apiClient.showSnackbar(
// //             "Success",
// //             "Photo uploaded successfully!",
// //             isError: false,
// //           );
// //           return true;
// //         } else {
// //           _apiClient.showSnackbar("Error", json['message']);
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return false;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _updateProfile,
// //         method: 'POST',
// //         requestBody: jsonEncode(body),
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in uploadProfilePhoto: $e');
// //       _apiClient.showSnackbar("Error", "Upload failed.");
// //     }
// //     return false;
// //   }

// //   /// Tracks technician's real-time location with device info
// //   Future<bool> trackLocation({
// //     required String technicianId,
// //     required String date,
// //     required String sessionDatetime,
// //     required String locationName,
// //     required String lat,
// //     required String lng,
// //   }) async {
// //     final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
// //     final body = {
// //       'technician_id': technicianId,
// //       'date': date,
// //       'session_datetime': sessionDatetime,
// //       'location': {'location_name': locationName, 'lat': lat, 'lng': lng},
// //       ...deviceInfo,
// //     };
// //     try {
// //       final res = await _apiClient.post(_trackLocation, body: body);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _trackLocation,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           requestBody: jsonEncode(body),
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body);
// //         if (json['status'] == 'success') {
// //           return true;
// //         } else {
// //           _apiClient.showSnackbar("Error", json['message']);
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return false;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _trackLocation,
// //         method: 'POST',
// //         requestBody: jsonEncode(body),
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in trackLocation: $e');
// //       _apiClient.showSnackbar("Error", "Failed to send location.");
// //     }
// //     return false;
// //   }

// //   /// Fetches technician's profile
// //   Future<Map<String, dynamic>?> fetchProfile() async {
// //     try {
// //       final res = await _apiClient.post(_fetchProfile);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchProfile,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success') {
// //           return json['data'];
// //         } else {
// //           _apiClient.showSnackbar("Error", json['message']);
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchProfile,
// //         method: 'POST',
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in fetchProfile: $e');
// //       _apiClient.showSnackbar("Error", "Failed to load profile.");
// //     }
// //     return null;
// //   }

// //   // ✅ NEW METHOD: Fetches technician's KYC details
// //   Future<TechnicianKycModel?> fetchKycDetails() async {
// //     try {
// //       final res = await _apiClient.post(_fetchKyc);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchKyc,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //       }
// //       if (res.statusCode == 200) {
// //         final json = jsonDecode(res.body) as Map<String, dynamic>;
// //         if (json['status'] == 'success' && json.containsKey('data')) {
// //           return TechnicianKycModel.fromJson(json['data']);
// //         } else {
// //           _apiClient.showSnackbar(
// //             "Info",
// //             json['message'] ?? "No KYC data found.",
// //           );
// //         }
// //       } else {
// //         _apiClient.handleHttpError(res.statusCode);
// //       }
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchKyc,
// //         method: 'POST',
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in fetchKycDetails: $e');
// //       _apiClient.showSnackbar("Error", "Failed to load KYC details.");
// //     }
// //     return null;
// //   }

// //   // ✅ NEW METHOD: Fetches unified Technician Profile (Profile + KYC)
// //   Future<TechnicianProfileModel?> fetchUnifiedProfile() async {
// //     try {
// //       // Fetch profile data
// //       final profileData = await fetchProfile();
// //       if (profileData == null) {
// //         return null; // fetchProfile handles unauthorized and shows snackbar
// //       }
// //       // Create base profile model
// //       final baseProfile = TechnicianProfileModel.fromProfileData(profileData);
// //       // Fetch KYC data
// //       final kycData = await fetchKycDetails();
// //       if (kycData == null) {
// //         // KYC fetch might have shown its own error, or it might just be empty.
// //         // Return profile without KYC.
// //         return baseProfile;
// //       }
// //       // Merge and return
// //       return baseProfile.mergeWithKyc(kycData);
// //     } catch (e, s) {
// //       _apiClient.logApiDebug(
// //         endpoint: 'fetchUnifiedProfile',
// //         method: 'COMBINED',
// //         error: e,
// //         stackTrace: s,
// //       );
// //       developer.log('Exception in fetchUnifiedProfile: $e');
// //       _apiClient.showSnackbar("Error", "Failed to load full profile.");
// //       return null;
// //     }
// //   }

// // // Add this method inside the TechnicianAPI class
// // Future<Map<String, dynamic>?> updateProfile(Map<String, dynamic> requestBody) async {
// //   try {
// //          final res = await _apiClient.post(_fetchKyc);
// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           endpoint: _fetchKyc,
// //           method: 'POST',
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //       }

// //     if (res.statusCode == 200) {
// //       final responseBody = jsonDecode(res.body);
// //       if (responseBody is Map<String, dynamic>) {
// //         return responseBody;
// //       } else {
// //         print("Invalid response format: ${res.body}");
// //         return null;
// //       }
// //     } else {
// //       print("Failed to update profile. Status code: ${res.statusCode}, Body: ${res.body}");
// //       return null;
// //     }
// //   } catch (e) {
// //     print("Error updating profile: $e");
// //     return null;
// //   }
// // }

// //   /// Searches customers by name or mobile number.
// //   ///
// //   /// [query]: The search term (name or mobile number).
// //   Future<List<CustomerModel>?> searchCustomers(String query) async {
// //     // Using positional parameter for simplicity}

// //     try {
// //       // --- KEY FIX: Use the correct parameter name expected by your API ---
// //       final res = await _apiClient.post(
// //         _fetchCustomerByMobOrName,
// //         body: {
// //           "customer_mobOrName": query,
// //         }, // <--- CHANGED: Use 'customer_mobOrName'
// //       );

// //       // Log the request details for debugging
// //       developer.log('Searching customers with query: $query');
// //       developer.log(
// //         'Request URL: ${res.request?.url.toString() ?? "N/A"}',
// //       ); // Log full URL if possible

// //       if (res.statusCode != 200) {
// //         _apiClient.logApiDebug(
// //           // Assuming _apiClient or this class has logApiDebug
// //           endpoint: _fetchCustomerByMobOrName,
// //           method: 'POST',
// //           requestBody:
// //               '{"customer_mobOrName": $query}', // Log the correct param
// //           statusCode: res.statusCode,
// //           responseBody: res.body,
// //         );
// //         _apiClient.handleHttpError(res.statusCode); // Assuming this exists
// //         return null; // Indicate network/HTTP error
// //       }

// //       if (res.statusCode == 200) {
// //         final dynamic jsonBody = jsonDecode(res.body); // Parse as dynamic first

// //         // Type check the parsed JSON
// //         if (jsonBody is! Map<String, dynamic>) {
// //           _apiClient.logApiDebug(
// //             endpoint: _fetchCustomerByMobOrName,
// //             method: 'POST',
// //             requestBody: '{"customer_mobOrName": $query}',
// //             statusCode: res.statusCode,
// //             responseBody: res.body,
// //             error: 'Response body is not a JSON object',
// //           );
// //           return null; // Unexpected response format
// //         }

// //         final Map<String, dynamic> json = jsonBody;

// //         // Check for success status
// //         if (json['status'] == 'success') {
// //           // Confirm 'status' key
// //           // Check for 'data' key and ensure it's a list
// //           if (json.containsKey('data') && json['data'] is List) {
// //             // Confirm 'data' key
// //             final List data = json['data'];
// //             // Safely map the list, checking item types
// //             try {
// //               return data
// //                   .where(
// //                     (item) => item is Map<String, dynamic>,
// //                   ) // Ensure each item is a Map
// //                   .map((e) => CustomerModel.fromJson(e as Map<String, dynamic>))
// //                   .toList();
// //             } catch (e) {
// //               _apiClient.logApiDebug(
// //                 endpoint: _fetchCustomerByMobOrName,
// //                 method: 'POST',
// //                 requestBody: '{"customer_mobOrName": $query}',
// //                 statusCode: res.statusCode,
// //                 responseBody: res.body,
// //                 error: 'Error mapping CustomerModel: $e',
// //               );
// //               return null; // Error during mapping
// //             }
// //           } else {
// //             // Log if 'data' key is missing or not a list
// //             _apiClient.logApiDebug(
// //               endpoint: _fetchCustomerByMobOrName,
// //               method: 'POST',
// //               requestBody: '{"customer_mobOrName": $query}',
// //               statusCode: res.statusCode,
// //               responseBody: res.body,
// //               error:
// //                   "Unexpected response format - 'data' key missing or not a list",
// //             );
// //             // Considered successful API call but no data found for the query
// //             return []; // Return empty list for "no results"
// //           }
// //         } else {
// //           // API responded with 200 but status is not 'success'
// //           _apiClient.logApiDebug(
// //             endpoint: _fetchCustomerByMobOrName,
// //             method: 'GET',
// //             requestBody: '{"customer_mobOrName": $query}',
// //             statusCode: res.statusCode,
// //             responseBody: res.body,
// //             error: "API returned non-success status",
// //           );
// //           // Show message from API if available
// //           String message =
// //               json['message']?.toString() ??
// //               "No customers found matching '$query'.";
// //           _apiClient.showSnackbar("Info", message); // Assuming this exists
// //           // Return empty list for "no results found" scenario when API call itself succeeded
// //           return [];
// //         }
// //       }
// //       return null; // Should generally not be reached
// //     } on TimeoutException catch (e) {
// //       // Add timeout handling if needed
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchCustomerByMobOrName,
// //         method: 'GET',
// //         requestBody: '{"customer_mobOrName": $query}',
// //         error: 'Timeout: $e',
// //         stackTrace: StackTrace.current,
// //       );
// //       _apiClient.showSnackbar("Error", "Request timed out. Please try again.");
// //       return null;
// //     } catch (e) {
// //       if (e.toString().contains('Unauthorized: No token')) {
// //         developer.log('Search failed due to unauthorized access.');
// //         return null;
// //       }
// //       _apiClient.logApiDebug(
// //         endpoint: _fetchCustomerByMobOrName,
// //         method: 'GET',
// //         requestBody: '{"customer_mobOrName": $query}',
// //         error: e,
// //         stackTrace: StackTrace.current,
// //       );
// //       developer.log('Exception in searchCustomers: $e');
// //       _apiClient.showSnackbar(
// //         "Error",
// //         "Failed to search customers. Check connection.",
// //       );
// //     }
// //     return null; // Return null on any unhandled error caught by catch block
// //   }
// // }

// // services/apis/technician_api.dart
// import 'dart:async';
// import 'dart:convert';
// import 'dart:developer' as developer;
// import '../../auth/core/model/customer_details_model.dart';
// import '../../technician/core/models/customer_model.dart';
// import '../../technician/core/models/technician_profile_model.dart';
// import '../../technician/core/models/tickets_model.dart';
// import '../../technician/core/models/tech_dashboard_model.dart';
// import '../utils/plugin/device_info_utils.dart';
// import 'base_api_service.dart'; // Import the new base service

// /// API Service for Technician-specific operations
// class TechnicianAPI {
//   static const String _baseURL =
//       "https://dgipe.com/af/api/techAPI/"; // Fixed trailing space
//   final BaseApiService _apiClient = BaseApiService(
//     _baseURL,
//   ); // Instance for tech API

//   // Endpoints
//   static const String _dashboard = "my_dashboard_tech.php";
//   static const String _fetchAllTickets = "fetch_ticket_tech.php";
//   static const String _fetchTicketByTicketNo =
//       "fetch_ticket_by_ticketNo_tech.php";
//   static const String _fetchAllCustomers = "fetch_all_customer_tech.php";
//   static const String _fetchCustomerSingle = "fetch_customer_single_tech.php";
//   static const String _complaintClose = "complaint_close_by_tech.php";
//   static const String _trackLocation = "track_location_tech.php";
//   static const String _updateProfile =
//       "update_my_profile_tech.php"; // Corrected endpoint name for update
//   static const String _notifications = "my_notification_tech.php";
//   static const String _fetchProfile = "fetch_my_profile_tech.php";
//   static const String _fetchKyc = "kyc_doc_tech.php";
//   static const String _fetchCustomerByMobOrName =
//       "fetch_customer_By_mobOrName_tech.php";
//   // Note: _updateMyProfile was redundant, using _updateProfile

//   // --- NEW EXPENSE ENDPOINTS ---
//   static const String _addExpense = "add_expenses_tech.php";
//   static const String _fetchExpenses = "fetch_expenses_tech.php";
//   static const String _fetchExpenseDetails = "fetch_expenses_details.php";

//   // --- ATTENDANCE ENDPOINTS (from provided list) ---
//   static const String _punchIn = "punch_in_tech.php";
//   static const String _punchOut = "punch_out_tech.php";
//   static const String _fetchAttendance = "fetch_attendance_tech.php";
//   static const String _fetchTodayAttendance = "fetch_today_attendance_tech.php";
//   static const String _attendanceDashboard =
//       "attandance_dashboard.php"; // Note: typo in filename from list

//   // --- LEAVE ENDPOINTS (from provided list) ---
//   static const String _applyLeave = "apply_leave_tech.php";
//   static const String _fetchLeaves = "fetch_leaves_tech.php";
//   static const String _cancelLeave = "cancel_leave_tech.php";

//   // --- OTHER ENDPOINTS (from provided list) ---
//   static const String _fetchMyRating = "fetch_my_rating_tech.php";
//   static const String _fetchMyReferral = "fetch_my_referral_tech.php";
//   static const String _fetchWorkArea = "fetch_work_area_tech.php";
//   static const String _getLoginHistory = "get_login_history_tech.php";
//   static const String _myNotification =
//       "my_notification_tech.php"; // Already defined above, can remove one
//   // --- End of added endpoints from list ---

//   // ————————————————————————
//   // 🔹 Technician APIs
//   // ————————————————————————

//   /// Fetches the technician's dashboard data
//   Future<TechDashboardModel?> getDashboard() async {
//     try {
//       final res = await _apiClient.post(_dashboard);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _dashboard,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return TechDashboardModel.fromJson(json);
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         _apiClient.unauthorized();
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _dashboard,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in getDashboard: $e');
//       // _apiClient.showSnackbar("Error", "Failed to load dashboard.");
//     }
//     _apiClient.unauthorized();
//     return null;
//   }

//   /// Fetches all tickets assigned to the technician
//   Future<List<TicketModel>?> fetchAllTickets() async {
//     try {
//       final res = await _apiClient.post(_fetchAllTickets);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchAllTickets,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List data = json['data'];
//           return data.map((e) => TicketModel.fromJson(e)).toList();
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "No tickets found.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchAllTickets,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchAllTickets: $e');
//       _apiClient.showSnackbar("Error", "Failed to load tickets.");
//     }
//     return null;
//   }

//   /// Fetches a single ticket by ticket number
//   Future<TicketModel?> fetchTicketByTicketNo(String ticketNo) async {
//     final body = {'ticket_no': ticketNo};
//     try {
//       final res = await _apiClient.post(_fetchTicketByTicketNo, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchTicketByTicketNo,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           return TicketModel.fromJson(json['data']);
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Ticket not found.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchTicketByTicketNo,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchTicketByTicketNo: $e');
//       _apiClient.showSnackbar("Error", "Failed to load ticket.");
//     }
//     return null;
//   }

//   /// Fetches all customers assigned to the technician
//   Future<List<CustomerModel>?> fetchAllCustomers() async {
//     try {
//       final res = await _apiClient.get(_fetchAllCustomers);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchAllCustomers,
//           method: 'GET',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('history')) {
//           final List data = json['history'];
//           return data.map((e) => CustomerModel.fromJson(e)).toList();
//         } else {
//           return [];
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchAllCustomers,
//         method: 'GET',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchAllCustomers: $e');
//     }
//     return null;
//   }

//   /// Fetches a single customer by ID
//   Future<CustomerDetails?> fetchCustomerById(int findCustomerId) async {
//     final body = {'find_customer_id': findCustomerId};
//     try {
//       final res = await _apiClient.post(_fetchCustomerSingle, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchCustomerSingle,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           return CustomerDetails.fromJson(json['data']);
//         } else {
//           _apiClient.showSnackbar(
//             "Error",
//             json['message'] ?? "Customer not found.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchCustomerSingle,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchCustomerById: $e');
//       _apiClient.showSnackbar("Error", "Failed to load customer.");
//     }
//     return null;
//   }

//   /// Closes a complaint/ticket by technician
//   Future<bool> closeComplaint({
//     required String ticketNo,
//     required String closedRemark,
//   }) async {
//     final body = {'ticket_no': ticketNo, 'closed_remark': closedRemark};
//     try {
//       final res = await _apiClient.post(_complaintClose, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _complaintClose,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             "Ticket closed successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _complaintClose,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in closeComplaint: $e');
//       _apiClient.showSnackbar("Error", "Failed to close ticket.");
//     }
//     return false;
//   }

//   /// Uploads technician's profile photo (base64) - Note: This might be redundant if updateProfile handles it
//   Future<bool> uploadProfilePhoto(String base64Image) async {
//     final body = {'profile_photo': base64Image};
//     try {
//       final res = await _apiClient.post(_updateProfile, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _updateProfile,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             "Photo uploaded successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _updateProfile,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in uploadProfilePhoto: $e');
//       _apiClient.showSnackbar("Error", "Upload failed.");
//     }
//     return false;
//   }

//   /// Tracks technician's real-time location with device info
//   Future<bool> trackLocation({
//     required String technicianId,
//     required String date,
//     required String sessionDatetime,
//     required String locationName,
//     required String lat,
//     required String lng,
//   }) async {
//     final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
//     final body = {
//       'technician_id': technicianId,
//       'date': date,
//       'session_datetime': sessionDatetime,
//       'location': {'location_name': locationName, 'lat': lat, 'lng': lng},
//       ...deviceInfo,
//     };
//     try {
//       final res = await _apiClient.post(_trackLocation, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _trackLocation,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _trackLocation,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in trackLocation: $e');
//       _apiClient.showSnackbar("Error", "Failed to send location.");
//     }
//     return false;
//   }

//   /// Fetches technician's profile
//   Future<Map<String, dynamic>?> fetchProfile() async {
//     try {
//       final res = await _apiClient.post(_fetchProfile);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchProfile,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return json['data'];
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchProfile,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchProfile: $e');
//       _apiClient.showSnackbar("Error", "Failed to load profile.");
//     }
//     return null;
//   }

//   // ✅ NEW METHOD: Fetches technician's KYC details
//   Future<TechnicianKycModel?> fetchKycDetails() async {
//     try {
//       final res = await _apiClient.post(_fetchKyc);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchKyc,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           return TechnicianKycModel.fromJson(json['data']);
//         } else {
//           _apiClient.showSnackbar(
//             "Info",
//             json['message'] ?? "No KYC data found.",
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchKyc,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchKycDetails: $e');
//       _apiClient.showSnackbar("Error", "Failed to load KYC details.");
//     }
//     return null;
//   }

//   // ✅ NEW METHOD: Fetches unified Technician Profile (Profile + KYC)
//   Future<TechnicianProfileModel?> fetchUnifiedProfile() async {
//     try {
//       // Fetch profile data
//       final profileData = await fetchProfile();
//       if (profileData == null) {
//         return null; // fetchProfile handles unauthorized and shows snackbar
//       }
//       // Create base profile model
//       final baseProfile = TechnicianProfileModel.fromProfileData(profileData);
//       // Fetch KYC data
//       final kycData = await fetchKycDetails();
//       if (kycData == null) {
//         // KYC fetch might have shown its own error, or it might just be empty.
//         // Return profile without KYC.
//         return baseProfile;
//       }
//       // Merge and return
//       return baseProfile.mergeWithKyc(kycData);
//     } catch (e, s) {
//       _apiClient.logApiDebug(
//         endpoint: 'fetchUnifiedProfile',
//         method: 'COMBINED',
//         error: e,
//         stackTrace: s,
//       );
//       developer.log('Exception in fetchUnifiedProfile: $e');
//       _apiClient.showSnackbar("Error", "Failed to load full profile.");
//       return null;
//     }
//   }

//   // ✅ FIXED METHOD: Updates technician's profile information
//   Future<Map<String, dynamic>?> updateProfile(
//     Map<String, dynamic> requestBody,
//   ) async {
//     try {
//       // FIXED: Was calling _fetchKyc, now correctly calls _updateProfile
//       final res = await _apiClient.post(_updateProfile, body: requestBody);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _updateProfile,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(requestBody),
//           responseBody: res.body,
//         );
//       }

//       if (res.statusCode == 200) {
//         final responseBody = jsonDecode(res.body);
//         if (responseBody is Map<String, dynamic>) {
//           if (responseBody['status'] == 'success') {
//             _apiClient.showSnackbar(
//               "Success",
//               responseBody['message'] ?? "Profile updated successfully!",
//               isError: false,
//             );
//           }
//           return responseBody;
//         } else {
//           print("Invalid response format: ${res.body}");
//           _apiClient.showSnackbar(
//             "Error",
//             "Invalid response format from server.",
//           );
//           return null;
//         }
//       } else {
//         print(
//           "Failed to update profile. Status code: ${res.statusCode}, Body: ${res.body}",
//         );
//         _apiClient.handleHttpError(res.statusCode);
//         return null;
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         _apiClient.unauthorized();
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _updateProfile,
//         method: 'POST',
//         requestBody: jsonEncode(requestBody),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in updateProfile: $e');
//       _apiClient.showSnackbar("Error", "Failed to update profile.");
//       return null;
//     }
//   }

//   /// Searches customers by name or mobile number.
//   ///
//   /// [query]: The search term (name or mobile number).
//   Future<List<CustomerModel>?> searchCustomers(String query) async {
//     // Using positional parameter for simplicity}

//     try {
//       // --- KEY FIX: Use the correct parameter name expected by your API ---
//       final res = await _apiClient.post(
//         _fetchCustomerByMobOrName,
//         body: {
//           "customer_mobOrName": query,
//         }, // <--- CHANGED: Use 'customer_mobOrName'
//       );

//       // Log the request details for debugging
//       developer.log('Searching customers with query: $query');
//       developer.log(
//         'Request URL: ${res.request?.url.toString() ?? "N/A"}',
//       ); // Log full URL if possible

//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           // Assuming _apiClient or this class has logApiDebug
//           endpoint: _fetchCustomerByMobOrName,
//           method: 'POST',
//           requestBody:
//               '{"customer_mobOrName": $query}', // Log the correct param
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//         _apiClient.handleHttpError(res.statusCode); // Assuming this exists
//         return null; // Indicate network/HTTP error
//       }

//       if (res.statusCode == 200) {
//         final dynamic jsonBody = jsonDecode(res.body); // Parse as dynamic first

//         // Type check the parsed JSON
//         if (jsonBody is! Map<String, dynamic>) {
//           _apiClient.logApiDebug(
//             endpoint: _fetchCustomerByMobOrName,
//             method: 'POST',
//             requestBody: '{"customer_mobOrName": $query}',
//             statusCode: res.statusCode,
//             responseBody: res.body,
//             error: 'Response body is not a JSON object',
//           );
//           return null; // Unexpected response format
//         }

//         final Map<String, dynamic> json = jsonBody;

//         // Check for success status
//         if (json['status'] == 'success') {
//           // Confirm 'status' key
//           // Check for 'data' key and ensure it's a list
//           if (json.containsKey('data') && json['data'] is List) {
//             // Confirm 'data' key
//             final List data = json['data'];
//             // Safely map the list, checking item types
//             try {
//               return data
//                   .where(
//                     (item) => item is Map<String, dynamic>,
//                   ) // Ensure each item is a Map
//                   .map((e) => CustomerModel.fromJson(e as Map<String, dynamic>))
//                   .toList();
//             } catch (e) {
//               _apiClient.logApiDebug(
//                 endpoint: _fetchCustomerByMobOrName,
//                 method: 'POST',
//                 requestBody: '{"customer_mobOrName": $query}',
//                 statusCode: res.statusCode,
//                 responseBody: res.body,
//                 error: 'Error mapping CustomerModel: $e',
//               );
//               return null; // Error during mapping
//             }
//           } else {
//             // Log if 'data' key is missing or not a list
//             _apiClient.logApiDebug(
//               endpoint: _fetchCustomerByMobOrName,
//               method: 'POST',
//               requestBody: '{"customer_mobOrName": $query}',
//               statusCode: res.statusCode,
//               responseBody: res.body,
//               error:
//                   "Unexpected response format - 'data' key missing or not a list",
//             );
//             // Considered successful API call but no data found for the query
//             return []; // Return empty list for "no results"
//           }
//         } else {
//           // API responded with 200 but status is not 'success'
//           _apiClient.logApiDebug(
//             endpoint: _fetchCustomerByMobOrName,
//             method: 'GET',
//             requestBody: '{"customer_mobOrName": $query}',
//             statusCode: res.statusCode,
//             responseBody: res.body,
//             error: "API returned non-success status",
//           );
//           // Show message from API if available
//           String message =
//               json['message']?.toString() ??
//               "No customers found matching '$query'.";
//           _apiClient.showSnackbar("Info", message); // Assuming this exists
//           // Return empty list for "no results found" scenario when API call itself succeeded
//           return []; // Return empty list for "no results found" scenario when API call itself succeeded
//         }
//       }
//       return null; // Should generally not be reached
//     } on TimeoutException catch (e) {
//       // Add timeout handling if needed
//       _apiClient.logApiDebug(
//         endpoint: _fetchCustomerByMobOrName,
//         method: 'GET',
//         requestBody: '{"customer_mobOrName": $query}',
//         error: 'Timeout: $e',
//         stackTrace: StackTrace.current,
//       );
//       _apiClient.showSnackbar("Error", "Request timed out. Please try again.");
//       return null;
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         developer.log('Search failed due to unauthorized access.');
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchCustomerByMobOrName,
//         method: 'GET',
//         requestBody: '{"customer_mobOrName": $query}',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in searchCustomers: $e');
//       _apiClient.showSnackbar(
//         "Error",
//         "Failed to search customers. Check connection.",
//       );
//     }
//     return null; // Return null on any unhandled error caught by catch block
//   }

//   // ————————————————————————
//   // 📦 NEW EXPENSE APIs
//   // ————————————————————————

//   /// Adds a new expense entry for the technician.
//   ///
//   /// Requires: expense_title, amount, expense_date, image, payment_mode, status, expense_category.
//   /// Optional: description, remark.
//   Future<Map<String, dynamic>?> addExpense({
//     required String expenseTitle,
//     required double amount,
//     required String expenseDate, // Format: YYYY-MM-DD
//     required String image, // Path or base64 string
//     required String paymentMode, // e.g., 'cash', 'card', 'upi'
//     // required String status, // e.g., 'pending', 'approved', 'rejected'
//     required String expenseCategory, // e.g., 'Travel', 'Food', 'Accommodation'
//     String? description,
//     String? remark,
//   }) async {
//     final body = {
//       'expense_title': expenseTitle,
//       'amount': amount,
//       'expense_date': expenseDate,
//       'image': image,
//       'payment_mode': paymentMode,
//       'status': 'Pending',
//       'expense_category': expenseCategory,
//       if (description != null) 'description': description,
//       if (remark != null) 'remark': remark,
//     };

//     try {
//       final res = await _apiClient.post(_addExpense, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _addExpense,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Expense added successfully!",
//             isError: false,
//           );
//           return json; // Returns the full response, including expense_id
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//           _apiClient.logApiDebug(
//             endpoint: _addExpense,
//             method: 'POST',
//             requestBody: jsonEncode(body),
//             error: json['message'],
//             stackTrace: StackTrace.current,
//           );
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         _apiClient.unauthorized();
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _addExpense,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in addExpense: $e');
//       _apiClient.showSnackbar("Error", "Failed to add expense.");
//     }
//     return null;
//   }

//   /// Fetches a list of expenses for the technician.
//   Future<List<Map<String, dynamic>>?> fetchExpenses() async {
//     try {
//       final res = await _apiClient.post(
//         _fetchExpenses,
//       ); // Assuming POST, adjust if GET
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchExpenses,
//           method: 'POST', // Adjust method if needed
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List data = json['data'];
//           // Return as List<Map<String, dynamic>>, you might want to create an ExpenseListModel
//           return data.cast<Map<String, dynamic>>();
//         } else {
//           _apiClient.showSnackbar(
//             "Info",
//             json['message'] ?? "No expenses found.",
//           );
//           return []; // Return empty list if no data but status is success
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchExpenses,
//         method: 'POST', // Adjust method if needed
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchExpenses: $e');
//       _apiClient.showSnackbar("Error", "Failed to load expenses.");
//     }
//     return null;
//   }

//   /// Fetches detailed information for a specific expense.
//   Future<Map<String, dynamic>?> fetchExpenseDetails(int expenseId) async {
//     final body = {'id': expenseId};

//     try {
//       final res = await _apiClient.post(_fetchExpenseDetails, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchExpenseDetails,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }

//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           // Return the detailed data object
//           return json['data'];
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchExpenseDetails,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchExpenseDetails: $e');
//       _apiClient.showSnackbar("Error", "Failed to load expense details.");
//     }
//     return null;
//   }

//   // ————————————————————————
//   // 📅 NEW ATTENDANCE APIs (from provided list)
//   // ————————————————————————

//   /// Punches in the technician.
//   Future<bool> punchIn(
//     String technicianId,
//     String locationName,
//     String lat,
//     String lng,
//   ) async {
//     final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
//     final body = {
//       'technician_id': technicianId,
//       'location': {'location_name': locationName, 'lat': lat, 'lng': lng},
//       ...deviceInfo,
//     };
//     try {
//       final res = await _apiClient.post(_punchIn, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _punchIn,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Punched in successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _punchIn,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in punchIn: $e');
//       _apiClient.showSnackbar("Error", "Failed to punch in.");
//     }
//     return false;
//   }

//   /// Punches out the technician.
//   Future<bool> punchOut(
//     String technicianId,
//     String locationName,
//     String lat,
//     String lng,
//   ) async {
//     final deviceInfo = await DeviceInfoUtils.getAllDeviceInfo();
//     final body = {
//       'technician_id': technicianId,
//       'location': {'location_name': locationName, 'lat': lat, 'lng': lng},
//       ...deviceInfo,
//     };
//     try {
//       final res = await _apiClient.post(_punchOut, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _punchOut,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Punched out successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _punchOut,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in punchOut: $e');
//       _apiClient.showSnackbar("Error", "Failed to punch out.");
//     }
//     return false;
//   }

//   /// Fetches attendance records for the technician.
//   Future<List<Map<String, dynamic>>?> fetchAttendance() async {
//     try {
//       final res = await _apiClient.post(_fetchAttendance);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchAttendance,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List data = json['data'];
//           return data.cast<Map<String, dynamic>>();
//         } else {
//           _apiClient.showSnackbar(
//             "Info",
//             json['message'] ?? "No attendance records found.",
//           );
//           return [];
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchAttendance,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchAttendance: $e');
//       _apiClient.showSnackbar("Error", "Failed to load attendance.");
//     }
//     return null;
//   }

//   /// Fetches today's attendance record for the technician.
//   Future<Map<String, dynamic>?> fetchTodayAttendance() async {
//     try {
//       final res = await _apiClient.post(_fetchTodayAttendance);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchTodayAttendance,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           // 'data' might be null if not punched in yet
//           return json['data']; // Returns the attendance object or null
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchTodayAttendance,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchTodayAttendance: $e');
//       _apiClient.showSnackbar("Error", "Failed to load today's attendance.");
//     }
//     return null;
//   }

//   /// Fetches the attendance dashboard summary for the technician.
//   Future<Map<String, dynamic>?> fetchAttendanceDashboard() async {
//     try {
//       final res = await _apiClient.post(_attendanceDashboard);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _attendanceDashboard,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return json['data']; // Assumes data contains dashboard summary
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _attendanceDashboard,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchAttendanceDashboard: $e');
//       _apiClient.showSnackbar("Error", "Failed to load attendance dashboard.");
//     }
//     return null;
//   }

//   // ————————————————————————
//   // 📅 NEW LEAVE APIs (from provided list)
//   // ————————————————————————

//   /// Applies for a new leave.
//   Future<bool> applyForLeave({
//     required String startDate,
//     required String endDate,
//     required String leaveType, // e.g., 'annual', 'sick', 'casual'
//     required String reason,
//     String? attachments, // Optional base64 or path
//   }) async {
//     final body = {
//       'start_date': startDate, // Format: YYYY-MM-DD
//       'end_date': endDate,
//       'leave_type': leaveType,
//       'reason': reason,
//       if (attachments != null) 'attachments': attachments,
//     };

//     try {
//       final res = await _apiClient.post(_applyLeave, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _applyLeave,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Leave applied successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _applyLeave,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in applyForLeave: $e');
//       _apiClient.showSnackbar("Error", "Failed to apply for leave.");
//     }
//     return false;
//   }

//   /// Fetches leave history for the technician.
//   Future<List<Map<String, dynamic>>?> fetchLeaves() async {
//     try {
//       final res = await _apiClient.post(_fetchLeaves);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchLeaves,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List data = json['data'];
//           return data.cast<Map<String, dynamic>>();
//         } else {
//           _apiClient.showSnackbar(
//             "Info",
//             json['message'] ?? "No leave records found.",
//           );
//           return [];
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchLeaves,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchLeaves: $e');
//       _apiClient.showSnackbar("Error", "Failed to load leaves.");
//     }
//     return null;
//   }

//   /// Cancels a pending leave application.
//   Future<bool> cancelLeave(int leaveId) async {
//     final body = {'leave_id': leaveId};

//     try {
//       final res = await _apiClient.post(_cancelLeave, body: body);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _cancelLeave,
//           method: 'POST',
//           statusCode: res.statusCode,
//           requestBody: jsonEncode(body),
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body);
//         if (json['status'] == 'success') {
//           _apiClient.showSnackbar(
//             "Success",
//             json['message'] ?? "Leave cancelled successfully!",
//             isError: false,
//           );
//           return true;
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return false;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _cancelLeave,
//         method: 'POST',
//         requestBody: jsonEncode(body),
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in cancelLeave: $e');
//       _apiClient.showSnackbar("Error", "Failed to cancel leave.");
//     }
//     return false;
//   }

//   // ————————————————————————
//   // ⭐ OTHER NEW APIs (from provided list)
//   // ————————————————————————

//   /// Fetches the technician's rating.
//   Future<Map<String, dynamic>?> fetchMyRating() async {
//     try {
//       final res = await _apiClient.post(_fetchMyRating);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchMyRating,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return json['data']; // Assumes data contains rating info
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchMyRating,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchMyRating: $e');
//       _apiClient.showSnackbar("Error", "Failed to load rating.");
//     }
//     return null;
//   }

//   /// Fetches the technician's referral information.
//   Future<Map<String, dynamic>?> fetchMyReferral() async {
//     try {
//       final res = await _apiClient.post(_fetchMyReferral);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchMyReferral,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return json['data']; // Assumes data contains referral info
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchMyReferral,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchMyReferral: $e');
//       _apiClient.showSnackbar("Error", "Failed to load referral info.");
//     }
//     return null;
//   }

//   /// Fetches the technician's work area information.
//   Future<Map<String, dynamic>?> fetchWorkArea() async {
//     try {
//       final res = await _apiClient.post(_fetchWorkArea);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _fetchWorkArea,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success') {
//           return json['data']; // Assumes data contains work area info
//         } else {
//           _apiClient.showSnackbar("Error", json['message']);
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _fetchWorkArea,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in fetchWorkArea: $e');
//       _apiClient.showSnackbar("Error", "Failed to load work area.");
//     }
//     return null;
//   }

//   /// Fetches the technician's login history.
//   Future<List<Map<String, dynamic>>?> getLoginHistory() async {
//     try {
//       final res = await _apiClient.post(_getLoginHistory);
//       if (res.statusCode != 200) {
//         _apiClient.logApiDebug(
//           endpoint: _getLoginHistory,
//           method: 'POST',
//           statusCode: res.statusCode,
//           responseBody: res.body,
//         );
//       }
//       if (res.statusCode == 200) {
//         final json = jsonDecode(res.body) as Map<String, dynamic>;
//         if (json['status'] == 'success' && json.containsKey('data')) {
//           final List data = json['data'];
//           return data.cast<Map<String, dynamic>>();
//         } else {
//           _apiClient.showSnackbar(
//             "Info",
//             json['message'] ?? "No login history found.",
//           );
//           return [];
//         }
//       } else {
//         _apiClient.handleHttpError(res.statusCode);
//       }
//     } catch (e) {
//       if (e.toString().contains('Unauthorized: No token')) {
//         return null;
//       }
//       _apiClient.logApiDebug(
//         endpoint: _getLoginHistory,
//         method: 'POST',
//         error: e,
//         stackTrace: StackTrace.current,
//       );
//       developer.log('Exception in getLoginHistory: $e');
//       _apiClient.showSnackbar("Error", "Failed to load login history.");
//     }
//     return null;
//   }
// }


// /// middleware

// // asia_fibernet_fixes/middleware/auth_middleware.dart
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';

// import '../sharedpref.dart';

// class AuthMiddleware extends GetMiddleware {
//   @override
//   int get priority => 1;

//   @override
//   RouteSettings? redirect(String? route) {
//     final isLoggedIn = AppSharedPref.instance.isUserLoggedIn();
//     final isAuthRoute = route == '/login' || route == '/otp';

//     if (isLoggedIn ) {
//       return RouteSettings(name: '/home');
//     }
//     if (!isLoggedIn && !isAuthRoute) {
//       return RouteSettings(name: '/login');
//     }
//     return null;
//   }
// }


// /// extensions

// extension DateTimeExtensions on DateTime {
//   DateTime get startOfDay => DateTime(year, month, day);
//   DateTime get endOfDay => DateTime(year, month, day, 23, 59, 59, 999, 999);
// }


// import 'package:flutter/widgets.dart';

// extension EmptySpace on num {
//   /// Give the Gap/Space by using [10.height]
//   SizedBox get height => SizedBox(height: toDouble());

//   /// Give the Gap/Space by using [10.width]
//   SizedBox get width => SizedBox(width: toDouble());
// }


// import 'package:flutter/widgets.dart';

// extension TextString on String {
//   Text get text => Text(this);

//   Text get isBold {
//     return Text(
//       this,
//       style: const TextStyle().copyWith(fontWeight: FontWeight.bold),
//     );
//   }

//   // Text color(Color? color) {
//   //   return Text(this,
//   //       style: const TextStyle().copyWith(color: color ?? MyTheme.textColor));
//   // }
// }

// extension BoldText on Text {
//   TextStyle get isBold {
//     return const TextStyle().copyWith(fontWeight: FontWeight.bold);
//   }
// }

// // external MakeText1 on Widget{
// //      TextStyle get make Text(this,
// //         style: const TextStyle().copyWith(fontWeight: FontWeight.bold))
// //   }

// // lib/src/core/utils/device_info_utils.dart

// import 'dart:developer' as developer;
// import 'dart:io';
// import 'package:get_ip_address/get_ip_address.dart';
// import 'package:network_info_plus/network_info_plus.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:geocoding/geocoding.dart';
// import 'package:timezone/timezone.dart' as tz;
// import 'package:device_info_plus/device_info_plus.dart'; // ✅ Import for device info

// /// A utility class to gather device information like IP, location, Wi-Fi details.
// class DeviceInfoUtils {
//   static final NetworkInfo _networkInfo = NetworkInfo();
//   static final DeviceInfoPlugin _deviceInfoPlugin =
//       DeviceInfoPlugin(); // ✅ Device Info Plugin Instance

//   /// Gets the public IP address, falling back to the local Wi-Fi IP.
//   static Future<String> getIpAddress() async {
//     try {
//       final String? publicIp = await IpAddress().getIpAddress();
//       if (publicIp != null && publicIp.isNotEmpty) {
//         return publicIp;
//       }
//       // Fallback to local Wi-Fi IP
//       final String? localIp = await _networkInfo.getWifiIP();
//       return localIp ?? "0.0.0.0";
//     } catch (e) {
//       developer.log('Error getting public IP, trying local IP: $e');
//       try {
//         final String? localIp = await _networkInfo.getWifiIP();
//         return localIp ?? "0.0.0.0";
//       } catch (e2) {
//         developer.log('Error getting local IP: $e2');
//         return "0.0.0.0";
//       }
//     }
//   }

//   /// Gets the current time zone name (e.g., "Asia/Kolkata").
//   static String getTimeZone() {
//     try {
//       // This call might fail with LateInitializationError if data isn't ready
//       return tz.local.name;
//     } catch (e) {
//       // Handle LateInitializationError specifically or generally
//       developer.log(
//         'Error getting time zone (might be uninitialized data): $e',
//       );
//       // Fallback to UTC if there's any issue getting the local timezone
//       return "UTC";
//     }
//   }

//   /// Attempts to get the current geographical position.
//   static Future<Position?> getLocation() async {
//     bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//     if (!serviceEnabled) {
//       developer.log('Location services are disabled.');
//       return null;
//     }
//     LocationPermission permission = await Geolocator.checkPermission();
//     if (permission == LocationPermission.denied) {
//       permission = await Geolocator.requestPermission();
//       if (permission == LocationPermission.denied) {
//         developer.log('Location permissions are denied.');
//         // Don't show snackbar here, let the calling code decide
//         return null;
//       }
//     }
//     if (permission == LocationPermission.deniedForever) {
//       developer.log('Location permissions are permanently denied.');
//       // Don't show snackbar here, let the calling code decide
//       return null;
//     }
//     try {
//       return await Geolocator.getCurrentPosition(
//         desiredAccuracy:
//             LocationAccuracy
//                 .medium, // Consider if high accuracy is always needed
//       );
//     } catch (e) {
//       developer.log('Error getting location: $e');
//       return null;
//     }
//   }

//   /// Gets the city name based on the current location.
//   static Future<String> getCityName() async {
//     final position = await getLocation();
//     if (position == null) return "Unknown";
//     try {
//       final List<Placemark> placemarks = await placemarkFromCoordinates(
//         position.latitude,
//         position.longitude,
//       );
//       if (placemarks.isNotEmpty) {
//         final Placemark place = placemarks.first;
//         // Prioritize locality, fallback to subAdministrativeArea
//         return place.locality?.isNotEmpty == true
//             ? place.locality!
//             : (place.subAdministrativeArea?.isNotEmpty == true
//                 ? place.subAdministrativeArea!
//                 : "Unknown");
//       }
//     } catch (e) {
//       developer.log('Error getting city name: $e');
//     }
//     return "Unknown";
//   }

//   /// Gets the postal code based on the current location.
//   static Future<String> getPostalCode() async {
//     final position = await getLocation();
//     if (position == null) return "Unknown";
//     try {
//       final List<Placemark> placemarks = await placemarkFromCoordinates(
//         position.latitude,
//         position.longitude,
//       );
//       if (placemarks.isNotEmpty) {
//         final Placemark place = placemarks.first;
//         return place.postalCode ?? "Unknown";
//       }
//     } catch (e) {
//       developer.log('Error getting postal code: $e');
//     }
//     return "Unknown";
//   }

//   /// Gets various Wi-Fi related information.
//   static Future<Map<String, String>> getWifiInfo() async {
//     try {
//       // Attempt to get Wi-Fi details. These might be null if not connected to Wi-Fi.
//       final ssid = await _networkInfo.getWifiName();
//       final bssid = await _networkInfo.getWifiBSSID();
//       final ip = await _networkInfo.getWifiIP();
//       final ipv6 =
//           await _networkInfo
//               .getWifiIPv6(); // Might often be null or unsupported

//       final subnet = "255.255.255.0"; // Common default, might not be accurate
//       final broadcast =
//           ip != null ? _calculateBroadcast(ip, subnet) : "Unknown";
//       // Common default gateway assumption (first host of subnet)
//       final gateway =
//           ip != null ? "${ip.split('.').take(3).join('.')}.1" : "Unknown";

//       return {
//         'ssid': ssid ?? "Unknown",
//         'bssid': bssid ?? "Unknown",
//         'ip': ip ?? "Unknown",
//         'ipv6': ipv6 ?? "Unknown",
//         'subnet': subnet,
//         'broadcast': broadcast,
//         'gateway': gateway,
//       };
//     } catch (e) {
//       developer.log('Error getting Wi-Fi info: $e');
//       // Return 'Unknown' for all fields on error
//       return {
//         'ssid': 'Unknown',
//         'bssid': 'Unknown',
//         'ip': 'Unknown',
//         'ipv6': 'Unknown',
//         'subnet': 'Unknown',
//         'broadcast': 'Unknown',
//         'gateway': 'Unknown',
//       };
//     }
//   }

//   /// Helper method to calculate the broadcast IP from IP and subnet mask.
//   static String _calculateBroadcast(String ip, String subnet) {
//     try {
//       final ipParts = ip.split('.').map(int.parse).toList();
//       final subnetParts = subnet.split('.').map(int.parse).toList();
//       final broadcastParts = <int>[];
//       for (int i = 0; i < 4; i++) {
//         // Bitwise OR: Network part (AND) + Host part (NOT subnet)
//         broadcastParts.add(
//           (ipParts[i] & subnetParts[i]) | (~subnetParts[i] & 255),
//         );
//       }
//       return broadcastParts.join('.');
//     } catch (e) {
//       developer.log('Error calculating broadcast address: $e');
//       return "Unknown";
//     }
//   }

//   /// Gets dynamic device information (model, brand, OS version, etc.).
//   static Future<Map<String, String>> getDeviceInfo() async {
//     try {
//       if (Platform.isAndroid) {
//         final androidInfo = await _deviceInfoPlugin.androidInfo;
//         return {
//           'device': 'Android',
//           'model': androidInfo.model,
//           'brand': androidInfo.brand,
//           'manufacturer': androidInfo.manufacturer,
//           'version_release': androidInfo.version.release,
//           'version_sdk': androidInfo.version.sdkInt.toString(),
//           'id': androidInfo.id, // Build ID
//           'hardware': androidInfo.hardware,
//         };
//       } else if (Platform.isIOS) {
//         final iosInfo = await _deviceInfoPlugin.iosInfo;
//         return {
//           'device': 'iOS',
//           'model': iosInfo.model,
//           'name': iosInfo.name, // e.g., "My iPhone"
//           'system_name': iosInfo.systemName, // e.g., "iOS"
//           'system_version': iosInfo.systemVersion,
//           'localized_model': iosInfo.localizedModel,
//           'identifier_for_vendor': iosInfo.identifierForVendor ?? "Unknown",
//         };
//       } else {
//         // Fallback for other platforms (Web, Desktop - limited info)
//         return {'device': 'Other', 'model': 'Unknown', 'brand': 'Unknown'};
//       }
//     } catch (e) {
//       developer.log('Error getting device info: $e');
//       // Provide minimal fallback info on error
//       return {'device': 'Unknown', 'model': 'Unknown', 'brand': 'Unknown'};
//     }
//   }

//   /// Gathers all available device information into a single map.
//   /// This mimics the structure often used in API request bodies.
//   /// Includes dynamic device details.
//   static Future<Map<String, dynamic>> getAllDeviceInfo() async {
//     // Run independent futures concurrently for better performance
//     final ipAddressFuture = getIpAddress();
//     final timeZoneFuture = Future.value(
//       getTimeZone(),
//     ); // Already sync, wrap for consistency
//     final locationFuture = getLocation();
//     final wifiInfoFuture = getWifiInfo();
//     final deviceInfoFuture = getDeviceInfo(); // ✅ Get device info

//     // Wait for all futures to complete
//     final results = await Future.wait([
//       ipAddressFuture,
//       timeZoneFuture,
//       locationFuture,
//       wifiInfoFuture,
//       deviceInfoFuture,
//       getCityName(), // Depends on location
//       getPostalCode(), // Depends on location
//     ], eagerError: false); // Don't stop on first error

//     final String ipAddress = results[0] as String;
//     final String timeZone = results[1] as String;
//     final Position? location = results[2] as Position?;
//     final Map<String, String> wifiInfo = results[3] as Map<String, String>;
//     final Map<String, String> deviceInfo =
//         results[4] as Map<String, String>; // ✅ Get result
//     final String cityName = results[5] as String;
//     final String postalCode = results[6] as String;

//     final double latitude = location?.latitude ?? 0.0;
//     final double longitude = location?.longitude ?? 0.0;

//     // Merge all maps into the final request data map
//     return {
//       'ip_address': ipAddress,
//       'time_zone': timeZone,
//       'latitude': latitude,
//       'longitude': longitude,
//       'city_name': cityName,
//       'postal_code': postalCode,
//       ...wifiInfo, // Spread Wi-Fi info
//       ...deviceInfo, // ✅ Spread dynamic device info
//     };
//   }
// }


// import '../auth/ui/login_screen.dart';
// import '../auth/ui/scaffold_screen.dart';
// import 'package:flutter/widgets.dart';

// import '../auth/ui/otp_screen.dart';

// class AppRoutes {
//   // Define route names as constants
//   static const String login = "/";
//   static const String otp = "/OTPScreen";
//   static const String home = "/HomeScreen";
//   static const String complaints = "/ComplaintsScreen";

//   // Define routes map
//   static Map<String, Widget Function(BuildContext)> routes = {
//     login: (BuildContext context) => LoginScreen(),
//     otp: (BuildContext context) => OTPScreen(),
//     home: (BuildContext context) => ScaffoldScreen(),
//     // complaints: (BuildContext context) => ComplaintsScreen(),
//   };
// }


// import 'package:shared_preferences/shared_preferences.dart';
// import 'dart:developer' as developer;

// /// A utility class for managing app-level persistent data using [SharedPreferences].
// ///
// /// This class provides a centralized, singleton-based interface for storing and retrieving
// /// sensitive and non-sensitive user data such as authentication tokens, user IDs,
// /// mobile numbers, and feature flags like location tracking status.
// ///
// /// It must be initialized before use via [init()] typically during app startup.
// ///
// /// Example:
// /// ```dart
// /// await AppSharedPref.init();
// /// await AppSharedPref.setToken("your_jwt_token");
// /// String? token = await AppSharedPref.getToken();
// /// ```
// class AppSharedPref {
//   // 🔑 Keys for SharedPreferences
//   static const String _tokenKey = 'auth_token';
//   static const String _roleKey = 'user_role';
//   static const String _userIDKey = 'user_id';
//   static const String _mobileNumberKey = 'mobile_number';
//   static const String _trackingStatusKey = 'is_tracking_enabled';
//   static const String _isVerifyCustomer = 'is_verify_customer';

//   // 🧩 Singleton instance
//   static AppSharedPref? _instance;
//   static SharedPreferences? _prefs;

//   // 🛠 Prevent external instantiation
//   AppSharedPref._();

//   /// Returns the singleton instance of [AppSharedPref].
//   ///
//   /// Throws an error if [init] has not been called first.
//   static AppSharedPref get instance {
//     if (_instance == null) {
//       throw StateError(
//         "AppSharedPref is not initialized. Call AppSharedPref.init() first.",
//       );
//     }
//     return _instance!;
//   }

//   /// Initializes the [AppSharedPref] class.
//   ///
//   /// This method must be called once before any other method is used.
//   /// Typically called during app startup (e.g., in `main()` or app initialization routine).
//   ///
//   /// Example:
//   /// ```dart
//   /// void main() async {
//   ///   WidgetsFlutterBinding.ensureInitialized();
//   ///   await AppSharedPref.init();
//   ///   runApp(MyApp());
//   /// }
//   /// ```
//   static Future<void> init() async {
//     if (_instance != null) {
//       developer.log(
//         "AppSharedPref already initialized. Skipping re-initialization.",
//       );
//       return;
//     }

//     try {
//       _prefs = await SharedPreferences.getInstance();
//       _instance = AppSharedPref._();
//       developer.log("AppSharedPref initialized successfully.");
//     } on Exception catch (e) {
//       developer.log("Failed to initialize AppSharedPref: $e");
//       throw Exception("Unable to initialize shared preferences: $e");
//     }
//   }

//   /// Checks if the user is logged in by verifying the presence of both token and user ID.
//   ///
//   /// Returns `true` if both authentication token and user ID exist.
//   /// This is a safe way to check login state during app startup or route guarding.
//   ///
//   /// Example:
//   /// ```dart
//   /// if (await AppSharedPref.instance.isUserLoggedIn()) {
//   ///   // Go to home screen
//   /// } else {
//   ///   // Redirect to login
//   /// }
//   /// ```
//   /// ✅ Synchronous check for login state (safe to use in middleware)
//   bool isUserLoggedIn() {
//     _validatePrefs();
//     final String? token = _prefs!.getString(_tokenKey);
//     final int? userId = _prefs!.getInt(_userIDKey);
//     final bool isLoggedIn = token != null && userId != null; // && userId > 0;

//     developer.log(
//       "Login status check: token=${token != null}, userId=$userId → isLoggedIn=$isLoggedIn",
//       name: "AppSharedPref.isUserLoggedIn",
//     );

//     return isLoggedIn;
//   }

//   /// Saves the authentication token.
//   ///
//   /// Returns `true` if the operation succeeded.
//   Future<bool> setToken(String token) {
//     _validatePrefs();
//     if (token.isEmpty) {
//       developer.log(
//         "Attempted to save empty token.",
//         name: "AppSharedPref.setToken",
//       );
//       return Future.value(false);
//     }
//     developer.log("Token saved.", name: "AppSharedPref.setToken");
//     return _prefs!.setString(_tokenKey, token);
//   }

//   /// Retrieves the stored authentication token.
//   ///
//   /// Returns `null` if no token is found or if it has expired.
//   Future<String?> getToken() {
//     _validatePrefs();
//     final String? token = _prefs!.getString(_tokenKey);
//     if (token == null) {
//       developer.log("No token found.", name: "AppSharedPref.getToken");
//     }
//     return Future.value(token);
//   }

//   /// Removes the authentication token from storage.
//   ///
//   /// Useful during logout.
//   Future<bool> removeToken() {
//     _validatePrefs();
//     developer.log("Token removed.", name: "AppSharedPref.removeToken");
//     return _prefs!.remove(_tokenKey);
//   }

//   /// Saves the Role.
//   ///
//   /// Returns `true` if the operation succeeded.
//   Future<bool> setRole(String role) {
//     _validatePrefs();
//     if (role.isEmpty) {
//       developer.log(
//         "Attempted to save empty Role.",
//         name: "AppSharedPref.setRole",
//       );
//       return Future.value(false);
//     }
//     developer.log("Role saved.", name: "AppSharedPref.setRole");
//     return _prefs!.setString(_roleKey, role);
//   }

//   /// Retrieves the stored Role.
//   ///
//   /// Returns `null` if no Role is found.
//   String? getRole() {
//     _validatePrefs();
//     final String? role = _prefs!.getString(_roleKey);
//     if (role == null) {
//       developer.log("No role found.", name: "AppSharedPref.getRole");
//     }
//     return role;
//   }

//   /// Removes the role from storage.
//   ///
//   /// Useful during logout.
//   Future<bool> removeRole() {
//     _validatePrefs();
//     developer.log("Role removed.", name: "AppSharedPref.removeRole");
//     return _prefs!.remove(_roleKey);
//   }

//   /// Saves the user ID.
//   ///
//   /// Returns `true` on success.
//   Future<bool> setUserID(int userID) {
//     _validatePrefs();
//     if (userID <= 0) {
//       developer.log(
//         "Invalid userID attempted to save: $userID",
//         name: "AppSharedPref.setUserID",
//       );
//       return Future.value(false);
//     }
//     developer.log("User ID saved: $userID", name: "AppSharedPref.setUserID");
//     return _prefs!.setInt(_userIDKey, userID);
//   }

//   /// Retrieves the stored user ID.
//   ///
//   /// Returns `null` if no user ID is found.
//   int? getUserID() {
//     _validatePrefs();
//     final int? id = _prefs!.getInt(_userIDKey);
//     if (id == null) {
//       developer.log("No user ID found.", name: "AppSharedPref.getUserID");
//     }
//     return id;
//   }

//   /// Removes the stored user ID.
//   Future<bool> removeUserID() {
//     _validatePrefs();
//     developer.log("User ID removed.", name: "AppSharedPref.removeUserID");
//     return _prefs!.remove(_userIDKey);
//   }

//   /// Saves the user's mobile number.
//   ///
//   /// Returns `true` on success.
//   Future<bool> setMobileNumber(String mobileNumber) {
//     _validatePrefs();
//     // final RegExp phoneRegex = RegExp(r'^[6-9]\d{9}$'); // Indian mobile format
//     // if (!phoneRegex.hasMatch(mobileNumber)) {
//     //   developer.log(
//     //     "Invalid mobile number format: $mobileNumber",
//     //     name: "AppSharedPref.setMobileNumber",
//     //   );
//     //   return Future.value(false);
//     // }
//     developer.log(
//       "Mobile number saved.",
//       name: "AppSharedPref.setMobileNumber",
//     );
//     return _prefs!.setString(_mobileNumberKey, mobileNumber);
//   }

//   /// Retrieves the stored mobile number.
//   ///
//   /// Returns `null` if not found.
//   String? getMobileNumber() {
//     _validatePrefs();
//     final String? number = _prefs!.getString(_mobileNumberKey);
//     if (number == null) {
//       developer.log(
//         "No mobile number found.",
//         name: "AppSharedPref.getMobileNumber",
//       );
//     }
//     return number;
//   }

//   /// Removes the stored mobile number.
//   Future<bool> removeMobileNumber() {
//     _validatePrefs();
//     developer.log(
//       "Mobile number removed.",
//       name: "AppSharedPref.removeMobileNumber",
//     );
//     return _prefs!.remove(_mobileNumberKey);
//   }

//   /// Sets the verification status feature.
//   ///
//   /// Used to remember whether the Customer has verification (uploaded has Identity).
//   Future<bool> setVerificationStatus(bool isVerifyCustomer) async {
//     _validatePrefs();
//     developer.log(
//       "Customer's verification status set to: $isVerifyCustomer",
//       name: "AppSharedPref.setVerificationStatus",
//     );
//     return await _prefs!.setBool(_isVerifyCustomer, isVerifyCustomer);
//   }

//   /// Gets the current verification status.
//   ///
//   /// Returns `false` by default if no value was previously set.
//   bool getVerificationStatus() {
//     _validatePrefs();
//     final bool status = _prefs!.getBool(_isVerifyCustomer) ?? false;
//     developer.log(
//       "Current Customer Verification status: $status",
//       name: "AppSharedPref.getVerificationStatus",
//     );
//     return status;
//   }

//   /// Sets the tracking status for location tracking feature.
//   ///
//   /// Used to remember whether the technician has enabled background location tracking.
//   Future<bool> setTrackingStatus(bool isTracking) async {
//     _validatePrefs();
//     developer.log(
//       "Tracking status set to: $isTracking",
//       name: "AppSharedPref.setTrackingStatus",
//     );
//     return await _prefs!.setBool(_trackingStatusKey, isTracking);
//   }

//   /// Gets the current tracking status.
//   ///
//   /// Returns `false` by default if no value was previously set.
//   Future<bool> getTrackingStatus() async {
//     _validatePrefs();
//     final bool status = _prefs!.getBool(_trackingStatusKey) ?? false;
//     developer.log(
//       "Current tracking status: $status",
//       name: "AppSharedPref.getTrackingStatus",
//     );
//     return status;
//   }

//   /// Clears all stored data (e.g., during logout).
//   ///
//   /// Use with caution — removes all keys set by this class.
//   Future<bool> clearAllUserData() async {
//     _validatePrefs();
//     developer.log(
//       "Clearing all user data...",
//       name: "AppSharedPref.clearAllUserData",
//     );
//     try {
//       // Optionally, preserve some app settings here if needed
//       await _prefs!.remove(_tokenKey);
//       await _prefs!.remove(_userIDKey);
//       await _prefs!.remove(_mobileNumberKey);
//       await _prefs!.remove(_trackingStatusKey);
//       await _prefs!.remove(_isVerifyCustomer);
//       developer.log(
//         "User data cleared successfully.",
//         name: "AppSharedPref.clearAllUserData",
//       );
//       return true;
//     } catch (e) {
//       developer.log(
//         "Error clearing user data: $e",
//         name: "AppSharedPref.clearAllUserData",
//       );
//       return false;
//     }
//   }

//   /// Ensures that [_prefs] is available before any operation.
//   ///
//   /// Throws an error if [init] was not called.
//   void _validatePrefs() {
//     if (_prefs == null) {
//       throw Exception(
//         "AppSharedPref not initialized. Call AppSharedPref.init() before using it.",
//       );
//     }
//   }
// }
