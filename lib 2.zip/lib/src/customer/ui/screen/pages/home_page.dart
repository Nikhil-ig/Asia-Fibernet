// lib/src/ui/screen/home_screen.dart
import 'dart:async';
import 'package:asia_fibernet/src/auth/ui/scaffold_screen.dart';
import 'package:asia_fibernet/src/customer/ui/screen/profile_screen.dart';
import 'package:asia_fibernet/src/services/routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart'; // Added ScreenUtil import
// Import your models and services
import '../../../../auth/core/model/customer_details_model.dart';
import '../../../../services/apis/api_services.dart';
import '../../../../services/sharedpref.dart';
// Import your theme
import '../../../../theme/colors.dart';
import '../../../../theme/theme.dart';
// Import other screens
import '../../../core/models/plan_request_status_model.dart';
import '../bsnl_screen.dart';

class HomeController extends GetxController {
  final ApiServices apiServices = ApiServices();
  final customer = Rx<CustomerDetails?>(null);
  final currentPlanName = ''.obs;
  final currentSpeed = ''.obs;
  final currentPrice = ''.obs;
  final usageText = ''.obs;
  final usageProgress = 0.0.obs;
  final isLoading = true.obs;
  // ✅ NEW: Add plan request status
  final planRequestStatus = Rx<PlanRequestStatusModel?>(null);
  final isFetchingPlanStatus = false.obs;
  Timer? _refreshTimer;

  @override
  void onInit() {
    super.onInit();
    ScaffoldController().fetchCustomerData();
    fetchCustomerData();
    fetchRelocationStatus();
  }

  @override
  void onClose() {
    _refreshTimer?.cancel();
    super.onClose();
  }

  final Rx<Map<String, dynamic>?> relocationStatus =
      ProfileController().relocationStatus;

  Future<void> fetchCustomerData() async {
    try {
      final int? userId = AppSharedPref.instance.getUserID();
      if (userId == null) {
        // Get.snackbar("Error", "User not logged in");
        return;
      }
      final result = await apiServices.fetchCustomer();
      if (result != null) {
        customer.value = result;
        // ✅ Use real customer name from API
        currentPlanName.value = "Hello, ${result.contactName}";
        // ⚠️ TODO: Replace these with real plan data from backend when available
        // (e.g., map from result.Subscription_Plan, result.Plan_Period, etc.)
        currentSpeed.value = "100 Mbps";
        currentPrice.value = "₹899/month";
        usageProgress.value = 0.65;
        usageText.value = "65% used";
        // ✅ Fetch Plan Request Status
        await fetchPlanRequestStatus(userId);
      } else {
        // Get.snackbar("Error", "Failed to load customer data");
      }
    } catch (e) {
      // Get.snackbar("Error", "Network issue: $e");
    } finally {
      isLoading.value = false;
    }
  }

  // ✅ NEW: Check if customer has any real plan data
  bool get hasActivePlan {
    final customerData = customer.value;
    if (customerData == null) return false;
    // Check if any meaningful plan field exists (adjust based on your backend)
    return customerData.subscriptionPlan != null ||
        customerData.subscriptionPlan != null ||
        customerData.fmc != null ||
        customerData.bbUserId != null;
  }

  // ✅ NEW METHOD: Fetch Plan Request Status
  Future<void> fetchPlanRequestStatus(int customerId) async {
    isFetchingPlanStatus.value = true;
    try {
      final status = await apiServices.getPlanRequestStatus(customerId);
      planRequestStatus.value = status;
    } catch (e) {
      // Get.snackbar("Error", "Failed to load plan status");
    } finally {
      isFetchingPlanStatus.value = false;
    }
  }

  // Add these fields in ProfileController
  final isRelocationLoading = false.obs;

  // Add this method
  Future<void> fetchRelocationStatus() async {
    final mobile = AppSharedPref.instance.getMobileNumber();
    if (mobile == null) return;

    isRelocationLoading(true);
    try {
      final data = await apiServices.checkRelocationStatus(mobile);
      if (data != null && data.containsKey('data')) {
        relocationStatus.value = data['data'];
      } else {
        relocationStatus.value = null;
      }
    } finally {
      isRelocationLoading(false);
    }
  }

  Future<void> refreshCustomerData() async {
    isLoading.value = true;
    await fetchCustomerData();
    await fetchRelocationStatus();
    isLoading.value = false;
  }
}

// --- Main Content Widget ---
class HomeScreenContent extends StatefulWidget {
  const HomeScreenContent({super.key});

  @override
  _HomeScreenContentState createState() => _HomeScreenContentState();
}

class _HomeScreenContentState extends State<HomeScreenContent> {
  late PageController _pageController;
  Timer? _adTimer;
  int _currentAdIndex = 0;

  // Example ads data - Using the new color palette
  final List<Map<String, dynamic>> ads = [
    {
      'title': 'Upgrade to Ultra Speed',
      'description': 'Get 500Mbps at just ₹1999/month',
      'color': AppColors.primary,
      'gradientStart': AppColors.primary,
      'gradientEnd': AppColors.primaryDark,
    },
    {
      'title': 'Refer & Earn',
      'description': 'Get ₹500 cashback for each referral',
      'color': AppColors.secondary,
      'gradientStart': AppColors.secondary,
      'gradientEnd': AppColors.secondaryDark,
    },
    {
      'title': 'Family Pack Special',
      'description': 'Add 4 connections at 30% discount',
      'color': AppColors.accent2,
      'gradientStart': AppColors.accent2,
      'gradientEnd': Color(0xFF303F9F),
    },
  ];

  // Quick actions data - Updated with new colors and icons
  final List<Map<String, dynamic>> actions = [
    {
      'icon': Icons.payment_rounded,
      'label': 'Pay Bill',
      'color': AppColors.primary,
      'onPressed': () {
        Get.snackbar(
          "Action",
          "Pay Bill functionality is not implemented yet.",
        );
      },
    },
    {
      'icon': Icons.speed_rounded,
      'label': 'Speed Test',
      'color': AppColors.secondary,
      'onPressed': () {
        Get.snackbar(
          "Action",
          "Speed Test functionality is not implemented yet.",
        );
      },
    },
    {
      'icon': Icons.data_usage_rounded,
      'label': 'Usage',
      'color': AppColors.success,
      'onPressed': () {
        Get.snackbar("Action", "Usage functionality is not implemented yet.");
      },
    },
    {
      'icon': Icons.support_agent_rounded,
      'label': 'Support',
      'color': AppColors.warning,
      'onPressed': () {
        // Get.to(() => ComplaintsPage());
      },
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.92);
    _startAdTimer();
  }

  void _startAdTimer() {
    _adTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      if (!mounted) return;
      final nextPage = (_currentAdIndex + 1) % ads.length;
      _pageController.animateToPage(
        nextPage,
        duration: Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
      setState(() {
        _currentAdIndex = nextPage;
      });
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _adTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();
    return RefreshIndicator(
      color: AppColors.primary,
      backgroundColor: Colors.white,
      onRefresh: controller.refreshCustomerData,
      child: Obx(() {
        if (controller.isLoading.value) {
          return Center(
            child: CircularProgressIndicator(color: AppColors.primary),
          );
        }
        return _buildHomeContent(controller);
      }),
    );
  }

  Widget _buildHomeContent(HomeController controller) {
    return CustomScrollView(
      physics: BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 16.h), // Responsive height
              // ✅ Greeting with customer name
              // Padding(
              //   padding: const EdgeInsets.symmetric(
              //     horizontal: 16,
              //     vertical: 8,
              //   ),
              //   child: Text(
              //     "Welcome back, ${controller.customer.value?.contactName ?? 'User'}!",
              //     style: AppText.headingSmall.copyWith(
              //       fontWeight: FontWeight.bold,
              //       color: AppColors.textColorPrimary,
              //     ),
              //   ),
              // ),
              // // ✅ Show referral code if available
              // if (controller.customer.value?.referralCode != null)
              //   Padding(
              //     padding: const EdgeInsets.symmetric(
              //       horizontal: 16,
              //       vertical: 8,
              //     ),
              //     child: Container(
              //       padding: EdgeInsets.all(12),
              //       decoration: BoxDecoration(
              //         color: AppColors.primary.withOpacity(0.1),
              //         borderRadius: BorderRadius.circular(12),
              //         border: Border.all(
              //           color: AppColors.primary.withOpacity(0.3),
              //           width: 1,
              //         ),
              //       ),
              //       child: Row(
              //         children: [
              //           Icon(Icons.card_giftcard, color: AppColors.primary),
              //           SizedBox(width: 8),
              //           Flexible(
              //             child: Text(
              //               "Your Referral Code: ${controller.customer.value!.referralCode!}",
              //               style: AppText.bodyMedium.copyWith(
              //                 fontWeight: FontWeight.w600,
              //               ),
              //               overflow: TextOverflow.ellipsis,
              //             ),
              //           ),
              //         ],
              //       ),
              //     ),
              //   ),
              // ),
              // Ad Swiper - Enhanced
              _buildAdSwiper(),
              SizedBox(height: 24.h), // Responsive height
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Obx(() {
                  if (controller.relocationStatus.value != null) {
                    return _buildRelocationStatusCard(
                      controller.relocationStatus.value!,
                    );
                  }
                  return SizedBox();
                }),
              ),
              SizedBox(height: 24.h), // Responsive height
              // ✅ Plan Request Status Widget
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 16.w,
                ), // Responsive padding
                child: _buildPlanRequestStatus(),
              ),
            ],
          ),
        ),
        // Current Plan Section
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 16.w, // Responsive padding
            ).copyWith(bottom: 140.h), // Responsive bottom padding
            child: _buildCurrentPlan(),
          ),
        ),
      ],
    );
  }

  Widget _buildRelocationStatusCard(Map<String, dynamic> data) {
    Color statusColor;
    String statusText;
    switch (data['status']?.toString().toLowerCase()) {
      case 'completed':
        statusColor = AppColors.success;
        statusText = 'Completed';
        break;
      case 'rejected':
        statusColor = AppColors.error;
        statusText = 'Rejected';
        break;
      case 'pending':
      default:
        statusColor = AppColors.warning;
        statusText = 'Pending';
    }

    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Iconsax.transaction_minus,
                  color: AppColors.primary,
                  size: 20,
                ),
              ),
              SizedBox(width: 12),
              Text(
                'Relocation Request',
                style: AppText.headingSmall.copyWith(
                  color: AppColors.primaryDark,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Spacer(),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  statusText,
                  style: AppText.labelSmall.copyWith(
                    color: statusColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          Divider(color: AppColors.dividerColor.withOpacity(0.5), height: 1),
          SizedBox(height: 16),
          _item(Iconsax.location, 'Old Address', data['old_address'] ?? 'N/A'),
          _item(Iconsax.location, 'New Address', data['new_address'] ?? 'N/A'),
          _item(Iconsax.ticket, 'Ticket No', data['ticket_no'] ?? 'N/A'),
          _item(
            Iconsax.calendar,
            'Preferred Date',
            data['preferred_shift_date'] ?? 'N/A',
          ),
          if (data['remark'] != null)
            _item(Iconsax.note, 'Remark', data['remark']),
          _item(Iconsax.money, 'Charges', '₹${data['charges']}'),
        ],
      ),
    );
  }

  Widget _item(IconData icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            size: 20,
            color: AppColors.textColorSecondary.withOpacity(0.7),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: AppText.bodySmall.copyWith(
                    color: AppColors.textColorSecondary,
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value.isNotEmpty ? value : 'Not provided',
                  style: AppText.bodyMedium.copyWith(
                    color: AppColors.textColorPrimary,
                    fontWeight: FontWeight.w500,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlanRequestStatus() {
    final controller = Get.find<HomeController>();
    return Obx(() {
      final status = controller.planRequestStatus.value;
      final isFetching = controller.isFetchingPlanStatus.value;
      if (isFetching) {
        return _buildPlanStatusShimmer();
      }
      if (status == null) {
        return SizedBox(); //_buildNoPlanRequestCard();
      }
      if (status.requestedPlan == null) {
        return SizedBox(); //_buildNoPlanRequestCard();
      }

      final requestedPlan = status.requestedPlan!;
      final currentPlan = status.currentPlan;
      Color statusColor;
      IconData statusIcon;
      String statusText;
      switch (status.status.toLowerCase()) {
        case 'approved':
          statusColor = AppColors.success;
          statusIcon = Icons.check_circle;
          statusText = "Approved";
          break;
        case 'rejected':
          statusColor = AppColors.error;
          statusIcon = Icons.cancel;
          statusText = "Rejected";
          break;
        case 'pending':
        default:
          statusColor = AppColors.warning;
          statusIcon = Icons.hourglass_empty;
          statusText = "Pending Approval";
      }

      return Container(
        margin: EdgeInsets.only(bottom: 24.h), // Responsive margin
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              statusColor.withOpacity(0.1),
              statusColor.withOpacity(0.05),
              Colors.white,
            ],
          ),
          borderRadius: BorderRadius.circular(24.r), // Responsive radius
          border: Border.all(
            color: statusColor.withOpacity(0.3),
            width: 1.w,
          ), // Responsive border width
          boxShadow: [
            BoxShadow(
              color: statusColor.withOpacity(0.1),
              blurRadius: 20.r, // Responsive blur
              offset: Offset(0, 8.h), // Responsive offset
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.all(24.r), // Responsive padding
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(8.r), // Responsive padding
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          statusIcon,
                          color: statusColor,
                          size: 24.r,
                        ), // Responsive icon size
                      ),
                      SizedBox(width: 12.w), // Responsive width
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Plan Change Request",
                            style: AppText.headingSmall.copyWith(
                              fontWeight: FontWeight.w700,
                              color: AppColors.textColorPrimary,
                            ),
                          ),
                          Text(
                            statusText,
                            style: AppText.bodySmall.copyWith(
                              color: statusColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  if (status.status.toLowerCase() == 'pending')
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 12.w, // Responsive padding
                        vertical: 6.h, // Responsive padding
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.warning.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(
                          20.r,
                        ), // Responsive radius
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.refresh,
                            color: AppColors.warning,
                            size: 16.r, // Responsive icon size
                          ),
                          SizedBox(width: 4.w), // Responsive width
                          Text(
                            "Processing",
                            style: TextStyle(
                              fontSize: 12.sp, // Already responsive via .sp
                              color: AppColors.warning,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              SizedBox(height: 24.h), // Responsive height
              // Current Plan (if exists)
              if (currentPlan != null && currentPlan.planName != null)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Current Plan",
                      style: AppText.labelMedium.copyWith(
                        color: AppColors.textColorSecondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 12.h), // Responsive height
                    Container(
                      padding: EdgeInsets.all(16.r), // Responsive padding
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(
                          16.r,
                        ), // Responsive radius
                        border: Border.all(
                          color: AppColors.dividerColor.withOpacity(0.5),
                          width: 1.w, // Responsive border width
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                child: Text(
                                  currentPlan.planName!,
                                  style: AppText.labelLarge.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textColorPrimary,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (currentPlan.price != null)
                                Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 12.w, // Responsive padding
                                    vertical: 6.h, // Responsive padding
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.primary.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(
                                      20.r,
                                    ), // Responsive radius
                                  ),
                                  child: Text(
                                    "₹${currentPlan.price}",
                                    style: AppText.labelMedium.copyWith(
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          if (currentPlan.speed != null)
                            Padding(
                              padding: EdgeInsets.only(
                                top: 8.h,
                              ), // Responsive padding
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.speed,
                                    size: 16.r, // Responsive icon size
                                    color: AppColors.primary,
                                  ),
                                  SizedBox(width: 8.w), // Responsive width
                                  Text(
                                    currentPlan.speed!,
                                    style: AppText.bodySmall.copyWith(
                                      color: AppColors.textColorSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20.h), // Responsive height
                  ],
                ),
              // Requested Plan
              Text(
                "Requested Plan",
                style: AppText.labelMedium.copyWith(
                  color: AppColors.textColorSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 12.h), // Responsive height
              Container(
                padding: EdgeInsets.all(16.r), // Responsive padding
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      statusColor.withOpacity(0.2),
                      statusColor.withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(
                    16.r,
                  ), // Responsive radius
                  border: Border.all(
                    color: statusColor.withOpacity(0.3),
                    width: 1.w, // Responsive border width
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: Text(
                            requestedPlan.planName!,
                            style: AppText.labelLarge.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppColors.textColorPrimary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (requestedPlan.price != null)
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 12.w, // Responsive padding
                              vertical: 6.h, // Responsive padding
                            ),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(
                                20.r,
                              ), // Responsive radius
                            ),
                            child: Text(
                              "₹${requestedPlan.price}",
                              style: AppText.labelMedium.copyWith(
                                color: statusColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                      ],
                    ),
                    if (requestedPlan.speed != null)
                      Padding(
                        padding: EdgeInsets.only(
                          top: 8.h,
                        ), // Responsive padding
                        child: Row(
                          children: [
                            Icon(
                              Icons.speed,
                              size: 16.r,
                              color: statusColor,
                            ), // Responsive icon size
                            SizedBox(width: 8.w), // Responsive width
                            Expanded(
                              child: Text(
                                requestedPlan.speed!,
                                style: AppText.bodySmall.copyWith(
                                  color: AppColors.textColorSecondary,
                                  // overflow: TextOverflow.clip,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    if (requestedPlan.dataLimit != null)
                      Padding(
                        padding: EdgeInsets.only(
                          top: 4.h,
                        ), // Responsive padding
                        child: Row(
                          children: [
                            Icon(
                              Icons.data_usage,
                              size: 16.r, // Responsive icon size
                              color: statusColor,
                            ),
                            SizedBox(width: 8.w), // Responsive width
                            Expanded(
                              child: Text(
                                requestedPlan.dataLimit!,
                                overflow: TextOverflow.clip,
                                style: AppText.bodySmall.copyWith(
                                  color: AppColors.textColorSecondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              SizedBox(height: 20.h), // Responsive height
              // Request Details
              Container(
                padding: EdgeInsets.all(16.r), // Responsive padding
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(
                    16.r,
                  ), // Responsive radius
                  border: Border.all(
                    color: AppColors.dividerColor.withOpacity(0.5),
                    width: 1.w, // Responsive border width
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Request Details",
                      style: AppText.labelMedium.copyWith(
                        color: AppColors.textColorSecondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 12.h), // Responsive height
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today,
                          size: 16.r, // Responsive icon size
                          color: AppColors.primary,
                        ),
                        SizedBox(width: 8.w), // Responsive width
                        Text(
                          "Requested on: ${status.addedDateTime.split(' ')[0]}",
                          style: AppText.bodySmall.copyWith(
                            color: AppColors.textColorSecondary,
                          ),
                        ),
                      ],
                    ),
                    if (status.planRemark != null &&
                        status.planRemark!.isNotEmpty)
                      Padding(
                        padding: EdgeInsets.only(
                          top: 8.h,
                        ), // Responsive padding
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.note,
                              size: 16.r, // Responsive icon size
                              color: AppColors.primary,
                            ),
                            SizedBox(width: 8.w), // Responsive width
                            Expanded(
                              child: Text(
                                status.planRemark!,
                                style: AppText.bodySmall.copyWith(
                                  color: AppColors.textColorSecondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              SizedBox(height: 20.h), // Responsive height
              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        final int? userId = AppSharedPref.instance.getUserID();
                        if (userId != null) {
                          controller.fetchPlanRequestStatus(userId);
                          controller.fetchRelocationStatus();
                        }
                      },
                      icon: Icon(
                        Icons.refresh,
                        size: 18.r,
                      ), // Responsive icon size
                      label: Text(
                        "Refresh Status",
                        style: AppText.button.copyWith(
                          fontSize: 14.sp,
                        ), // Already responsive
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        minimumSize: Size(
                          double.infinity,
                          48.h,
                        ), // Responsive height
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            12.r,
                          ), // Responsive radius
                        ),
                        elevation: 0,
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w), // Responsive width
                  if (status.status.toLowerCase() == 'pending')
                    Container(
                      width: 48.w, // Responsive width
                      height: 48.h, // Responsive height
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(
                          12.r,
                        ), // Responsive radius
                        border: Border.all(
                          color: AppColors.primary.withOpacity(0.3),
                        ),
                      ),
                      child: IconButton(
                        icon: Icon(
                          Icons.help_outline,
                          color: AppColors.primary,
                          size: 20.r, // Responsive icon size
                        ),
                        onPressed: () {
                          Get.snackbar(
                            "Need Help?",
                            "Your plan change request is being processed. Contact support if you have any questions.",
                            backgroundColor: AppColors.primary,
                            colorText: Colors.white,
                            duration: Duration(seconds: 5),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      );
    });
  }

  Widget _buildNoPlanRequestCard() {
    return Container(
      margin: EdgeInsets.only(bottom: 24.h), // Responsive margin
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary.withOpacity(0.05), Colors.white],
        ),
        borderRadius: BorderRadius.circular(24.r), // Responsive radius
        border: Border.all(
          color: AppColors.dividerColor,
          width: 1.w,
        ), // Responsive border width
      ),
      child: Padding(
        padding: EdgeInsets.all(24.r), // Responsive padding
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              Icons.upgrade,
              size: 48.r, // Responsive icon size
              color: AppColors.primary.withOpacity(0.5),
            ),
            SizedBox(height: 16.h), // Responsive height
            Text(
              "No Plan Change Request",
              style: AppText.headingSmall.copyWith(
                fontSize: 18.sp, // Already responsive
                fontWeight: FontWeight.w600,
                color: AppColors.textColorPrimary,
              ),
            ),
            SizedBox(height: 8.h), // Responsive height
            Text(
              "You haven't requested any plan changes recently.",
              textAlign: TextAlign.center,
              style: AppText.bodyMedium.copyWith(
                color: AppColors.textColorSecondary,
              ),
            ),
            SizedBox(height: 24.h), // Responsive height
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  Get.context!,
                  MaterialPageRoute(
                    builder: (context) => PremiumBsnlPlansScreen(),
                  ),
                );
              },
              icon: Icon(Icons.upgrade, size: 18.r), // Responsive icon size
              label: Text(
                "Upgrade Your Plan",
                style: AppText.button.copyWith(
                  fontSize: 14.sp,
                ), // Already responsive
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                minimumSize: Size(double.infinity, 48.h), // Responsive height
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                    12.r,
                  ), // Responsive radius
                ),
                elevation: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlanStatusShimmer() {
    return Container(
      margin: EdgeInsets.only(bottom: 24.h), // Responsive margin
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24.r), // Responsive radius
        color: Colors.white,
      ),
      child: Padding(
        padding: EdgeInsets.all(24.r), // Responsive padding
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40.w, // Responsive width
                  height: 40.h, // Responsive height
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 12.w), // Responsive width
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 200.w,
                      height: 20.h,
                      color: Colors.grey[300],
                    ), // Responsive size
                    SizedBox(height: 8.h), // Responsive height
                    Container(
                      width: 120.w,
                      height: 16.h,
                      color: Colors.grey[300],
                    ), // Responsive size
                  ],
                ),
              ],
            ),
            SizedBox(height: 24.h), // Responsive height
            Container(
              padding: EdgeInsets.all(16.r), // Responsive padding
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(16.r), // Responsive radius
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 180.w,
                    height: 20.h,
                    color: Colors.grey[300],
                  ), // Responsive size
                  SizedBox(height: 12.h), // Responsive height
                  Container(
                    width: 120.w,
                    height: 16.h,
                    color: Colors.grey[300],
                  ), // Responsive size
                  SizedBox(height: 8.h), // Responsive height
                  Container(
                    width: 150.w,
                    height: 16.h,
                    color: Colors.grey[300],
                  ), // Responsive size
                ],
              ),
            ),
            SizedBox(height: 20.h), // Responsive height
            Container(
              width: double.infinity,
              height: 48.h, // Responsive height
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(12.r), // Responsive radius
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentPlan() {
    final controller = Get.find<HomeController>();
    // ✅ If no real plan data, show "No Active Plan" card
    if (!controller.hasActivePlan) {
      return Container(
        margin: EdgeInsets.only(bottom: 16.h), // Responsive margin
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.warning.withOpacity(0.05), Colors.white],
          ),
          borderRadius: BorderRadius.circular(20.r), // Responsive radius
          border: Border.all(
            color: AppColors.warning.withOpacity(0.3),
            width: 1.w, // Responsive border width
          ),
        ),
        padding: EdgeInsets.all(24.r), // Responsive padding
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.error_outline,
                  color: AppColors.warning,
                  size: 28.r,
                ), // Responsive icon size
                SizedBox(width: 12.w), // Responsive width
                Flexible(
                  child: Text(
                    "No Active Plan",
                    style: AppText.bodyLarge.copyWith(
                      // fontSize: 18.sp, // Already responsive
                      fontWeight: FontWeight.w700,
                      color: AppColors.textColorPrimary,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.h), // Responsive height
            Text(
              "You don’t have an active internet plan yet. Choose a plan to get started!",
              style: AppText.bodySmall.copyWith(
                color: AppColors.textColorSecondary,
                overflow: TextOverflow.clip,
                height: 1.4, // Keep line height consistent
              ),
            ),
            SizedBox(height: 24.h), // Responsive height
            ElevatedButton.icon(
              onPressed: () {
                Get.toNamed(
                  AppRoutes.bsnlPlans,
                  arguments: {"isBackBtn": true},
                );
              },
              icon: Icon(Icons.upgrade, size: 18.r), // Responsive icon size
              label: Text(
                "Choose a Plan",
                style: AppText.button.copyWith(
                  fontWeight: FontWeight.w600,
                  fontSize: 14.sp, // Already responsive
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                minimumSize: Size(double.infinity, 56.h), // Responsive height
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                    14.r,
                  ), // Responsive radius
                ),
                elevation: 0,
                padding: EdgeInsets.symmetric(
                  vertical: 16.h,
                ), // Responsive padding
              ),
            ),
          ],
        ),
      );
    }

    // ✅ Else, show current plan (mock for now, until backend provides real data)
    return Container(
      margin: EdgeInsets.only(bottom: 16.h), // Responsive margin
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.primary.withOpacity(0.03),
            AppColors.primary.withOpacity(0.01),
            Colors.white,
          ],
        ),
        borderRadius: BorderRadius.circular(20.r), // Responsive radius
        border: Border.all(
          color: AppColors.primary.withOpacity(0.1),
          width: 1.w,
        ), // Responsive border width
      ),
      padding: EdgeInsets.all(20.r), // Responsive padding
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Text(
                  controller.currentPlanName.value,
                  style: AppText.headingSmall.copyWith(
                    fontSize: 18.sp, // Already responsive
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 12.w,
                  vertical: 6.h,
                ), // Responsive padding
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(
                    20.r,
                  ), // Responsive radius
                ),
                child: Text(
                  controller.currentPrice.value,
                  style: AppText.labelLarge.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 20.h), // Responsive height
          Row(
            children: [
              _buildPlanDetail(
                Icons.speed,
                "Speed",
                controller.currentSpeed.value,
              ),
              SizedBox(width: 20.w), // Responsive width
              _buildPlanDetail(Icons.data_usage, "Data", "Unlimited"),
            ],
          ),
          SizedBox(height: 20.h), // Responsive height
          Row(
            children: [
              _buildPlanDetail(Icons.calendar_today, "Validity", "30 days"),
              SizedBox(width: 20.w), // Responsive width
              _buildPlanDetail(Icons.update, "Renewal", "15 Jan 2025"),
            ],
          ),
          SizedBox(height: 24.h), // Responsive height
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Data Usage",
                    style: AppText.bodyMedium.copyWith(
                      color: AppColors.textColorSecondary,
                    ),
                  ),
                  Text(
                    controller.usageText.value,
                    style: AppText.labelMedium.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8.h), // Responsive height
              ClipRRect(
                borderRadius: BorderRadius.circular(10.r), // Responsive radius
                child: LinearProgressIndicator(
                  value: controller.usageProgress.value,
                  backgroundColor: AppColors.inputBackground,
                  minHeight: 10.h, // Responsive height
                  valueColor: AlwaysStoppedAnimation<Color>(
                    _getProgressColor(controller.usageProgress.value),
                  ),
                ),
              ),
              SizedBox(height: 4.h), // Responsive height
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "0 GB",
                    style: AppText.labelSmall.copyWith(
                      color: AppColors.textColorHint,
                    ),
                  ),
                  Text(
                    "1000 GB",
                    style: AppText.labelSmall.copyWith(
                      color: AppColors.textColorHint,
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 20.h), // Responsive height
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PremiumBsnlPlansScreen(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    minimumSize: Size(
                      double.infinity,
                      50.h,
                    ), // Responsive height
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        12.r,
                      ), // Responsive radius
                    ),
                    elevation: 0,
                    padding: EdgeInsets.symmetric(
                      vertical: 14.h,
                    ), // Responsive padding
                  ),
                  child: Text(
                    "Upgrade Plan",
                    style: AppText.button.copyWith(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              SizedBox(width: 12.w), // Responsive width
              Container(
                width: 50.w, // Responsive width
                height: 50.h, // Responsive height
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    12.r,
                  ), // Responsive radius
                  border: Border.all(color: AppColors.primary.withOpacity(0.3)),
                ),
                child: IconButton(
                  icon: Icon(Icons.refresh, color: AppColors.primary),
                  onPressed: () {
                    controller.fetchCustomerData();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAdSwiper() {
    return Column(
      children: [
        SizedBox(
          height: 180.h, // Responsive height
          child: PageView.builder(
            controller: _pageController,
            itemCount: ads.length,
            onPageChanged: (index) {
              setState(() {
                _currentAdIndex = index;
              });
            },
            itemBuilder: (context, index) {
              return AnimatedBuilder(
                animation: _pageController,
                builder: (context, child) {
                  double value = 1.0;
                  if (_pageController.position.haveDimensions) {
                    value = _pageController.page! - index;
                    value = (1 - (value.abs() * 0.3)).clamp(0.0, 1.0);
                  }
                  return Transform.scale(
                    scale: value,
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage("assets/slider-0${index + 1}.jpg"),
                          fit: BoxFit.fill,
                        ),
                        borderRadius: BorderRadius.circular(
                          20.r,
                        ), // Responsive radius
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SizedBox(height: 12.h), // Responsive height
        SmoothPageIndicator(
          controller: _pageController,
          count: ads.length,
          effect: ExpandingDotsEffect(
            activeDotColor: AppColors.primary,
            dotColor: AppColors.textColorHint.withOpacity(0.3),
            dotHeight: 8.h, // Responsive height
            dotWidth: 8.w, // Responsive width
            expansionFactor: 3,
          ),
        ),
      ],
    );
  }

  Widget _buildPlanDetail(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(12.r), // Responsive padding
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r), // Responsive radius
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 10.r, // Responsive blur
              spreadRadius: 2.r, // Responsive spread
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 36.w, // Responsive width
              height: 36.h, // Responsive height
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: AppColors.primary,
                size: 18.r,
              ), // Responsive icon size
            ),
            SizedBox(width: 12.w), // Responsive width
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: AppText.bodySmall.copyWith(
                    color: AppColors.textColorSecondary,
                  ),
                ),
                SizedBox(height: 2.h), // Responsive height
                Text(
                  value,
                  style: AppText.labelSmall.copyWith(
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.w600,
                    color: AppColors.backgroundDark,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _getProgressColor(double value) {
    if (value < 0.5) return AppColors.success;
    if (value < 0.8) return AppColors.warning;
    return AppColors.error;
  }
}
