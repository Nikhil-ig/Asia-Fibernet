// To parse this JSON data, do
//
//     final customerDetails = customerDetailsFromJson(jsonString);

import 'dart:convert';

CustomerDetailsResponse customerDetailsResponseFromJson(String str) =>
    CustomerDetailsResponse.fromJson(json.decode(str));

String customerDetailsResponseToJson(CustomerDetailsResponse data) =>
    json.encode(data.toJson());

class CustomerDetailsResponse {
  final String? status;
  final String? message;
  final Data? data;

  CustomerDetailsResponse({this.status, this.message, this.data});

  factory CustomerDetailsResponse.fromJson(Map<String, dynamic> json) =>
      CustomerDetailsResponse(
        status: json["status"],
        message: json["message"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
  };
}

class Data {
  final CustomerDetails? customerDetails;
  final List<MoreAccount>? moreAccount;

  Data({this.customerDetails, this.moreAccount});

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    customerDetails:
        json["customer_details"] == null
            ? null
            : CustomerDetails.fromJson(json["customer_details"]),
    moreAccount:
        json["more_account"] == null
            ? []
            : List<MoreAccount>.from(
              json["more_account"]!.map((x) => MoreAccount.fromJson(x)),
            ),
  );

  Map<String, dynamic> toJson() => {
    "customer_details": customerDetails?.toJson(),
    "more_account":
        moreAccount == null
            ? []
            : List<dynamic>.from(moreAccount!.map((x) => x.toJson())),
  };
}

class CustomerDetails {
  final int? id;
  final String? accountId;
  final String? accountType;
  final String? contactName;
  final String? address;
  final String? city;
  final String? state;
  final String? workphnumber;
  final String? cellphnumber;
  final String? email;
  final String? referralCode;
  final dynamic referredBy;
  final String? profilePhoto;
  final dynamic frServiceCode;
  final dynamic category;
  final dynamic exchangeCode;
  final String? ftthNo;
  final dynamic subServiceType;
  final dynamic subscriptionPlan;
  final dynamic planPeriod;
  final dynamic fmc;
  final dynamic bbUserId;
  final dynamic bbActivationDate;
  final dynamic assignTo;
  final dynamic status;

  CustomerDetails({
    this.id,
    this.accountId,
    this.accountType,
    this.contactName,
    this.address,
    this.city,
    this.state,
    this.workphnumber,
    this.cellphnumber,
    this.email,
    this.referralCode,
    this.referredBy,
    this.profilePhoto,
    this.frServiceCode,
    this.category,
    this.exchangeCode,
    this.ftthNo,
    this.subServiceType,
    this.subscriptionPlan,
    this.planPeriod,
    this.fmc,
    this.bbUserId,
    this.bbActivationDate,
    this.assignTo,
    this.status,
  });

  factory CustomerDetails.fromJson(Map<String, dynamic> json) =>
      CustomerDetails(
        id: json["ID"],
        accountId: json["AccountID"],
        accountType: json["AccountType"],
        contactName: json["ContactName"],
        address: json["Address"],
        city: json["City"],
        state: json["State"],
        workphnumber: json["Workphnumber"],
        cellphnumber: json["Cellphnumber"],
        email: json["Email"],
        referralCode: json["referral_code"],
        referredBy: json["referred_by"],
        profilePhoto: "http://dgipe.com/af/api/${json["profile_photo"]}",
        frServiceCode: json["FR_Service_Code"],
        category: json["Category"],
        exchangeCode: json["Exchange_Code"],
        ftthNo: json["ftth_no"],
        subServiceType: json["Sub_Service_Type"],
        subscriptionPlan: json["Subscription_Plan"],
        planPeriod: json["Plan_Period"],
        fmc: json["FMC"],
        bbUserId: json["BB_USER_ID"],
        bbActivationDate: json["BB_Activation_Date"],
        assignTo: json["Assign_To"],
        status: json["Status"],
      );

  Map<String, dynamic> toJson() => {
    "ID": id,
    "AccountID": accountId,
    "AccountType": accountType,
    "ContactName": contactName,
    "Address": address,
    "City": city,
    "State": state,
    "Workphnumber": workphnumber,
    "Cellphnumber": cellphnumber,
    "Email": email,
    "referral_code": referralCode,
    "referred_by": referredBy,
    "profile_photo": profilePhoto,
    "FR_Service_Code": frServiceCode,
    "Category": category,
    "Exchange_Code": exchangeCode,
    "ftth_no": ftthNo,
    "Sub_Service_Type": subServiceType,
    "Subscription_Plan": subscriptionPlan,
    "Plan_Period": planPeriod,
    "FMC": fmc,
    "BB_USER_ID": bbUserId,
    "BB_Activation_Date": bbActivationDate,
    "Assign_To": assignTo,
    "Status": status,
  };
}

class MoreAccount {
  final int? id;
  final String? ladlineno;

  MoreAccount({this.id, this.ladlineno});

  factory MoreAccount.fromJson(Map<String, dynamic> json) =>
      MoreAccount(id: json["ID"], ladlineno: json["ladlineno"]);

  Map<String, dynamic> toJson() => {"ID": id, "ladlineno": ladlineno};
}
